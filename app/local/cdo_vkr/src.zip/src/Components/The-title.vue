<template>
    <v-container>
        <v-row class="">
            <v-col md="12" class="d-flex align-start">
                <h1>{{ this.$store.state.strings.headers.VKR }}</h1>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
export default {
    name: "The-title",
    methods: {
    }
}
</script>

<style scoped>

</style>