class Settings {
    constructor(token = '', url = '') {
        this.token = token;
        this.url = url;
    }

    /**
     * Устанавливает токен
     * @param {string} token - Токен для авторизации
     */
    setToken(token) {
        this.token = token;
    }

    /**
     * Устанавливает URL
     * @param {string} url - Базовый URL
     */
    setUrl(url) {
        this.url = url;
    }

    /**
     * Получает текущий токен
     * @returns {string} Текущий токен
     */
    getToken() {
        return this.token;
    }

    /**
     * Получает текущий URL
     * @returns {string} Текущий URL
     */
    getUrl() {
        return this.url;
    }
}

/**
 * Получает массив экземпляров Settings с разными параметрами
 * @returns {Promise<Array<Settings>>} Массив экземпляров Settings
 */
const fetchConfigs = async () => {
    try {
        // Здесь будет реализация получения данных из сервиса
        // Пока возвращаем тестовые данные
        return [
            new Settings('token1', 'https://api1.example.com'),
            new Settings('token2', 'https://api2.example.com'),
            new Settings('token3', 'https://api3.example.com')
        ];
    } catch (error) {
        console.error('Ошибка при получении конфигураций:', error);
        throw error;
    }
};

// Экспортируем класс Settings и функцию fetchConfigs
export { Settings, fetchConfigs }; 