import App from './components/App.vue';
import {createApp} from "vue";
import {createPinia} from 'pinia';
import router from './router';

import {useLangStore} from "./store/storeLang";
import {useGeneralStore} from "./store/storeGeneral";
import notification from "core/notification";

async function init(email, isROP, apiRequestParam) {
    if (email) {
        const pinia = createPinia();
        const app = createApp(App);
        
        // Инициализируем плагины
        app.use(pinia);
        app.use(router);

        const lang = useLangStore();
        await lang.loadComponentStrings('block_cdo_showcase');

        // Устанавливаем email пользователя и загружаем информацию о нем
        const generalStore = useGeneralStore();
       // generalStore.setUserEmail(email);
        generalStore.userEmail = (email);
        generalStore.isROP = isROP;
        generalStore.apiRequestParam = apiRequestParam || '';

        if (isROP) {
            await generalStore.fetchROPConfig();
            await generalStore.getROPCourses();
        } else {

            await generalStore.fetchConfigs();
            await generalStore.getUserCourses();
        }

        
        // Монтируем приложение
        app.mount('#main_app');
    } else {
        await notification.addNotification({message: 'Не найдена электронная почта'})
    }
}

export {
    init
};
