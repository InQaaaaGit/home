import * as XLSX from 'xlsx';

/**
 * Форматирует шкалу оценок в читаемый вид
 * @param {Object} scale - объект шкалы
 * @returns {string} - отформатированная строка шкалы
 */
export function formatScale(scale) {
  if (!scale || !scale.gradescales || !Array.isArray(scale.gradescales)) {
    return 'Шкала не определена';
  }

  return scale.gradescales
    .map(grade => {
      // Используем правильные поля из структуры шкалы
      const name = grade.gradename || grade.name || 'Неизвестно';
      const min = grade.minimum || grade.min || 0;
      const max = grade.maximum || grade.max || 0;
      return `${name}: ${min} - ${max}`;
    })
    .join('; ');
}

/**
 * Создает отчет студента в формате Excel
 * @param {Array} coursesData - массив данных о курсах студента
 * @param {string} studentName - имя студента
 * @param {string} studentEmail - email студента
 * @returns {Blob} - Excel файл в виде Blob
 */
export function createStudentReport(coursesData, studentName, studentEmail) {
  // Подготавливаем данные для Excel
  const worksheetData = [
    // Заголовки
    [
      'Дисциплина',
      'ТК1',
      'ТК2',
      'Индивидуальные достижения',
      'Итого',
      'Средний балл дисциплины',
      'Шкала'
    ]
  ];

  // Добавляем данные по каждому курсу
  coursesData.forEach((course, index) => {
    const row = [
      course.course_name || 'Неизвестная дисциплина',
      course.frtk1 !== null && course.frtk1 !== undefined ? course.frtk1 : '-',
      course.frtk2 !== null && course.frtk2 !== undefined ? course.frtk2 : '-',
      course.individual !== null && course.individual !== undefined ? course.individual : '-',
      course.final_grade !== null && course.final_grade !== undefined ? course.final_grade : '-',
      course.average_grade !== null && course.average_grade !== undefined ? course.average_grade : '-',
      formatScale(course.scale)
    ];
    
    worksheetData.push(row);
  });

  // Создаем рабочую книгу
  const workbook = XLSX.utils.book_new();
  
  // Создаем рабочий лист
  const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

  // Настраиваем ширину колонок
  const columnWidths = [
    { wch: 40 }, // Дисциплина
    { wch: 12 }, // ТК1
    { wch: 12 }, // ТК2
    { wch: 25 }, // Индивидуальные достижения
    { wch: 12 }, // Итого
    { wch: 20 }, // Средний балл дисциплины
    { wch: 50 }  // Шкала
  ];
  worksheet['!cols'] = columnWidths;

  // Добавляем стили для заголовков
  const headerRange = XLSX.utils.decode_range(worksheet['!ref']);
  for (let col = headerRange.s.c; col <= headerRange.e.c; col++) {
    const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
    if (worksheet[cellAddress]) {
      worksheet[cellAddress].s = {
        font: { bold: true },
        fill: { fgColor: { rgb: "CCCCCC" } },
        alignment: { horizontal: "center" }
      };
    }
  }

  // Добавляем лист в книгу
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Отчет студента');

  // Создаем метаданные
  const fileName = `Отчет_студента_${studentName}_${new Date().toISOString().split('T')[0]}.xlsx`;

  // Конвертируем в Blob
  const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

  return { blob, fileName };
}

/**
 * Скачивает файл
 * @param {Blob} blob - файл для скачивания
 * @param {string} fileName - имя файла
 */
export function downloadFile(blob, fileName) {
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(url);
}

/**
 * Создает и скачивает отчет студента
 * @param {Array} coursesData - массив данных о курсах студента
 * @param {string} studentName - имя студента
 * @param {string} studentEmail - email студента
 */
export function exportStudentReport(coursesData, studentName, studentEmail) {
  try {
    const { blob, fileName } = createStudentReport(coursesData, studentName, studentEmail);
    downloadFile(blob, fileName);
    return true;
  } catch (error) {
    console.error('Ошибка при создании отчета:', error);
    return false;
  }
}

/**
 * Создает и скачивает отчет преподавателя
 * @param {string} disciplineName - Название дисциплины
 * @param {string|number} averageGrade - Средний балл
 * @param {string} gradingScale - Шкала оценивания
 * @param {Array} students - Массив студентов
 */
export function exportTeacherReport(disciplineName, averageGrade, gradingScale, students) {
    try {
        const header = [
            ['Дисциплина:', disciplineName],
            ['Средний балл по дисциплине:', averageGrade],
            ['Шкала оценивания:', gradingScale],
            [], // Пустая строка для разделения
            ['ФИО Студента', 'ТК1', 'ТК2', 'Индивидуальные достижения', 'Финальный балл']
        ];

        const studentData = students.map(student => [
            student.fullname,
            student.frtk1 !== null && student.frtk1 !== undefined ? student.frtk1.toFixed(2) : '-',
            student.frtk2 !== null && student.frtk2 !== undefined ? student.frtk2.toFixed(2) : '-',
            student.individual !== null && student.individual !== undefined ? student.individual.toFixed(2) : '-',
            student.finalGrade !== null && student.finalGrade !== undefined ? student.finalGrade.toFixed(2) : '-'
        ]);

        const worksheetData = [...header, ...studentData];
        const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

        // Стили и ширина колонок
        worksheet['!cols'] = [
            { wch: 40 }, // ФИО Студента
            { wch: 12 }, // ТК1
            { wch: 12 }, // ТК2
            { wch: 25 }, // Индивидуальные достижения
            { wch: 20 }  // Финальный балл
        ];
        worksheet['A1'].s = { font: { bold: true } };
        worksheet['A2'].s = { font: { bold: true } };
        worksheet['A3'].s = { font: { bold: true } };
        // Стили для заголовков таблицы
        worksheet['A5'].s = { font: { bold: true }, fill: { fgColor: { rgb: "FFFF00" } } };
        worksheet['B5'].s = { font: { bold: true }, fill: { fgColor: { rgb: "FFFF00" } } };
        worksheet['C5'].s = { font: { bold: true }, fill: { fgColor: { rgb: "FFFF00" } } };
        worksheet['D5'].s = { font: { bold: true }, fill: { fgColor: { rgb: "FFFF00" } } };
        worksheet['E5'].s = { font: { bold: true }, fill: { fgColor: { rgb: "FFFF00" } } };


        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Отчет преподавателя');

        const fileName = `Отчет_преподавателя_${disciplineName.replace(/\s/g, '_')}_${new Date().toISOString().split('T')[0]}.xlsx`;
        const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

        downloadFile(blob, fileName);

        return true;
    } catch (error) {
        console.error('Ошибка при создании отчета преподавателя:', error);
        return false;
    }
}

/**
 * Создает и скачивает отчет для РОП
 * @param {Array} coursesData - массив данных о курсах
 */
export function exportRopReport(coursesData) {
    try {
        const worksheetData = [
            [
                'Название дисциплины',
                'Средний балл ФРТК1',
                'Средний балл ФРТК2',
                'Средний балл инд. достижений',
                'Средний балл студентов',
                'Шкала оценивания'
            ],
            ...coursesData.map(course => [
                course.discipline_name,
                course.average_frtk1 !== null && course.average_frtk1 !== undefined ? course.average_frtk1 : '-',
                course.average_frtk2 !== null && course.average_frtk2 !== undefined ? course.average_frtk2 : '-',
                course.average_individual !== null && course.average_individual !== undefined ? course.average_individual : '-',
                course.average_student_grade,
                formatScale(course.grading_scale)
            ])
        ];

        const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

        worksheet['!cols'] = [
            { wch: 40 }, // Название дисциплины
            { wch: 18 }, // Средний балл ФРТК1
            { wch: 18 }, // Средний балл ФРТК2
            { wch: 25 }, // Средний балл инд. достижений
            { wch: 20 }, // Средний балл студентов
            { wch: 50 }  // Шкала оценивания
        ];
        const headerRange = XLSX.utils.decode_range(worksheet['!ref']);
        for (let col = headerRange.s.c; col <= headerRange.e.c; col++) {
            const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
            if (worksheet[cellAddress]) {
                worksheet[cellAddress].s = {
                    font: { bold: true },
                    fill: { fgColor: { rgb: "D3D3D3" } },
                    alignment: { horizontal: "center" }
                };
            }
        }

        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Отчет РОП');

        const fileName = `Отчет_РОП_${new Date().toISOString().split('T')[0]}.xlsx`;
        const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

        downloadFile(blob, fileName);

        return true;
    } catch (error) {
        console.error('Ошибка при создании отчета РОП:', error);
        return false;
    }
} 