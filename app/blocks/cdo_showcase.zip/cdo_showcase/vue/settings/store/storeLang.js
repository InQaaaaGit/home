import {defineStore} from 'pinia'
import * as moodleStorage from 'core/localstorage';
import * as moodleAjax from 'core/ajax';

export const useLangStore = defineStore('lang', {
    state: () => (
        {
            strings: {
                name: 'Название',
                url: 'URL',
                token: 'Токен',
                actions: 'Действия',
                save: 'Сохранить',
                delete_row: 'Удалить',
                add_new: 'Добавить новую запись',
                no_settings: 'Нет настроек',
                check_token: 'Проверить токен',
                assign_users: 'Назначить пользователей',
                assign_users_to_token: 'Назначить пользователей на токен',
                search_users: 'Поиск пользователей...',
                no_users_found: 'Пользователи не найдены',
                cancel: 'Отмена',
                users_assigned: 'Пользователи успешно назначены',
                error_assigning_users: 'Ошибка при назначении пользователей'
            }
        }
    ),
    getters: {
        getStrings(state) {
            return state.strings;
        }
    },
    actions: {
        async loadComponentStrings(pluginName) {
            const lang = document.getElementsByTagName('html')[0].getAttribute('lang').replace(/-/g, '_');
            const cacheKey = pluginName +'/strings/' + lang;
            const cachedStrings = moodleStorage.get(cacheKey);
            if (cachedStrings) {
                this.strings = JSON.parse(cachedStrings);
            } else {
                const request = {
                    methodname: 'core_get_component_strings',
                    args: {
                        'component': pluginName,
                        lang,
                    },
                };
                const loadedStrings = await moodleAjax.call([request])[0];
                let strings = {};
                loadedStrings.forEach((s) => {
                    strings[s.stringid] = s.string;
                });
                this.strings = strings;
                moodleStorage.set(cacheKey, JSON.stringify(strings));
            }
        }
    }
})