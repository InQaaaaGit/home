<?php
require_once(__DIR__ . "/../../config.php");

try {
    redirect('education_plan.php');
} catch (moodle_exception $e) {

}