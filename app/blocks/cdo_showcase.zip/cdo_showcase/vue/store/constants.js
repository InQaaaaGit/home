/**
 * Константы для системы оценивания
 */

/**
 * Ключевые слова для поиска категорий оценок
 * Используется для определения типа категории по её названию
 */
export const CATEGORY_KEYWORDS = {
  frtk1: ['фртк1', 'фртк 1', 'frtk1', 'frtk 1', 'фртк-1', 'тк-1', 'тк 1', 'тк1', 'tk-1', 'tk 1', 'tk1'],
  frtk2: ['фртк2', 'фртк 2', 'frtk2', 'frtk 2', 'фртк-2', 'тк-2', 'тк 2', 'тк2', 'tk-2', 'tk 2', 'tk2'],
  individual: ['индивидуальн', 'достижени', 'individual', 'achievement']
};

/**
 * Функция для проверки соответствия текста ключевым словам
 * @param {string} text - Текст для проверки
 * @param {string[]} keywords - Массив ключевых слов
 * @returns {boolean} - true если найдено соответствие
 */
export function matchesKeywords(text, keywords) {
  if (!text || typeof text !== 'string') {
    return false;
  }
  
  const textLower = text.toLowerCase().trim();
  
  return keywords.some(keyword => {
    const keywordLower = keyword.toLowerCase().trim();
    
    // Проверяем точное совпадение (без учета регистра)
    if (textLower === keywordLower) {
      return true;
    }
    // Проверяем, содержит ли текст ключевое слово
    if (textLower.includes(keywordLower)) {
      return true;
    }
    return false;
  });
}

/**
 * Функция для определения типа категории по её названию
 * @param {string} categoryName - Название категории
 * @returns {string|null} - Тип категории или null если не определен
 */
export function getCategoryType(categoryName) {
  const name = categoryName.toLowerCase();
  
  if (matchesKeywords(name, CATEGORY_KEYWORDS.frtk1)) {
    return 'frtk1';
  } else if (matchesKeywords(name, CATEGORY_KEYWORDS.frtk2)) {
    return 'frtk2';
  } else if (matchesKeywords(name, CATEGORY_KEYWORDS.individual)) {
    return 'individual';
  }
  
  return null;
}
