<script>
export default {
name: "StudentsGradeTable"
}
</script>

<template>
  <div class="students-grade-table-container">
    <!-- Прогресс загрузки -->
    <div v-if="loading" class="progress-loader">
      <div class="progress">
        <div class="progress-bar progress-bar-striped progress-bar-animated" 
             role="progressbar" 
             aria-valuenow="100" 
             aria-valuemin="0" 
             aria-valuemax="100" 
             style="width: 100%">
          {{ langStore.strings.students_table_loading || 'Загрузка данных студентов...' }}
        </div>
      </div>
    </div>

    <!-- Основной контент -->
    <div v-else class="grade-table-content">
      <!-- Заголовок с информацией о курсе -->
      <div class="table-header mb-3">
        <div class="row align-items-center">
          <div class="col-md-8">
            <h5 class="mb-1">{{ langStore.strings.students_grades_title || 'Оценки студентов' }}</h5>
            <div class="d-flex flex-wrap gap-2 align-items-center">
              <small class="text-muted">
                {{ langStore.strings.total_students || 'Всего студентов' }}: {{ totalStudents }}
              </small>
              <small v-if="sortField" class="text-info">
                <i class="fa fa-sort me-1"></i>
                {{ langStore.strings.sorted_by || 'Сортировка:' }} 
                {{ getSortFieldName() }}
                <i class="fa ms-1" :class="getSortIcon(sortField)"></i>
              </small>
            </div>
          </div>
          <div class="col-md-4 text-end">
            <!-- Переключатель режимов и поиск -->
            <div class="table-controls">
              <!-- Поиск студентов -->
              <div class="search-box">
                <input 
                  v-model="searchQuery" 
                  type="text" 
                  class="form-control form-control-sm" 
                  :placeholder="langStore.strings.search_student || 'Поиск студента...'"
                  @input="onSearch">
                <i class="fa fa-search search-icon"></i>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Подсказка для мобильных устройств -->
      <div class="mobile-scroll-hint d-md-none mb-2">
        <small class="text-muted">
          <i class="fa fa-hand-point-right me-1"></i>
          {{ langStore.strings.scroll_horizontally || 'Прокрутите горизонтально для просмотра всех колонок' }}
        </small>
      </div>

      <!-- Таблица оценок -->
      <div class="table-responsive">
        <table class="table table-bordered table-hover">
          <thead class="table-header-sticky">
            <tr>
              <th scope="col" 
                  class="student-column"
                  :class="getSortClass('name')"
                  @click="sortBy('name')">
                <div class="d-flex align-items-center justify-content-between">
                  <span>{{ langStore.strings.student_name || 'Студент' }}</span>
                  <i class="fa" :class="getSortIcon('name')"></i>
                </div>
              </th>
              <th scope="col" 
                  class="grade-column text-center"
                  :class="getSortClass('frtk1')"
                  @click="sortBy('frtk1')">
                <div class="d-flex align-items-center justify-content-center">
                  <span>{{ langStore.strings.gradetable_header_grade1 || 'ФРТК1' }}</span>
                  <i class="fa ms-1" :class="getSortIcon('frtk1')"></i>
                </div>
              </th>
              <th scope="col" 
                  class="grade-column text-center"
                  :class="getSortClass('frtk2')"
                  @click="sortBy('frtk2')">
                <div class="d-flex align-items-center justify-content-center">
                  <span>{{ langStore.strings.gradetable_header_grade2 || 'ФРТК2' }}</span>
                  <i class="fa ms-1" :class="getSortIcon('frtk2')"></i>
                </div>
              </th>
              <th scope="col" 
                  class="grade-column text-center"
                  :class="getSortClass('individual')"
                  @click="sortBy('individual')">
                <div class="d-flex align-items-center justify-content-center">
                  <span class="grade-header-text">
                    <span class="d-none d-md-inline">{{ langStore.strings.gradetable_header_grade3 || 'Индивидуальные достижения' }}</span>
                    <span class="d-md-none">{{ langStore.strings.gradetable_header_grade3_short || 'Инд. достижения' }}</span>
                  </span>
                  <i class="fa ms-1" :class="getSortIcon('individual')"></i>
                </div>
              </th>
              <th scope="col" 
                  class="total-column text-center"
                  :class="getSortClass('total')"
                  @click="sortBy('total')">
                <div class="d-flex align-items-center justify-content-center">
                  <span>{{ langStore.strings.total_grade || 'Итого' }}</span>
                  <i class="fa ms-1" :class="getSortIcon('total')"></i>
                </div>
              </th>
            </tr>
          </thead>
          <tbody>
            <!-- Список студентов -->
            <tr v-for="student in paginatedStudents" 
                  :key="student.id" 
                  class="student-row">
                <td class="student-info">
                  <div class="d-flex align-items-center">
                    <img v-if="student.profileimageurlsmall" 
                         :src="student.profileimageurlsmall" 
                         :alt="student.fullname"
                         class="student-avatar me-2">
                    <i v-else class="fa fa-user-circle text-secondary me-2 student-icon"></i>
                    <div class="flex-grow-1">
                      <div class="student-name">{{ student.fullname }}</div>
                      <small class="text-muted">{{ student.email }}</small>
                    </div>
                    <div class="student-actions ms-2">
                      <StudentReportExport 
                        :student-email="student.email"
                        :student-name="student.fullname"
                      />
                    </div>
                  </div>
                </td>
                <td class="grade-cell text-center">
                  <span class="grade-badge" :class="getGradeClassForStudent(student.grades.frtk1)" v-html="formatGradeWithPercentageForStudent(student.grades.frtk1)">
                  </span>
                </td>
                <td class="grade-cell text-center">
                  <span class="grade-badge" :class="getGradeClassForStudent(student.grades.frtk2)" v-html="formatGradeWithPercentageForStudent(student.grades.frtk2)">
                  </span>
                </td>
                <td class="grade-cell text-center">
                  <span class="grade-badge" :class="getGradeClassForStudent(student.grades.individual)" v-html="formatGradeWithPercentageForStudent(student.grades.individual)">
                  </span>
                </td>
                <td class="total-cell text-center">
                  <span class="total-grade-badge" :class="getTotalGradeClassForStudent(student.grades.total)" v-html="formatGradeWithPercentageForStudent(student.grades.total)">
                  </span>
                </td>
              </tr>
              
              <tr v-if="filteredStudents.length === 0" class="empty-row">
                <td colspan="5" class="text-center text-muted py-4">
                  <i class="fa fa-users fa-2x mb-2"></i><br>
                  {{ searchQuery ? 
                     (langStore.strings.no_students_found || 'Студенты не найдены') :
                     (langStore.strings.no_students || 'Нет данных о студентах') 
                  }}
                </td>
              </tr>


          </tbody>
          
          <!-- Подвал таблицы со средними баллами -->
          <tfoot v-if="filteredStudents.length > 0"
                 class="table-footer">
            <tr class="average-row">
              <td class="average-label">
                <div class="d-flex align-items-center">
                  <i class="fa fa-calculator text-primary me-2"></i>
                  <div>
                    <div class="average-title">
                      {{ langStore.strings.average_grades || 'Средний балл' }}
                    </div>
                    <small class="text-muted">
                      {{ langStore.strings.based_on || 'На основе' }} {{ filteredStudents.length }} 
                      {{ langStore.strings.students || 'студентов' }}
                    </small>
                  </div>
                </div>
              </td>
              <td class="average-cell text-center">
                <span class="average-badge" :class="getGradeClassForStudent(averageGrades.frtk1)" v-html="formatAverageGradeWithContribution(averageGrades.frtk1)">
                </span>
              </td>
              <td class="average-cell text-center">
                <span class="average-badge" :class="getGradeClassForStudent(averageGrades.frtk2)" v-html="formatAverageGradeWithContribution(averageGrades.frtk2)">
                </span>
              </td>
              <td class="average-cell text-center">
                <span class="average-badge" :class="getGradeClassForStudent(averageGrades.individual)" v-html="formatAverageGradeWithContribution(averageGrades.individual)">
                </span>
              </td>
              <td class="average-cell text-center">
                <span class="average-total-badge" :class="getTotalGradeClassForStudent(averageGrades.total)" v-html="formatAverageGradeWithContribution(averageGrades.total)">
                </span>
              </td>
            </tr>
          </tfoot>
        </table>
      </div>



      <!-- Пагинация -->
      <div v-if="totalPages > 1" class="pagination-container">
        <nav aria-label="Students pagination">
          <ul class="pagination pagination-sm justify-content-center">
            <li class="page-item" :class="{ disabled: currentPage === 1 }">
              <button class="page-link" @click="goToPage(1)" :disabled="currentPage === 1">
                <i class="fa fa-angle-double-left"></i>
              </button>
            </li>
            <li class="page-item" :class="{ disabled: currentPage === 1 }">
              <button class="page-link" @click="goToPage(currentPage - 1)" :disabled="currentPage === 1">
                <i class="fa fa-angle-left"></i>
              </button>
            </li>
            
            <li v-for="page in visiblePages" 
                :key="page" 
                class="page-item" 
                :class="{ active: page === currentPage }">
              <button class="page-link" @click="goToPage(page)">
                {{ page }}
              </button>
            </li>
            
            <li class="page-item" :class="{ disabled: currentPage === totalPages }">
              <button class="page-link" @click="goToPage(currentPage + 1)" :disabled="currentPage === totalPages">
                <i class="fa fa-angle-right"></i>
              </button>
            </li>
            <li class="page-item" :class="{ disabled: currentPage === totalPages }">
              <button class="page-link" @click="goToPage(totalPages)" :disabled="currentPage === totalPages">
                <i class="fa fa-angle-double-right"></i>
              </button>
            </li>
          </ul>
        </nav>
        
        <!-- Информация о пагинации -->
        <div class="pagination-info text-center mt-2">
          <small class="text-muted">
            {{ langStore.strings.showing || 'Показано' }} 
            {{ startIndex + 1 }}-{{ Math.min(endIndex, filteredStudents.length) }} 
            {{ langStore.strings.of || 'из' }} 
            {{ filteredStudents.length }} 
            {{ langStore.strings.students || 'студентов' }}
          </small>
          <br>
          <small class="text-info mt-1">
            <i class="fa fa-info-circle me-1"></i>
            {{ langStore.strings.averages_note || 'Средние баллы рассчитаны для всех студентов в списке' }}
          </small>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch, nextTick } from 'vue';
import { useGeneralStore } from '../store/storeGeneral';
import { useLangStore } from '../store/storeLang';
import StudentReportExport from './StudentReportExport.vue';
import { formatGradeWithPercentage, getMaxGradeFromScale, getGradeClass, getTotalGradeClass, formatGradeWithContribution } from '../utils/gradeFormatting';
import { CATEGORY_KEYWORDS, getCategoryType } from '../store/constants';

const generalStore = useGeneralStore();
const langStore = useLangStore();

const props = defineProps({
  courseId: {
    type: [String, Number],
    default: null
  },
  studentsPerPage: {
    type: Number,
    default: 10
  }
});

// Состояние компонента
const loading = ref(true);
const searchQuery = ref('');
const currentPage = ref(1);

// Состояние сортировки
const sortField = ref('');
const sortDirection = ref('asc'); // 'asc' или 'desc'


// Получение данных о студентах из store
const courseData = computed(() => {
  if (!props.courseId) {
    // Если courseId не передан, берем первый доступный курс
    return generalStore.userCourses[0] || null;
  }
  
  return generalStore.userCourses.find(item => item.course.id == props.courseId);
});

const allStudents = computed(() => {
  if (!courseData.value?.course?.user_grades?.usergrades) {
    return [];
  }

  return courseData.value.course.user_grades.usergrades.map(usergrade => {
    const student = courseData.value.course.enrolled_users?.find(user => user.id === usergrade.userid) || {};
    
    // Парсим оценки из gradeitems
    const gradeData = parseStudentGrades(usergrade.gradeitems || []);
    
    // Отладочная информация (можно убрать в продакшене)
    if (process.env.NODE_ENV === 'development') {
      // Отладочная информация удалена
    }
    
    return {
      id: usergrade.userid,
      fullname: usergrade.userfullname,
      email: student.email || '',
      profileimageurlsmall: student.profileimageurlsmall || '',
      grades: gradeData.grades,
      gradeItems: gradeData.gradeItems,
      totalWeight: gradeData.totalWeight
    };
  });
});

// Функция для парсинга оценок студента только по категориям ФРТК
function parseStudentGrades(gradeitems) {
  const grades = {
    frtk1: null,    // ФРТК1 - основная категория
    frtk2: null,    // ФРТК2 - дополнительная категория  
    individual: null, // Индивидуальные достижения
    total: null     // Итоговая оценка курса
  };

  const gradeItems = {
    frtk1: null,
    frtk2: null,
    individual: null,
    total: null
  };

  // Используем константы из store
  const categoryKeywords = CATEGORY_KEYWORDS;

  // Собираем только категории
  const categories = {};
  let totalWeight = 0;
  
  gradeitems.forEach(item => {
    if (item.itemtype === 'category') {
      categories[item.id] = {
        id: item.id,
        name: item.itemname || '',
        gradeValue: item.gradeformatted || item.graderaw,
        weight: item.weightraw,
        instance: item.iteminstance
      };
      
      // Суммируем общий вес
      if (item.weightraw) {
        totalWeight += parseFloat(item.weightraw);
      }
    } else if (item.itemtype === 'course') {
      // Итоговая оценка курса
      grades.total = item.gradeformatted || item.graderaw;
      gradeItems.total = {
        weight: item.weightraw || 0,
        maxGrade: item.grademax || 100
      };
    }
  });

  // Сортируем категории по весу
  const categoryKeys = Object.keys(categories);
  const sortedCategories = categoryKeys.sort((a, b) => {
    const catA = categories[a];
    const catB = categories[b];
    
    // Сортируем по весу (weightraw) - обычно ФРТК1 имеет больший вес
    if (catA.weight !== undefined && catB.weight !== undefined) {
      return catB.weight - catA.weight;
    }
    
    // Если весов нет, сортируем по id
    return parseInt(a) - parseInt(b);
  });

  if (process.env.NODE_ENV === 'development') {
    // Отладочная информация удалена
  }


  // Обрабатываем каждую категорию
  sortedCategories.forEach((categoryId, index) => {
    const category = categories[categoryId];
    
    // Определяем тип категории используя функцию из store
    const categoryType = getCategoryType(category.name);
    
    // Назначаем оценку
    if (categoryType && category.gradeValue !== null && category.gradeValue !== undefined) {
      grades[categoryType] = category.gradeValue;
      gradeItems[categoryType] = {
        weight: category.weight || 0,
        maxGrade: category.maxGrade || 100
      };
      
      if (process.env.NODE_ENV === 'development') {
        // Отладочная информация удалена
      }
    }
  });

  // Возвращаем и оценки, и информацию о весах
  return {
    grades: grades,
    gradeItems: gradeItems,
    totalWeight: totalWeight
  };
}

// Поиск и фильтрация
const filteredStudents = computed(() => {
  let students = allStudents.value;

  // Применяем поиск
  if (searchQuery.value.trim()) {
    const query = searchQuery.value.toLowerCase().trim();
    students = students.filter(student => 
      student.fullname.toLowerCase().includes(query) ||
      student.email.toLowerCase().includes(query)
    );
  }

  // Применяем сортировку
  if (sortField.value) {
    students = [...students].sort((a, b) => {
      let valueA, valueB;

      if (sortField.value === 'name') {
        valueA = a.fullname.toLowerCase();
        valueB = b.fullname.toLowerCase();
      } else if (sortField.value === 'email') {
        valueA = a.email.toLowerCase();
        valueB = b.email.toLowerCase();
      } else {
        // Сортировка по оценкам
        valueA = a.grades[sortField.value];
        valueB = b.grades[sortField.value];
        
        // Обрабатываем null/undefined значения - ставим их в конец
        if (valueA === null || valueA === undefined) valueA = -999;
        if (valueB === null || valueB === undefined) valueB = -999;
        
        valueA = parseFloat(valueA) || -999;
        valueB = parseFloat(valueB) || -999;
      }

      if (sortDirection.value === 'asc') {
        return valueA < valueB ? -1 : valueA > valueB ? 1 : 0;
      } else {
        return valueA > valueB ? -1 : valueA < valueB ? 1 : 0;
      }
    });
  }

  return students;
});

// Вычисление средних баллов
const averageGrades = computed(() => {
  if (filteredStudents.value.length === 0) {
    return {
      frtk1: null,
      frtk2: null,
      individual: null,
      total: null
    };
  }

  const sums = {
    frtk1: { total: 0, count: 0 },
    frtk2: { total: 0, count: 0 },
    individual: { total: 0, count: 0 },
    total: { total: 0, count: 0 }
  };

  let totalWeightSum = 0;
  let totalWeightCount = 0;

  filteredStudents.value.forEach(student => {
    Object.keys(sums).forEach(gradeType => {
      const grade = student.grades[gradeType];
      if (grade !== null && grade !== undefined && !isNaN(grade)) {
        sums[gradeType].total += parseFloat(grade);
        sums[gradeType].count++;
      }
    });
    
    // Суммируем общие веса для вычисления среднего
    if (student.totalWeight) {
      totalWeightSum += student.totalWeight;
      totalWeightCount++;
    }
  });

  return {
    frtk1: sums.frtk1.count > 0 ? sums.frtk1.total / sums.frtk1.count : null,
    frtk2: sums.frtk2.count > 0 ? sums.frtk2.total / sums.frtk2.count : null,
    individual: sums.individual.count > 0 ? sums.individual.total / sums.individual.count : null,
    total: sums.total.count > 0 ? sums.total.total / sums.total.count : null,
    averageTotalWeight: totalWeightCount > 0 ? totalWeightSum / totalWeightCount : 0
  };
});

// Пагинация
const totalStudents = computed(() => filteredStudents.value.length);
const totalPages = computed(() => Math.ceil(totalStudents.value / props.studentsPerPage));

const startIndex = computed(() => (currentPage.value - 1) * props.studentsPerPage);
const endIndex = computed(() => startIndex.value + props.studentsPerPage);

const paginatedStudents = computed(() => {
  return filteredStudents.value.slice(startIndex.value, endIndex.value);
});

// Видимые страницы для пагинации
const visiblePages = computed(() => {
  const pages = [];
  const maxVisiblePages = 5;
  let start = Math.max(1, currentPage.value - Math.floor(maxVisiblePages / 2));
  let end = Math.min(totalPages.value, start + maxVisiblePages - 1);

  if (end - start < maxVisiblePages - 1) {
    start = Math.max(1, end - maxVisiblePages + 1);
  }

  for (let i = start; i <= end; i++) {
    pages.push(i);
  }

  return pages;
});

// Методы компонента
function goToPage(page) {
  if (page >= 1 && page <= totalPages.value) {
    currentPage.value = page;
  }
}

function onSearch() {
  currentPage.value = 1; // Сбрасываем на первую страницу при поиске
}

function sortBy(field) {
  if (sortField.value === field) {
    // Если кликнули по тому же полю, меняем направление
    sortDirection.value = sortDirection.value === 'asc' ? 'desc' : 'asc';
  } else {
    // Если новое поле, сортируем по возрастанию
    sortField.value = field;
    sortDirection.value = 'asc';
  }
  currentPage.value = 1; // Сбрасываем на первую страницу при сортировке
}

function getSortIcon(field) {
  if (sortField.value !== field) {
    return 'fa-sort'; // Иконка сортировки по умолчанию
  }
  return sortDirection.value === 'asc' ? 'fa-sort-up' : 'fa-sort-down';
}

function getSortClass(field) {
  return {
    'sortable': true,
    'sorted': sortField.value === field,
    'sorted-asc': sortField.value === field && sortDirection.value === 'asc',
    'sorted-desc': sortField.value === field && sortDirection.value === 'desc'
  };
}

function getSortFieldName() {
  const fieldNames = {
    'name': langStore.strings.student_name || 'Имени',
    'email': 'Email',
    'frtk1': langStore.strings.gradetable_header_grade1 || 'ФРТК1',
    'frtk2': langStore.strings.gradetable_header_grade2 || 'ФРТК2',
    'individual': langStore.strings.gradetable_header_grade3_short || 'Инд. достижениям',
    'total': langStore.strings.total_grade || 'Итого'
  };
  return fieldNames[sortField.value] || sortField.value;
}

function formatGrade(grade) {
  if (grade === null || grade === undefined) {
    return '-';
  }
  
  const numGrade = parseFloat(grade);
  if (isNaN(numGrade)) {
    return grade.toString();
  }
  
  return numGrade.toFixed(2);
}

// Функция для форматирования оценки - разделяет оценку и процент на разные строки
function formatGradeWithPercentageForStudent(grade) {
  if (grade === null || grade === undefined) {
    return '-';
  }
  
  const gradeStr = grade.toString();
  
  // Если есть скобки с процентом, разделяем на две строки
  const match = gradeStr.match(/^(.+?)\s*\((.+?)\)$/);
  if (match) {
    const mainGrade = match[1].trim();
    const percentage = `(${match[2]})`;
    return `${mainGrade}<br><small class="grade-percentage">${percentage}</small>`;
  }
  
  // Если нет скобок, возвращаем как есть
  return gradeStr;
}

// Функция для форматирования средних оценок - разделяет оценку и процент на разные строки
function formatAverageGradeWithContribution(grade) {
  if (grade === null || grade === undefined) {
    return '-';
  }
  
  const gradeStr = grade.toString();
  
  // Если есть скобки с процентом, разделяем на две строки
  const match = gradeStr.match(/^(.+?)\s*\((.+?)\)$/);
  if (match) {
    const mainGrade = match[1].trim();
    const percentage = `(${match[2]})`;
    return `${mainGrade}<br><small class="grade-percentage">${percentage}</small>`;
  }
  
  // Если нет скобок, возвращаем как есть
  return gradeStr;
}

function getGradeClassForStudent(grade) {
  if (grade === null || grade === undefined) {
    return 'grade-empty';
  }
  
  // Если это строка, пытаемся извлечь числовое значение для определения класса
  let numGrade;
  if (typeof grade === 'string') {
    // Извлекаем число из строки (может быть "85.50", "85%", "85.50%" и т.д.)
    const match = grade.match(/(\d+(?:\.\d+)?)/);
    numGrade = match ? parseFloat(match[1]) : 0;
  } else {
    numGrade = parseFloat(grade);
  }
  
  if (isNaN(numGrade)) {
    return 'grade-empty';
  }
  
  // Используем стандартную максимальную оценку 100 для определения класса
  const maxGrade = 100;
  return getGradeClass(numGrade, maxGrade);
}

function getTotalGradeClassForStudent(grade) {
  if (grade === null || grade === undefined) {
    return 'total-grade-empty';
  }
  
  // Если это строка, пытаемся извлечь числовое значение для определения класса
  let numGrade;
  if (typeof grade === 'string') {
    // Извлекаем число из строки (может быть "85.50", "85%", "85.50%" и т.д.)
    const match = grade.match(/(\d+(?:\.\d+)?)/);
    numGrade = match ? parseFloat(match[1]) : 0;
  } else {
    numGrade = parseFloat(grade);
  }
  
  if (isNaN(numGrade)) {
    return 'total-grade-empty';
  }
  
  // Используем стандартную максимальную оценку 100 для определения класса
  const maxGrade = 100;
  return getTotalGradeClass(numGrade, maxGrade);
}

function formatAverageGrade(grade) {
  if (grade === null || grade === undefined) {
    return '-';
  }
  return typeof grade === 'number' ? grade.toFixed(1) : grade.toString();
}

function getAverageGradeClass(grade) {
  if (grade === null || grade === undefined) {
    return 'average-grade-empty';
  }
  
  const numGrade = parseFloat(grade);
  if (numGrade >= 8) return 'average-grade-excellent';
  if (numGrade >= 6) return 'average-grade-good';
  if (numGrade >= 4) return 'average-grade-satisfactory';
  return 'average-grade-poor';
}

function getAverageTotalGradeClass(grade) {
  if (grade === null || grade === undefined) {
    return 'average-total-grade-empty';
  }
  
  const numGrade = parseFloat(grade);
  if (numGrade >= 80) return 'average-total-grade-excellent';
  if (numGrade >= 60) return 'average-total-grade-good';
  if (numGrade >= 40) return 'average-total-grade-satisfactory';
  return 'average-total-grade-poor';
}



// Следим за изменением поискового запроса
watch(searchQuery, () => {
  currentPage.value = 1;
});

// Следим за изменением courseId
watch(() => props.courseId, () => {
  currentPage.value = 1;
  searchQuery.value = '';
  // Сбрасываем сортировку при смене курса
  sortField.value = '';
  sortDirection.value = 'asc';
});



// Инициализация компонента
onMounted(async () => {
  await nextTick();
  loading.value = false;
});
</script>

<style scoped>
@import '../styles/table-footer.css';
.students-grade-table-container {
  position: relative;
  width: 100%;
  margin: 0 auto;
  padding: 1rem;
}

/* Прогресс-бар */
.progress-loader {
  padding: 2rem 1rem;
}

.progress {
  height: 1.5rem;
  background-color: #e9ecef;
  border-radius: 0.5rem;
  overflow: hidden;
}

.progress-bar {
  background-color: #007bff;
  color: white;
  font-size: 0.875rem;
  font-weight: 500;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* Заголовок таблицы */
.table-header h5 {
  color: #333;
  font-weight: 600;
}

.search-box {
  position: relative;
  max-width: 250px;
  margin-left: auto;
}

.search-box input {
  padding-right: 2.5rem;
}

.search-icon {
  position: absolute;
  right: 0.75rem;
  top: 50%;
  transform: translateY(-50%);
  color: #6c757d;
  pointer-events: none;
}

/* Подсказка для мобильных устройств */
.mobile-scroll-hint {
  text-align: center;
  padding: 0.5rem;
  background-color: #f8f9fa;
  border-radius: 0.25rem;
  border-left: 3px solid #007bff;
}

/* Таблица */
.table-responsive {
  border-radius: 0.5rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  overflow-x: auto;
  overflow-y: visible;
  -webkit-overflow-scrolling: touch;
  max-width: 100%;
  position: relative;
  /* Позволяем выпадающим меню выходить за границы */
  contain: none;
  overflow-clip-margin: 0;
}

/* Убеждаемся, что таблица не обрезает выпадающие меню */
.table {
  position: relative;
  overflow: visible !important;
}

.table tbody {
  overflow: visible !important;
}

.table tbody tr {
  position: relative;
  overflow: visible !important;
}

.table td {
  overflow: visible !important;
}

/* Улучшенный скролл-бар */
.table-responsive::-webkit-scrollbar {
  height: 8px;
}

.table-responsive::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 4px;
}

.table-responsive::-webkit-scrollbar-thumb {
  background: #888;
  border-radius: 4px;
}

.table-responsive::-webkit-scrollbar-thumb:hover {
  background: #555;
}

.table {
  margin-bottom: 0;
  font-size: 0.9rem;
  min-width: 600px; /* Минимальная ширина таблицы */
  table-layout: auto;
  white-space: nowrap;
}

.table-header-sticky {
  background-color: #f8f9fa;
  position: sticky;
  top: 0;
  z-index: 10;
}

.table th {
  border-bottom: 2px solid #dee2e6;
  font-weight: 600;
  padding: 0.75rem 0.5rem;
  vertical-align: middle;
  line-height: 1.2;
  height: auto;
  min-height: 60px;
  position: relative;
}

/* Стили для сортировки */
.table th.sortable {
  cursor: pointer;
  user-select: none;
  transition: background-color 0.2s ease;
}

.table th.sortable:hover {
  background-color: #e9ecef;
}

.table th.sorted {
  background-color: #e3f2fd;
}

.table th.sorted:hover {
  background-color: #bbdefb;
}

.table th .fa {
  font-size: 0.8rem;
  opacity: 0.6;
  transition: opacity 0.2s ease;
}

.table th.sortable:hover .fa {
  opacity: 1;
}

.table th.sorted .fa {
  opacity: 1;
  color: #007bff;
}

.table th.student-column {
  white-space: nowrap; /* Только для колонки студента оставляем без переносов */
}

.table th.grade-column, .table th.total-column {
  white-space: normal; /* Разрешаем переносы для колонок с оценками */
  word-wrap: break-word;
  hyphens: auto;
}

.grade-header-text {
  display: inline-block;
  line-height: 1.2;
  word-break: break-word;
  text-align: center;
  width: 100%;
}

/* Дополнительные стили для лучших переносов */
.table th.grade-column {
  word-break: break-word;
  overflow-wrap: break-word;
  hyphens: auto;
  -webkit-hyphens: auto;
  -ms-hyphens: auto;
}

/* Специальные правила для русского языка */
.table th.grade-column:lang(ru) {
  word-break: keep-all;
  overflow-wrap: break-word;
}

.table td {
  padding: 0.75rem 0.5rem;
  vertical-align: middle;
  border-bottom: 1px solid #dee2e6;
}

/* Колонки */
.student-column {
  width: 40%;
  min-width: 180px;
  max-width: 250px;
}

.grade-column {
  width: 15%;
  min-width: 80px;
  max-width: 120px;
}

.total-column {
  width: 15%;
  min-width: 80px;
  max-width: 120px;
}

/* Информация о студенте */
.student-info {
  max-width: 300px;
  overflow: hidden;
}

.student-info .d-flex {
  align-items: center;
  min-width: 0; /* Позволяет flex элементам сжиматься */
}

.student-info .flex-grow-1 {
  min-width: 0; /* Позволяет тексту обрезаться */
  flex: 1;
}

.student-actions {
  flex-shrink: 0;
  position: relative;
  z-index: 1;
}

/* Увеличиваем z-index для строки с открытым dropdown */
.table tbody tr:has(.dropdown.show) {
  z-index: 1050 !important;
  position: relative;
}

/* Убеждаемся, что ячейка таблицы не обрезает выпадающее меню Bootstrap */
.table td:has(.student-actions),
.table td .student-actions {
  overflow: visible !important;
  position: relative;
  z-index: 1;
}

/* Когда dropdown открыт, увеличиваем z-index */
.table td:has(.dropdown.show),
.table td .dropdown.show {
  z-index: 1050 !important;
  position: relative;
}

/* Убеждаемся, что строка таблицы не обрезает меню */
.table tbody tr:has(.student-actions),
.table tbody tr .student-actions {
  overflow: visible !important;
}

.student-avatar {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  object-fit: cover;
  flex-shrink: 0;
}

.student-icon {
  font-size: 1.25rem;
  flex-shrink: 0;
}

.student-name {
  font-weight: 500;
  color: #333;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  line-height: 1.2;
}

.student-info small {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 0.75rem;
}

/* Оценки */
.grade-badge, .total-grade-badge {
  display: inline-block;
  padding: 0.25rem 0.5rem;
  border-radius: 0.25rem;
  font-weight: 500;
  min-width: 50px;
  line-height: 1.2;
  vertical-align: middle;
}

/* Стили для многострочного отображения оценок */
.grade-percentage {
  font-size: 0.75rem;
  opacity: 0.8;
  font-weight: 400;
  display: block;
  margin-top: 2px;
}

/* Увеличиваем высоту ячеек для многострочного контента */
.grade-cell,
.total-cell,
.average-cell {
  min-height: 60px;
  vertical-align: middle;
}

/* Адаптивные стили для мобильных устройств */
@media (max-width: 768px) {
  .grade-percentage {
    font-size: 0.7rem;
  }
  
  .grade-cell,
  .total-cell,
  .average-cell {
    min-height: 50px;
  }
}

@media (max-width: 576px) {
  .grade-percentage {
    font-size: 0.65rem;
  }
  
  .grade-cell,
  .total-cell,
  .average-cell {
    min-height: 45px;
  }
}

.grade-empty, .total-grade-empty {
  background-color: #f8f9fa;
  color: #6c757d;
  border: 1px solid #dee2e6;
}

.grade-excellent {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.grade-good {
  background-color: #d1ecf1;
  color: #0c5460;
  border: 1px solid #bee5eb;
}

.grade-satisfactory {
  background-color: #fff3cd;
  color: #856404;
  border: 1px solid #ffeaa7;
}

.grade-poor {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}

.total-grade-excellent {
  background-color: #28a745;
  color: white;
}

.total-grade-good {
  background-color: #17a2b8;
  color: white;
}

.total-grade-satisfactory {
  background-color: #ffc107;
  color: #212529;
}

.total-grade-poor {
  background-color: #dc3545;
  color: white;
}

/* Строки таблицы */
.student-row:hover {
  background-color: #f8f9fa;
}



.empty-row td {
  padding: 3rem 1rem;
}

/* Контролы таблицы */
.table-controls {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  align-items: flex-end;
}





.info-metric {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.25rem;
}

.metric-value {
  font-size: 1.25rem;
  font-weight: 700;
  color: #333;
}

.metric-label {
  font-size: 0.7rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  font-weight: 600;
}

/* Специфичные стили только для StudentsGradeTable */
tfoot .average-row {
  border-top: none; /* Убираем границу, так как она уже есть у tfoot */
}

/* Пагинация */
.pagination-container {
  margin-top: 1.5rem;
}

.pagination .page-link {
  color: #007bff;
  border-color: #dee2e6;
  padding: 0.375rem 0.75rem;
}

.pagination .page-link:hover {
  color: #0056b3;
  background-color: #e9ecef;
  border-color: #dee2e6;
}

.pagination .page-item.active .page-link {
  background-color: #007bff;
  border-color: #007bff;
  color: white;
}

.pagination .page-item.disabled .page-link {
  color: #6c757d;
  background-color: #fff;
  border-color: #dee2e6;
  cursor: not-allowed;
}

.pagination-info {
  margin-top: 0.5rem;
}

/* Анимация появления */
.grade-table-content {
  animation: fadeIn 0.3s ease-in-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Адаптивность */
@media (max-width: 992px) {
  .students-grade-table-container {
    padding: 0.75rem;
  }
  
  .table {
    min-width: 550px;
  }
  
  .student-column {
    min-width: 160px;
  }
  
  .grade-column, .total-column {
    min-width: 75px;
  }
}

@media (max-width: 768px) {
  .students-grade-table-container {
    padding: 0.5rem;
  }
  
  .table {
    font-size: 0.8rem;
    min-width: 500px;
  }
  
  .table th, .table td {
    padding: 0.5rem 0.375rem;
  }
  
  .table th {
    min-height: 50px;
    font-size: 0.8rem;
  }
  
  .student-column {
    min-width: 140px;
    width: 45%;
  }
  
  .grade-column, .total-column {
    min-width: 70px;
    width: 13.75%;
  }
  
  .student-avatar {
    width: 24px;
    height: 24px;
  }
  
  .student-icon {
    font-size: 1rem;
  }
  
  .search-box {
    max-width: 180px;
  }
  
  .table-header .row {
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .table-header .col-md-4 {
    text-align: start !important;
  }
  
  /* Адаптивность для сортировки */
  .table th .fa {
    font-size: 0.7rem;
  }
  
  .table th .d-flex {
    gap: 0.25rem;
  }
  

  
  /* Адаптивность для контролов */
  .table-controls {
    align-items: stretch;
  }
  

  

  
  .metric-value {
    font-size: 1rem;
  }
  
  .metric-label {
    font-size: 0.65rem;
  }
}

@media (max-width: 576px) {
  .students-grade-table-container {
    padding: 0.25rem;
  }
  
  .table {
    font-size: 0.75rem;
    min-width: 450px;
  }
  
  .table th, .table td {
    padding: 0.375rem 0.25rem;
  }
  
  .table th {
    min-height: 45px;
    font-size: 0.7rem;
    line-height: 1.1;
  }
  
  .student-column {
    min-width: 120px;
    width: 50%;
  }
  
  .grade-column, .total-column {
    min-width: 60px;
    width: 12.5%;
  }
  
  .grade-badge, .total-grade-badge {
    padding: 0.125rem 0.25rem;
    font-size: 0.7rem;
    min-width: 35px;
  }
  
  .student-avatar {
    width: 20px;
    height: 20px;
  }
  
  .student-icon {
    font-size: 0.9rem;
  }
  
  .student-name {
    font-size: 0.8rem;
  }
  
  .student-info small {
    font-size: 0.65rem;
  }
  
  .search-box {
    max-width: 150px;
  }
  
  .pagination .page-link {
    padding: 0.25rem 0.5rem;
    font-size: 0.8rem;
  }
  
  /* Адаптивность для сортировки на маленьких экранах */
  .table th .fa {
    font-size: 0.65rem;
  }
  
  .table th .d-flex {
    gap: 0.125rem;
  }
  

  
  /* Адаптивность для контролов на маленьких экранах */

  

}
</style>