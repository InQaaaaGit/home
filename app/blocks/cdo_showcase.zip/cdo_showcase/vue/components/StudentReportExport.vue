<template>
  <div class="student-report-export">
    <div class="dropdown">
      <button 
        ref="dropdownButtonRef"
        class="btn btn-outline-secondary btn-sm dropdown-toggle"
        type="button"
        :id="'dropdownMenuButton' + _uid"
        data-toggle="dropdown"
        aria-haspopup="true"
        aria-expanded="false"
        :disabled="loading || !canExport"
        :title="exportTooltip"
      >
        <i class="fa fa-ellipsis-v"></i>
      </button>
      <div 
        class="dropdown-menu dropdown-menu-right"
        :aria-labelledby="'dropdownMenuButton' + _uid"
        style="z-index: 9999 !important;"
      >
        <a 
          class="dropdown-item"
          href="#"
          @click.prevent="handleExportClick"
          :class="{ 'disabled': loading || !canExport }"
        >
          <i v-if="!loading" class="fa fa-file-excel-o me-2"></i>
          <span v-if="loading" class="export-loader-dots me-2">
            <span class="dot"></span>
            <span class="dot"></span>
            <span class="dot"></span>
          </span>
          <span v-if="loading">
            {{ langStore.strings.preparing_report || 'Подготовка отчета...' }}
          </span>
          <span v-else>
            {{ langStore.strings.export_student_report || 'Выгрузить отчет студента' }}
          </span>
        </a>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, getCurrentInstance } from 'vue';
import { useGeneralStore } from '../store/storeGeneral';
import { useLangStore } from '../store/storeLang';
import { exportStudentReport } from '../utils/excelExport';
import notification from 'core/notification';
import { CATEGORY_KEYWORDS, getCategoryType } from '../store/constants';

const generalStore = useGeneralStore();
const langStore = useLangStore();
const instance = getCurrentInstance();

const props = defineProps({
  studentEmail: {
    type: String,
    required: true
  },
  studentName: {
    type: String,
    required: true
  }
});

const loading = ref(false);
const dropdownButtonRef = ref(null);

// Получаем уникальный ID для компонента
const _uid = instance ? instance.uid : Math.random().toString(36).substr(2, 9);

// Обработчик клика на экспорт в выпадающем меню
const handleExportClick = async () => {
  // Закрываем Bootstrap dropdown через jQuery (если доступен)
  if (typeof $ !== 'undefined' && dropdownButtonRef.value) {
    $(dropdownButtonRef.value).dropdown('hide');
  }
  await exportReport();
};

// Функция для извлечения числового значения из оценки (может быть строкой или числом)
function extractNumericGrade(grade) {
  if (grade === null || grade === undefined) {
    return null;
  }
  
  if (typeof grade === 'number') {
    return grade;
  }
  
  // Извлекаем число из строки (может быть "85.50", "85%", "85.50 (90%)" и т.д.)
  const match = grade.toString().match(/(\d+(?:\.\d+)?)/);
  return match ? parseFloat(match[1]) : null;
}

// Функция для парсинга оценок студента - точно такая же как в StudentsGradeTable
function parseStudentGrades(gradeitems) {
  const grades = {
    frtk1: null,    // ФРТК1 - основная категория
    frtk2: null,    // ФРТК2 - дополнительная категория  
    individual: null, // Индивидуальные достижения
    total: null     // Итоговая оценка курса
  };

  const gradeItems = {
    frtk1: null,
    frtk2: null,
    individual: null,
    total: null
  };

  // Используем константы из store
  const categoryKeywords = CATEGORY_KEYWORDS;

  // Собираем только категории
  const categories = {};
  let totalWeight = 0;
  
  gradeitems.forEach(item => {
    if (item.itemtype === 'category') {
      categories[item.id] = {
        id: item.id,
        name: item.itemname || '',
        gradeValue: item.gradeformatted, // Используем только gradeformatted для отчета
        weight: item.weightraw,
        instance: item.iteminstance
      };
      
      // Суммируем общий вес
      if (item.weightraw) {
        totalWeight += parseFloat(item.weightraw);
      }
    } else if (item.itemtype === 'course') {
      // Итоговая оценка курса - используем только gradeformatted
      grades.total = item.gradeformatted;
      gradeItems.total = {
        weight: item.weightraw || 0,
        maxGrade: item.grademax || 100
      };
    }
  });

  // Сортируем категории по весу
  const categoryKeys = Object.keys(categories);
  const sortedCategories = categoryKeys.sort((a, b) => {
    const catA = categories[a];
    const catB = categories[b];
    
    // Сортируем по весу (weightraw) - обычно ФРТК1 имеет больший вес
    if (catA.weight !== undefined && catB.weight !== undefined) {
      return catB.weight - catA.weight;
    }
    
    // Если весов нет, сортируем по id
    return parseInt(a) - parseInt(b);
  });

  // Обрабатываем каждую категорию
  sortedCategories.forEach((categoryId, index) => {
    const category = categories[categoryId];
    
    // Определяем тип категории используя функцию из store
    const categoryType = getCategoryType(category.name);
    
    // Назначаем оценку
    if (categoryType && category.gradeValue !== null && category.gradeValue !== undefined) {
      grades[categoryType] = category.gradeValue;
      gradeItems[categoryType] = {
        weight: category.weight || 0,
        maxGrade: category.maxGrade || 100
      };
    }
  });

  // Возвращаем и оценки, и информацию о весах - точно так же как в StudentsGradeTable
  return {
    grades: grades,
    gradeItems: gradeItems,
    totalWeight: totalWeight
  };
}

// Подготавливаем данные для отчета
const prepareReportData = () => {
  if (!generalStore.userCourses || generalStore.userCourses.length === 0) {
    return [];
  }

  const reportData = [];

  // Проходим по всем курсам
  generalStore.userCourses.forEach((courseItem, courseIndex) => {
    const course = courseItem.course;
    
    if (!course.user_grades?.usergrades) {
      return;
    }

    // Ищем оценки конкретного студента
    const studentGrades = course.user_grades.usergrades.find(
      usergrade => {
        const studentData = course.enrolled_users?.find(user => user.id === usergrade.userid);
        return studentData?.email === props.studentEmail;
      }
    );

    if (studentGrades) {
      // Используем ту же логику парсинга, что и в StudentsGradeTable
      const gradeData = parseStudentGrades(studentGrades.gradeitems || []);
      const grades = gradeData.grades; // Извлекаем оценки из объекта gradeData
      
      // Вычисляем средний балл всех студентов за дисциплину (как в exportRopReportHandler)
      // Это среднее от итоговых оценок всех студентов в курсе
      const allStudents = course.user_grades?.usergrades || [];
      const validStudentsWithGrades = allStudents.map(usergrade => {
        const gradeItem = usergrade.gradeitems?.find(item => item.itemtype === 'course');
        return gradeItem ? gradeItem.graderaw : null;
      }).filter(grade => grade !== null && grade !== undefined && !isNaN(grade));
      
      const averageGrade = validStudentsWithGrades.length > 0
        ? (validStudentsWithGrades.reduce((sum, grade) => sum + parseFloat(grade), 0) / validStudentsWithGrades.length).toFixed(2)
        : null;

      const reportRow = {
        course_name: course.fullname,
        frtk1: grades.frtk1 !== null && grades.frtk1 !== undefined ? grades.frtk1 : null,
        frtk2: grades.frtk2 !== null && grades.frtk2 !== undefined ? grades.frtk2 : null,
        individual: grades.individual !== null && grades.individual !== undefined ? grades.individual : null,
        final_grade: grades.total !== null && grades.total !== undefined ? grades.total : null,
        average_grade: averageGrade,
        scale: course.scale || null
      };
      
      reportData.push(reportRow);
    }
  });

  return reportData;
};

// Проверяем, можно ли экспортировать отчет
const canExport = computed(() => {
  return generalStore.userCourses && generalStore.userCourses.length > 0;
});

// Подсказка для кнопки
const exportTooltip = computed(() => {
  if (!canExport.value) {
    return langStore.strings.no_data_for_export || 'Нет данных для экспорта';
  }
  return langStore.strings.export_student_report_tooltip || 'Выгрузить отчет студента в Excel';
});

// Экспорт отчета
const exportReport = async () => {
  if (!canExport.value) {
    await notification.addNotification({
      message: langStore.strings.no_data_for_export || 'Нет данных для экспорта',
      type: 'warning'
    });
    return;
  }

  loading.value = true;

  try {
    const reportData = prepareReportData();
    
    if (reportData.length === 0) {
      await notification.addNotification({
        message: langStore.strings.no_grades_found || 'Не найдено оценок для данного студента',
        type: 'warning'
      });
      return;
    }

    const success = exportStudentReport(
      reportData, 
      props.studentName, 
      props.studentEmail
    );

    if (success) {
      await notification.addNotification({
        message: langStore.strings.report_exported_successfully || 'Отчет успешно выгружен',
        type: 'success'
      });
    } else {
      throw new Error('Failed to export report');
    }
  } catch (error) {
    // Ошибка при экспорте отчета
    await notification.addNotification({
      message: langStore.strings.export_error || 'Ошибка при выгрузке отчета',
      type: 'error'
    });
  } finally {
    loading.value = false;
  }
};
</script>

<style scoped>
.student-report-export {
  display: inline-block;
  position: relative;
  z-index: 1000;
}

/* Стили для кнопки dropdown Bootstrap */
.student-report-export .dropdown-toggle {
  padding: 0.25rem 0.375rem;
  min-width: 24px;
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none !important;
  background: transparent !important;
  box-shadow: none !important;
}

.student-report-export .dropdown-toggle:hover,
.student-report-export .dropdown-toggle:focus,
.student-report-export .dropdown-toggle:active {
  border: none !important;
  background: rgba(0, 0, 0, 0.05) !important;
  box-shadow: none !important;
  outline: none !important;
}

.student-report-export .dropdown-toggle::after {
  display: none;
}

/* Убеждаемся, что выпадающее меню Bootstrap не обрезается и отображается поверх других элементов */
.student-report-export .dropdown-menu {
  min-width: 200px;
  z-index: 9999 !important;
}

/* Увеличиваем z-index для открытого dropdown и его родительских элементов */
.student-report-export .dropdown.show {
  z-index: 9999 !important;
  position: relative;
}

.student-report-export .dropdown {
  position: relative;
}

.student-report-export .dropdown-item {
  display: flex;
  align-items: center;
}

.student-report-export .dropdown-item.disabled {
  opacity: 0.6;
  cursor: not-allowed;
  pointer-events: none;
}

.student-report-export .dropdown-item i {
  width: 20px;
  text-align: center;
}

.btn:disabled {
  cursor: not-allowed;
  opacity: 0.7;
}

/* Индикатор загрузки с перебегающими точками */
.export-loader-dots {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  vertical-align: middle;
}

.export-loader-dots .dot {
  display: inline-block;
  width: 4px;
  height: 4px;
  border-radius: 50%;
  background-color: currentColor;
  animation: export-dots-bounce 1.4s infinite ease-in-out;
}

.export-loader-dots .dot:nth-child(1) {
  animation-delay: -0.32s;
}

.export-loader-dots .dot:nth-child(2) {
  animation-delay: -0.16s;
}

.export-loader-dots .dot:nth-child(3) {
  animation-delay: 0s;
}

@keyframes export-dots-bounce {
  0%, 80%, 100% {
    transform: scale(0.8);
    opacity: 0.5;
  }
  40% {
    transform: scale(1);
    opacity: 1;
  }
}
</style> 