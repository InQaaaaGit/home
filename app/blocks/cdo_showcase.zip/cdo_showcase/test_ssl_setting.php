<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Test file for block settings
 *
 * @package    block_cdo_showcase
 * @copyright  2024 Your Name <your@email.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');

// Проверяем права доступа
require_login();
require_capability('moodle/site:config', context_system::instance());

$PAGE->set_context(context_system::instance());
$PAGE->set_url('/blocks/cdo_showcase/test_ssl_setting.php');
$PAGE->set_title('Test Block Settings');
$PAGE->set_heading('Test Block Settings');

echo $OUTPUT->header();

echo '<h2>Тест настроек блока CDO Showcase</h2>';

// Получаем текущие значения настроек
$ssl_verification = get_config('block_cdo_showcase', 'ssl_verification');
$test_mode = get_config('block_cdo_showcase', 'test_mode');
$test_email = get_config('block_cdo_showcase', 'test_email');
$test_isrop = get_config('block_cdo_showcase', 'test_isrop');

echo '<div class="row">';
echo '<div class="col-md-6">';
echo '<h3>Текущие значения настроек</h3>';
echo '<ul class="list-group">';
echo '<li class="list-group-item"><strong>SSL-верификация:</strong> ' . 
     ($ssl_verification ? 'Включена (1)' : 'Отключена (0)') . '</li>';
echo '<li class="list-group-item"><strong>Тестовый режим:</strong> ' . 
     ($test_mode ? 'Включен (1)' : 'Отключен (0)') . '</li>';
echo '<li class="list-group-item"><strong>Тестовый email:</strong> ' . 
     htmlspecialchars($test_email) . '</li>';
echo '<li class="list-group-item"><strong>Тестовое isROP:</strong> ' . 
     ($test_isrop ? 'Включено (1)' : 'Отключено (0)') . '</li>';
echo '</ul>';
echo '</div>';

echo '<div class="col-md-6">';
echo '<h3>Тестирование изменения настроек</h3>';
echo '<form method="post">';
echo '<input type="hidden" name="test_change" value="1">';

echo '<div class="form-group mb-3">';
echo '<label>SSL-верификация: </label>';
echo '<select name="ssl_verification" class="form-control">';
echo '<option value="1" ' . ($ssl_verification ? 'selected' : '') . '>Включена</option>';
echo '<option value="0" ' . (!$ssl_verification ? 'selected' : '') . '>Отключена</option>';
echo '</select>';
echo '</div>';

echo '<div class="form-group mb-3">';
echo '<label>Тестовый режим: </label>';
echo '<select name="test_mode" class="form-control">';
echo '<option value="1" ' . ($test_mode ? 'selected' : '') . '>Включен</option>';
echo '<option value="0" ' . (!$test_mode ? 'selected' : '') . '>Отключен</option>';
echo '</select>';
echo '</div>';

echo '<div class="form-group mb-3">';
echo '<label>Тестовый email: </label>';
echo '<input type="email" name="test_email" value="' . htmlspecialchars($test_email) . '" class="form-control">';
echo '</div>';

echo '<div class="form-group mb-3">';
echo '<label>Тестовое isROP: </label>';
echo '<select name="test_isrop" class="form-control">';
echo '<option value="1" ' . ($test_isrop ? 'selected' : '') . '>Включено</option>';
echo '<option value="0" ' . (!$test_isrop ? 'selected' : '') . '>Отключено</option>';
echo '</select>';
echo '</div>';

echo '<input type="submit" value="Сохранить настройки" class="btn btn-primary">';
echo '</form>';
echo '</div>';
echo '</div>';

// Обработка изменения настроек
if (optional_param('test_change', 0, PARAM_INT)) {
    $new_ssl_verification = optional_param('ssl_verification', 1, PARAM_INT);
    $new_test_mode = optional_param('test_mode', 0, PARAM_INT);
    $new_test_email = optional_param('test_email', 'test@example.com', PARAM_EMAIL);
    $new_test_isrop = optional_param('test_isrop', 1, PARAM_INT);
    
    set_config('ssl_verification', $new_ssl_verification, 'block_cdo_showcase');
    set_config('test_mode', $new_test_mode, 'block_cdo_showcase');
    set_config('test_email', $new_test_email, 'block_cdo_showcase');
    set_config('test_isrop', $new_test_isrop, 'block_cdo_showcase');
    
    echo '<div class="alert alert-success mt-3">Настройки успешно обновлены!</div>';
    
    // Обновляем значения для отображения
    $ssl_verification = $new_ssl_verification;
    $test_mode = $new_test_mode;
    $test_email = $new_test_email;
    $test_isrop = $new_test_isrop;
}

echo '<h3 class="mt-4">Информация о настройках</h3>';
echo '<div class="row">';
echo '<div class="col-md-6">';
echo '<h4>SSL-верификация</h4>';
echo '<ul>';
echo '<li><strong>Имя настройки:</strong> block_cdo_showcase/ssl_verification</li>';
echo '<li><strong>Тип:</strong> admin_setting_configselect</li>';
echo '<li><strong>Значение по умолчанию:</strong> 1 (включена)</li>';
echo '<li><strong>Описание:</strong> Управляет проверкой SSL-сертификатов при выполнении внешних API-запросов</li>';
echo '</ul>';
echo '</div>';

echo '<div class="col-md-6">';
echo '<h4>Настройки блока</h4>';
echo '<ul>';
echo '<li><strong>Тестовый режим:</strong> block_cdo_showcase/test_mode</li>';
echo '<li><strong>Тестовый email:</strong> block_cdo_showcase/test_email</li>';
echo '<li><strong>Тестовое isROP:</strong> block_cdo_showcase/test_isrop</li>';
echo '</ul>';
echo '</div>';
echo '</div>';

echo '<h3>Как это работает в коде</h3>';
echo '<p>В файле <code>block_cdo_showcase.php</code> настройки используются следующим образом:</p>';
echo '<pre><code>';
echo '// Получаем настройки блока
$test_mode = get_config(\'block_cdo_showcase\', \'test_mode\');

// Определяем email в зависимости от режима
if ($test_mode) {
    // Тестовый режим - используем настройку
    $email = get_config(\'block_cdo_showcase\', \'test_email\');
} else {
    // Продакшн режим - используем реальный email пользователя
    $email = $USER->email;
}

// Определяем isROP в зависимости от режима
if ($test_mode) {
    // Тестовый режим - используем настройку
    $isrop = (bool)get_config(\'block_cdo_showcase\', \'test_isrop\');
} else {
    // Продакшн режим - используем реальное значение
    $isrop = controller::user_has_token_assignments();
}';
echo '</code></pre>';

echo $OUTPUT->footer(); 