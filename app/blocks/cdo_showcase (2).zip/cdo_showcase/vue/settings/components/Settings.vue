<script setup>
import {useLangStore} from "../store/storeLang";
import {useGeneralStore} from "../store/storeGeneral";
import notification from "core/notification";
import { ref, computed } from 'vue';
import * as moodleAjax from 'core/ajax';
import Modal from './Modal.vue';

const lang = useLangStore();
const general = useGeneralStore();

const showUserModal = ref(false);
const selectedToken = ref(null);
const tokenUsers = ref([]);
const searchQuery = ref('');
const selectedUsers = ref([]);
const showCoursesModal = ref(false);
const courses = ref([]);
const searchCourseQuery = ref('');
const selectedCourses = ref([]);
const slideDirection = ref('');
const currentPage = ref(1);
const coursesPerPage = ref(5);

const addNewRow = () => {
  general.settings.push({name: '', url: '', token: '', token_status: null, category_id: null})
}

const deleteRow = (row, index) => {
  general.settings.splice(index, 1);
  general.deleteSetting(row.id);
}

const saveRow = async (row, index) => {
  try {
    const success = await general.saveSettings(row);
    if (success) {
      // Добавляем класс успешного сохранения
      row.saved = true;
      // Убираем класс через 2 секунды
      setTimeout(() => {
        row.saved = false;
      }, 2000);
    }
  } catch (error) {
    await notification.exception(error);
  }
}

const checkToken = async (row) => {
  try {
    const result = await general.checkToken(row);
    row.token_status = result.success;
    if (result.success) {
      await notification.addNotification({
        message: 'Токен действителен',
        type: 'success'
      });
    } else {
      await notification.addNotification({
        message: result.message,
        type: 'error'
      });
    }
  } catch (error) {
    row.token_status = false;
    await notification.exception(error);
  }
}

const disableToken = async (row, index) => {
  try {
    // Устанавливаем token_status в 0 (выключен)
    row.token_status = 0;
    // Сохраняем изменения
    const success = await general.saveSettings(row);
    if (success) {
      await notification.addNotification({
        message: 'Токен успешно отключен',
        type: 'success'
      });
      // Добавляем класс успешного сохранения
      row.saved = true;
      setTimeout(() => {
        row.saved = false;
      }, 2000);
    }
  } catch (error) {
    // В случае ошибки возвращаем предыдущее значение
    row.token_status = true;
    await notification.exception(error);
  }
}

const getTokenStatusClass = (status) => {
  switch (status) {
    case true:
      return 'valid';
    case false:
      return 'invalid';
    default:
      return '';
  }
}

const validateCategoryId = (row) => {
  // Валидация category_id: должно быть положительным числом или пустым
  if (row.category_id !== null && row.category_id !== '') {
    const value = parseInt(row.category_id);
    if (isNaN(value) || value < 0) {
      row.category_id = null;
    } else {
      row.category_id = value;
    }
  }
}

const openUserModal = async (row) => {
  selectedToken.value = row;
  showUserModal.value = true;
  try {
    await getTokenUsers(row);
    // Здесь будет запрос на получение списка пользователей
    tokenUsers.value = []; // Временно пустой массив
    tokenUsers.value = general.currentTokenUsers; // Временно пустой массив
    selectedUsers.value = []; // Сбрасываем выбранных пользователей
  } catch (error) {
    await notification.exception(error);
  }
}

const closeUserModal = () => {
  showUserModal.value = false;
  selectedToken.value = null;
  tokenUsers.value = [];
  selectedUsers.value = [];
  searchQuery.value = '';
  // Очищаем также список назначенных курсов
  userAssignedCourses.value = [];
}

const toggleUserSelection = async (user) => {
  const index = selectedUsers.value.findIndex(u => u.id === user.id);
  if (index === -1) {
    selectedUsers.value = [user]; // Выбираем только одного пользователя
    // Загружаем уже назначенные курсы для выбранного пользователя
    await loadUserAssignedCourses(user.email);
  } else {
    selectedUsers.value.splice(index, 1);
    // Очищаем список назначенных курсов
    userAssignedCourses.value = [];
  }
}

// Добавляем новую переменную для хранения назначенных курсов
const userAssignedCourses = ref([]);

// Новый метод для загрузки назначенных курсов пользователя
const loadUserAssignedCourses = async (userEmail) => {
  if (!selectedToken.value || !selectedToken.value.id) {
    return;
  }

  try {
    const result = await moodleAjax.call([{
      methodname: 'block_cdo_showcase_get_user_courses',
      args: {
        config_id: selectedToken.value.id,
        user_email: userEmail
      }
    }])[0];

    if (result && Array.isArray(result)) {
      userAssignedCourses.value = result.map(course => course.id);
    } else {
      userAssignedCourses.value = [];
    }
  } catch (error) {
    console.error('Error loading user assigned courses:', error);
    userAssignedCourses.value = [];
  }
};

// Метод для проверки назначен ли курс пользователю
const isCourseAssigned = (courseId) => {
  return userAssignedCourses.value.includes(courseId);
};

const saveUserAssignments = async () => {
  try {

    // Здесь будет запрос на сохранение назначенных пользователей
    await notification.addNotification({
      message: 'Пользователи успешно назначены',
      type: 'success'
    });
    closeUserModal();
  } catch (error) {
    await notification.exception(error);
  }
}

const searchUsers = async () => {
  if (!searchQuery.value || searchQuery.value.length < 2) {
    tokenUsers.value = [];
    return;
  }

  try {
    const result = await moodleAjax.call([{
      methodname: 'core_user_get_users_by_field',
      args: {
        field: 'email',
        values: [searchQuery.value]
      }
    }])[0];

    if (result && Array.isArray(result)) {
      tokenUsers.value = result.map(user => ({
        id: user.id,
        firstname: user.firstname,
        lastname: user.lastname,
        email: user.email
      }));
    } else {
      tokenUsers.value = [];
    }
  } catch (error) {
    console.error('Error searching users:', error);
    tokenUsers.value = general.currentTokenUsers;
    await notification.exception(error);
  }
};

// Добавим debounce для оптимизации запросов
let searchTimeout = null;
const debouncedSearch = () => {
  if (searchTimeout) {
    clearTimeout(searchTimeout);
  }
  searchTimeout = setTimeout(() => {
    searchUsers();
  }, 300);
};

// Обновим обработчик input
const handleSearchInput = () => {
  debouncedSearch();
};

const filteredUsers = computed(() => {
  if (!searchQuery.value) return tokenUsers.value;
  const query = searchQuery.value.toLowerCase();
  return tokenUsers.value.filter(user => 
    user.firstname.toLowerCase().includes(query) ||
    user.lastname.toLowerCase().includes(query) ||
    user.email.toLowerCase().includes(query)
  );
});

const openCoursesModal = async () => {
  if (!selectedToken.value || !selectedToken.value.id) {
    await notification.addNotification({
      message: 'Ошибка: не выбран токен',
      type: 'error'
    });
    return;
  }

  slideDirection.value = 'slide-in';
  showCoursesModal.value = true;
  courses.value = [];
  selectedCourses.value = [];
  searchCourseQuery.value = '';
  currentPage.value = 1;
  
  // Сразу вызываем поиск курсов при открытии с ID токена
  await searchCourses(selectedToken.value.id);
  
  // Предварительно отмечаем уже назначенные курсы как выбранные
  if (userAssignedCourses.value.length > 0) {
    selectedCourses.value = courses.value.filter(course => 
      userAssignedCourses.value.includes(course.id)
    );
  }
};

const closeCoursesModal = () => {
  slideDirection.value = 'slide-out';
  // Даем время для анимации перед закрытием
  setTimeout(() => {
    showCoursesModal.value = false;
    courses.value = [];
    selectedCourses.value = [];
    searchCourseQuery.value = '';
    currentPage.value = 1;
  }, 300);
}

const searchCourses = async (configId) => {
  if (!configId) {
    console.error('Error: configId is required');
    return;
  }

  // Получаем конфиг из general.settings для извлечения category_id
  const config = general.settings.find(s => s.id === configId);
  const categoryId = config?.category_id !== null && config?.category_id !== undefined ? config.category_id : null;

  try {
    const args = {
      configid: configId
    };
    
    // Передаем category_id, если он задан
    if (categoryId !== null) {
      args.category_id = categoryId;
    }
    
    const result = await moodleAjax.call([{
      methodname: 'block_cdo_showcase_search_courses',
      args: args
    }])[0];

    if (result && Array.isArray(result)) {
      courses.value = result.map(course => ({
        id: course.id,
        fullname: course.fullname,
        shortname: course.shortname,
        category: course.category
      }));
    } else {
      courses.value = [];
    }
  } catch (error) {
    console.error('Error searching courses:', error);
    courses.value = [];
    await notification.exception(error);
  }
};

// Обновим обработчик поиска, чтобы он НЕ делал API вызов, а только сбрасывал пагинацию
const handleCourseSearchInput = () => {
  currentPage.value = 1; // Сбрасываем на первую страницу при поиске
};

const toggleCourseSelection = (course) => {
  const index = selectedCourses.value.findIndex(c => c.id === course.id);
  if (index === -1) {
    selectedCourses.value.push(course);
  } else {
    selectedCourses.value.splice(index, 1);
  }
};

// Обновляем фильтрацию курсов - фокус на наименовании курса
const filteredCourses = computed(() => {
  if (!searchCourseQuery.value) return courses.value;
  const query = searchCourseQuery.value.toLowerCase().trim();
  
  return courses.value.filter(course => {
    // Основной критерий поиска - наименование курса (fullname)
    const matchesFullName = course.fullname.toLowerCase().includes(query);
    // Дополнительно можем искать по короткому имени
    const matchesShortName = course.shortname.toLowerCase().includes(query);
    
    return matchesFullName || matchesShortName;
  });
});

const totalPages = computed(() => {
  return Math.ceil(filteredCourses.value.length / coursesPerPage.value);
});

const paginatedCourses = computed(() => {
  const startIndex = (currentPage.value - 1) * coursesPerPage.value;
  const endIndex = startIndex + coursesPerPage.value;
  return filteredCourses.value.slice(startIndex, endIndex);
});

const goToPage = (page) => {
  if (page >= 1 && page <= totalPages.value) {
    currentPage.value = page;
  }
};

const nextPage = () => {
  if (currentPage.value < totalPages.value) {
    currentPage.value++;
  }
};

const prevPage = () => {
  if (currentPage.value > 1) {
    currentPage.value--;
  }
};

const saveCourseAssignments = async () => {
  try {
    // Проверяем что есть выбранные курсы и пользователь
    if (selectedCourses.value.length === 0) {
      await notification.addNotification({
        message: 'Выберите хотя бы один курс',
        type: 'error'
      });
      return;
    }
    
    if (selectedUsers.value.length === 0) {
      await notification.addNotification({
        message: 'Выберите пользователя',
        type: 'error'
      });
      return;
    }

    const user = selectedUsers.value[0]; // Берём первого выбранного пользователя
    const courseIds = selectedCourses.value.map(course => course.id);

    // Вызываем API для сохранения курсов пользователя
    const result = await moodleAjax.call([{
      methodname: 'block_cdo_showcase_save_user_courses',
      args: {
        config_id: selectedToken.value.id,
        user_email: user.email,
        course_ids: courseIds
      }
    }])[0];

    if (result.success) {
      await notification.addNotification({
        message: result.message || `Успешно назначено ${result.courses_count} курсов пользователю ${user.email}`,
        type: 'success'
      });
      closeCoursesModal();
    } else {
      await notification.addNotification({
        message: 'Ошибка при сохранении курсов',
        type: 'error'
      });
    }
  } catch (error) {
    console.error('Error saving course assignments:', error);
    await notification.exception(error);
  }
};

const getTokenUsers = async (row) => {
  await general.getTokenUsers(row);
}
</script>

<template>
  <div class="settings-table">
    <div v-if="general.isLoading" class="loading">
      <i class="fa fa-refresh fa-spin"></i>
    </div>
    <template v-else>
      <div v-if="general.settings.length === 0" class="no-settings">
        <i class="fa fa-info-circle"></i>
        <p>{{ lang.strings.no_settings }}</p>
        <button @click="addNewRow" class="add-button">{{ lang.strings.add_new }}</button>
      </div>
      <template v-else>
        <table>
          <thead>
          <tr>
            <th>{{ lang.strings.name }}</th>
            <th>{{ lang.strings.url }}</th>
            <th>{{ lang.strings.category_id || 'ID категории' }}</th>
            <th>{{ lang.strings.token }}</th>
            <th>{{ lang.strings.actions }}</th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="(row, index) in general.settings" :key="index">
            <td>
              <input v-model="row.name" type="text" :placeholder="lang.strings.name">
            </td>
            <td>
              <input v-model="row.url" type="text" :placeholder="lang.strings.url">
            </td>
            <td class="category-id-cell">
              <div class="category-id-wrapper" :title="lang.strings.category_id_desc || 'Идентификатор категории на сайте-доноре для фильтрации курсов по категории'">
                <input 
                  v-model.number="row.category_id" 
                  type="number" 
                  min="0"
                  step="1"
                  :placeholder="lang.strings.category_id || 'ID категории'"
                  class="category-id-input"
                  :class="{ 'has-value': row.category_id !== null && row.category_id !== '' }"
                  :title="lang.strings.category_id_desc || 'Идентификатор категории на сайте-доноре для фильтрации курсов'"
                  @blur="validateCategoryId(row)"
                  @input="validateCategoryId(row)"
                >
                <i class="fa fa-folder category-id-icon" :title="lang.strings.category_id_desc || 'Идентификатор категории'"></i>
              </div>
            </td>
            <td>
              <input v-model="row.token" type="text" :placeholder="lang.strings.token">
            </td>
            <td class="actions-cell">
              <button
                  @click="saveRow(row, index)"
                  class="action-button save"
                  :title="lang.strings.save"
                  :class="{ 
                    'saving': general.savingRows[row.id || 'new'],
                    'saved': row.saved
                  }"
              >
                <i class="fa" :class="{
                    'fa-spinner fa-spin': general.savingRows[row.id || 'new'],
                    'fa-save': !general.savingRows[row.id || 'new'] && !row.saved,
                    'fa-check': row.saved
                  }"></i>
              </button>
              <button
                  :disabled="!row.token.length"
                  @click="checkToken(row)"
                  class="action-button check"
                  :title="lang.strings.check_token"
                  :class="getTokenStatusClass(row.token_status)"
              >
                <i class="fa fa-handshake"></i>
              </button>
              <button 
                  v-if="row.token_status"
                  @click="openUserModal(row)"
                  class="action-button users"
                  :title="lang.strings.assign_users"
              >
                <i class="fa fa-users"></i>
              </button>
              <button 
                  v-if="row.token_status"
                  @click="disableToken(row, index)"
                  class="action-button disable"
                  :title="lang.strings.disable_token || 'Отключить токен'"
              >
                <i class="fa fa-power-off"></i>
              </button>
              <button @click="deleteRow(row, index)" class="action-button delete" :title="lang.strings.delete_row">
                <i class="fa fa-trash"></i>
              </button>
            </td>
          </tr>
          </tbody>
        </table>
        <button @click="addNewRow" class="add-button">{{ lang.strings.add_new }}</button>
      </template>
    </template>

    <!-- Модальное окно назначения пользователей -->
    <Modal
      :show="showUserModal"
      :title="lang.strings.assign_users_to_token || 'Назначить пользователей'"
      :icon="'fa fa-users'"
      @close="closeUserModal"
    >
      <div class="search-box">
        <input 
          v-model="searchQuery"
          type="text"
          :placeholder="lang.strings.search_users || 'Поиск пользователей...'"
          class="search-input"
          @input="handleSearchInput"
        >
        <button 
          v-if="selectedUsers.length === 1"
          @click="openCoursesModal"
          class="select-courses-button"
          :title="lang.strings.select_courses || 'Выбрать курсы'"
        >
          <i class="fa fa-book"></i>
          {{ lang.strings.select_courses || 'Выбрать курсы' }}
        </button>
      </div>
      <div class="users-list">
        <div v-if="filteredUsers.length === 0" class="no-users">
          {{ lang.strings.no_users_found || 'Пользователи не найдены' }}
        </div>
        <div 
          v-for="user in filteredUsers" 
          :key="user.id"
          class="user-item"
          :class="{ 'selected': selectedUsers.some(u => u.id === user.id) }"
          @click="toggleUserSelection(user)"
        >
          <div class="user-info">
            <span class="user-name">{{ user.firstname }} {{ user.lastname }}</span>
            <span class="user-email">{{ user.email }}</span>
          </div>
          <i class="fa" :class="selectedUsers.some(u => u.id === user.id) ? 'fa-check-circle' : 'fa-circle'"></i>
        </div>
      </div>
      <template #footer>
        <button @click="closeUserModal" class="cancel-button">
          {{ lang.strings.cancel || 'Отмена' }}
        </button>
        <button 
          @click="saveUserAssignments"
          class="save-button"
          :disabled="selectedUsers.length === 0"
        >
          {{ lang.strings.save || 'Сохранить' }}
        </button>
      </template>
    </Modal>

    <!-- Модальное окно выбора курсов -->
    <Modal
      :show="showCoursesModal"
      :title="lang.strings.select_courses || 'Выбрать курсы'"
      :subtitle="selectedUsers.length === 1 ? `для ${selectedUsers[0].firstname} ${selectedUsers[0].lastname}` : ''"
      :icon="'fa fa-book'"
      slide-direction="slide-in"
      @close="closeCoursesModal"
    >
      <div class="search-box">
        <input 
          v-model="searchCourseQuery"
          type="text"
          :placeholder="lang.strings.search_courses || 'Поиск курсов по названию...'"
          class="search-input"
          @input="handleCourseSearchInput"
        >
        <div v-if="courses.length > 0" class="search-results-info">
          <span v-if="!searchCourseQuery">Всего курсов: {{ courses.length }}</span>
          <span v-else>Найдено: {{ filteredCourses.length }} из {{ courses.length }} курсов</span>
        </div>
      </div>
      <div class="courses-list">
        <div v-if="courses.length === 0" class="no-courses">
          <i class="fa fa-book"></i>
          <p>{{ lang.strings.loading_courses || 'Загрузка курсов...' }}</p>
        </div>
        <div v-else-if="filteredCourses.length === 0 && searchCourseQuery" class="no-courses">
          <i class="fa fa-search"></i>
          <p>По запросу "{{ searchCourseQuery }}" курсы не найдены</p>
          <small>Попробуйте изменить поисковый запрос</small>
        </div>
        <div 
          v-for="course in paginatedCourses" 
          :key="course.id"
          class="course-item"
          :class="{ 
            'selected': selectedCourses.some(c => c.id === course.id),
            'already-assigned': isCourseAssigned(course.id)
          }"
          @click="toggleCourseSelection(course)"
        >
          <div class="course-info">
            <span class="course-name">{{ course.fullname }}</span>
            <span class="course-shortname">{{ course.shortname }}</span>
            <!-- Индикатор уже назначенного курса -->
            <span v-if="isCourseAssigned(course.id)" class="assigned-indicator">
              <i class="fa fa-user-check"></i>
              Уже назначен
            </span>
          </div>
          <div class="course-status">
            <i class="fa" :class="selectedCourses.some(c => c.id === course.id) ? 'fa-check-circle' : 'fa-circle'"></i>
          </div>
        </div>
      </div>
      
      <!-- Пагинация -->
      <div v-if="filteredCourses.length > coursesPerPage" class="pagination">
        <div class="pagination-info">
          Показано {{ ((currentPage - 1) * coursesPerPage) + 1 }}-{{ Math.min(currentPage * coursesPerPage, filteredCourses.length) }} из {{ filteredCourses.length }} курсов
        </div>
        <div class="pagination-controls">
          <button 
            @click="prevPage" 
            :disabled="currentPage === 1"
            class="pagination-button"
            :title="'Предыдущая страница'"
          >
            <i class="fa fa-chevron-left"></i>
          </button>
          
          <div class="pagination-pages">
            <button 
              v-for="page in Math.min(totalPages, 5)" 
              :key="page"
              @click="goToPage(page)"
              class="pagination-button page-number"
              :class="{ 'active': page === currentPage }"
            >
              {{ page }}
            </button>
            <span v-if="totalPages > 5" class="pagination-ellipsis">...</span>
          </div>
          
          <button 
            @click="nextPage" 
            :disabled="currentPage === totalPages"
            class="pagination-button"
            :title="'Следующая страница'"
          >
            <i class="fa fa-chevron-right"></i>
          </button>
        </div>
      </div>
      <template #footer>
        <button @click="closeCoursesModal" class="cancel-button">
          {{ lang.strings.cancel || 'Отмена' }}
        </button>
        <button 
          @click="saveCourseAssignments"
          class="save-button"
          :disabled="selectedCourses.length === 0"
        >
          {{ lang.strings.save || 'Сохранить' }}
        </button>
      </template>
    </Modal>
  </div>
</template>

<style scoped>
.settings-table {
  width: 100%;
  margin: 20px 0;
}

.loading {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 40px;
}

.loading .fa {
  font-size: 40px;
  color: #666;
}

.no-settings {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px;
  text-align: center;
  background-color: #f5f5f5;
  border-radius: 8px;
  margin-bottom: 20px;
}

.no-settings .fa {
  font-size: 48px;
  color: #666;
  margin-bottom: 16px;
}

.no-settings p {
  margin: 0 0 20px;
  color: #666;
  font-size: 16px;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 20px;
}

th, td {
  padding: 12px;
  text-align: left;
  border: 1px solid #ddd;
}

th {
  background-color: #f5f5f5;
  font-weight: bold;
}

input {
  width: 100%;
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.category-id-cell {
  position: relative;
}

.category-id-wrapper {
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
}

.category-id-input {
  flex: 1;
  padding-right: 32px;
}

.category-id-icon {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  color: #666;
  font-size: 14px;
  pointer-events: none;
  opacity: 0.5;
  transition: all 0.2s ease;
}

.category-id-wrapper:hover .category-id-icon {
  opacity: 0.8;
  color: #4CAF50;
}

.category-id-input:focus ~ .category-id-icon {
  opacity: 1;
  color: #1976d4;
}

.category-id-input.has-value ~ .category-id-icon {
  opacity: 0.8;
  color: #4CAF50;
}

.category-id-input.has-value {
  border-color: #4CAF50;
  background-color: #f8fff8;
}

.category-id-input.has-value:focus {
  border-color: #1976d4;
  background-color: #fff;
  box-shadow: 0 0 0 2px rgba(25, 118, 210, 0.1);
}

.actions-cell {
  text-align: center;
  white-space: nowrap;
}

.action-button {
  display: inline-block;
  padding: 6px;
  margin: 0 2px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  background-color: #f5f5f5;
  color: #333;
  transition: all 0.3s ease;
  vertical-align: middle;
}

.action-button:hover {
  background-color: #e0e0e0;
}

.action-button.save {
  color: #1976d4;
}

.action-button.save:hover {
  background-color: #e3f2fd;
}

.action-button.save.saving {
  color: #666;
  background-color: #f5f5f5;
  cursor: wait;
}

.action-button.save.saved {
  color: #4CAF50;
  background-color: #e8f5e9;
}

.action-button.check {
  color: #ed0505;
}

.action-button.check:hover {
  background-color: #e8f5e9;
}

.action-button.check.valid {
  color: #4CAF50;
  background-color: #e8f5e9;
}

.action-button.check.invalid {
  color: #d32f2f;
  background-color: #ffebee;
}

.action-button.check.error {
  color: #ff9800;
  background-color: #fff3e0;
}

.action-button.delete {
  color: #d32f2f;
}

.action-button.delete:hover {
  background-color: #ffebee;
}

.fa {
  font-size: 20px;
}

.add-button {
  padding: 10px 20px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
}

.add-button:hover {
  background-color: #45a049;
}

.action-button.users {
  color: #2196F3;
}

.action-button.users:hover {
  background-color: #E3F2FD;
}

.action-button.disable {
  color: #ff9800;
}

.action-button.disable:hover {
  background-color: #fff3e0;
}

/* Оставляем только стили для содержимого модальных окон */
.search-box {
  margin-bottom: 1rem;
}

.search-input {
  width: 100%;
  padding: 0.5rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
}

.search-results-info {
  margin-top: 8px;
  font-size: 0.875rem;
  color: #666;
  text-align: center;
  padding: 4px 8px;
  background-color: #f8f9fa;
  border-radius: 4px;
}

.users-list,
.courses-list {
  max-height: 400px;
  overflow-y: auto;
}

.user-item,
.course-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem;
  border-bottom: 1px solid #eee;
  cursor: pointer;
  transition: background-color 0.2s;
}

.user-item:hover,
.course-item:hover {
  background-color: #f8f9fa;
}

.user-item.selected,
.course-item.selected {
  background-color: #E3F2FD;
}

.course-item.already-assigned {
  background-color: #FFF3E0;
  border-left: 4px solid #FF9800;
}

.course-item.already-assigned.selected {
  background-color: #E8F5E9;
  border-left: 4px solid #4CAF50;
}

.user-info,
.course-info {
  display: flex;
  flex-direction: column;
  flex: 1;
}

.course-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.course-status {
  display: flex;
  align-items: center;
  margin-left: 10px;
}

.assigned-indicator {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 0.75rem;
  color: #FF9800;
  margin-top: 4px;
  font-weight: 500;
}

.course-item.already-assigned.selected .assigned-indicator {
  color: #4CAF50;
}

.user-name,
.course-name {
  font-weight: 500;
  color: #333;
}

.user-email,
.course-shortname {
  font-size: 0.875rem;
  color: #666;
}

.no-users,
.no-courses {
  text-align: center;
  padding: 2rem;
  color: #666;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
}

.no-courses .fa {
  font-size: 2rem;
  color: #999;
}

.no-courses p {
  margin: 0;
  font-size: 1rem;
}

.no-courses small {
  color: #999;
  font-size: 0.875rem;
}

.select-courses-button {
  margin-top: 10px;
  padding: 8px 16px;
  background-color: #2196F3;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  justify-content: center;
  transition: all 0.3s ease;
  animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.select-courses-button:hover {
  background-color: #1976D2;
  transform: translateY(-1px);
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.select-courses-button:active {
  transform: translateY(0);
  box-shadow: none;
}

/* Стили для кнопок в футере модального окна */
.cancel-button {
  padding: 0.5rem 1rem;
  background-color: #f8f9fa;
  border: 1px solid #ddd;
  border-radius: 4px;
  cursor: pointer;
  color: #333;
}

.save-button {
  padding: 0.5rem 1rem;
  background-color: #4CAF50;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  color: white;
}

.save-button:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}

.save-button:not(:disabled):hover {
  background-color: #45a049;
}

.cancel-button:hover {
  background-color: #e9ecef;
}

.pagination {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  background-color: #f5f5f5;
  border-radius: 4px;
}

.pagination-info {
  font-size: 0.875rem;
  color: #666;
}

.pagination-controls {
  display: flex;
  gap: 10px;
}

.pagination-button {
  padding: 6px 12px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  background-color: #f5f5f5;
  color: #333;
  transition: all 0.3s ease;
}

.pagination-button:hover {
  background-color: #e0e0e0;
}

.pagination-button.active {
  background-color: #2196F3;
  color: white;
}

.pagination-pages {
  display: flex;
  gap: 5px;
}

.pagination-ellipsis {
  color: #666;
}

.pagination-button:disabled {
  background-color: #e9ecef;
  color: #999;
  cursor: not-allowed;
}

.pagination-button:disabled:hover {
  background-color: #e9ecef;
}

.pagination-button.page-number {
  min-width: 36px;
  text-align: center;
}

.pagination-button.page-number.active:hover {
  background-color: #1976D2;
}

.pagination-ellipsis {
  display: flex;
  align-items: center;
  padding: 6px 8px;
  color: #666;
  font-weight: bold;
}
</style>