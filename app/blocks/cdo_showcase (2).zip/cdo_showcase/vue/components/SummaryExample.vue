<template>
  <div class="summary-example-container">
    <div class="container-fluid">
      <!-- Навигация между представлениями -->
      <div class="nav-tabs-container mb-4">
        <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item" role="presentation">
            <button 
              class="nav-link" 
              :class="{ active: activeTab === 'individual' }"
              @click="activeTab = 'individual'"
              type="button">
              <i class="fa fa-user-graduate me-2"></i>
              {{ langStore.strings.individual_courses || 'Отдельные курсы' }}
            </button>
          </li>
          <li class="nav-item" role="presentation">
            <button 
              class="nav-link" 
              :class="{ active: activeTab === 'summary' }"
              @click="activeTab = 'summary'"
              type="button">
              <i class="fa fa-chart-bar me-2"></i>
              {{ langStore.strings.summary_view || 'Сводная таблица' }}
            </button>
          </li>
        </ul>
      </div>

      <!-- Контент табов -->
      <div class="tab-content">
        <!-- Индивидуальные курсы -->
        <div 
          v-show="activeTab === 'individual'" 
          class="tab-pane fade"
          :class="{ 'show active': activeTab === 'individual' }">
          
          <div class="courses-section">
            <h5 class="mb-3">
              <i class="fa fa-list me-2 text-primary"></i>
              {{ langStore.strings.select_course || 'Выберите курс для просмотра оценок' }}
            </h5>
            
            <!-- Список курсов -->
            <div class="row">
              <div 
                v-for="courseItem in generalStore.userCourses" 
                :key="courseItem.course.id"
                class="col-md-6 col-lg-4 mb-3">
                <div 
                  class="course-card" 
                  :class="{ active: selectedCourseId === courseItem.course.id }"
                  @click="selectCourse(courseItem.course.id)">
                  <div class="course-header">
                    <h6 class="course-title">{{ courseItem.course.fullname }}</h6>
                    <small class="course-shortname text-muted">{{ courseItem.course.shortname }}</small>
                  </div>
                  <div class="course-stats">
                    <div class="stat">
                      <i class="fa fa-users text-info"></i>
                      <span>{{ getCourseStudentsCount(courseItem.course) }} студентов</span>
                    </div>
                    <div class="stat">
                      <i class="fa fa-graduation-cap text-success"></i>
                      <span>{{ getCourseGradesCount(courseItem.course) }} оценок</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Таблица оценок выбранного курса -->
            <div v-if="selectedCourseId" class="selected-course-grades mt-4">
              <div class="course-grades-header">
                <h5>
                  <i class="fa fa-table me-2 text-success"></i>
                  {{ langStore.strings.course_grades || 'Оценки по курсу' }}: 
                  {{ getSelectedCourseName() }}
                </h5>
              </div>
              
              <StudentsGradeTable :course-id="selectedCourseId" />
            </div>
          </div>
        </div>

        <!-- Сводная таблица -->
        <div 
          v-show="activeTab === 'summary'" 
          class="tab-pane fade"
          :class="{ 'show active': activeTab === 'summary' }">
          
          <SummaryGradeTable />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { useGeneralStore } from '../store/storeGeneral';
import { useLangStore } from '../store/storeLang';
import StudentsGradeTable from './StudentsGradeTable.vue';
import SummaryGradeTable from './SummaryGradeTable.vue';

const generalStore = useGeneralStore();
const langStore = useLangStore();

// Состояние компонента
const activeTab = ref('summary'); // По умолчанию открываем сводную таблицу
const selectedCourseId = ref(null);

// Методы
function selectCourse(courseId) {
  selectedCourseId.value = courseId;
}

function getCourseStudentsCount(course) {
  return course.enrolled_users?.length || 0;
}

function getCourseGradesCount(course) {
  return course.user_grades?.usergrades?.length || 0;
}

function getSelectedCourseName() {
  const courseItem = generalStore.userCourses.find(item => item.course.id === selectedCourseId.value);
  return courseItem ? courseItem.course.fullname : '';
}
</script>

<style scoped>
.summary-example-container {
  padding: 1rem;
  min-height: 100vh;
}

/* Навигация */
.nav-tabs-container {
  background-color: #f8f9fa;
  padding: 1rem;
  border-radius: 0.5rem;
}

.nav-tabs {
  border-bottom: none;
}

.nav-link {
  color: #6c757d;
  border: none;
  border-radius: 0.375rem;
  margin-right: 0.5rem;
  padding: 0.75rem 1.5rem;
  transition: all 0.2s ease;
}

.nav-link:hover {
  color: #007bff;
  background-color: #e3f2fd;
}

.nav-link.active {
  color: #ffffff;
  background-color: #007bff;
  border-color: #007bff;
}

/* Карточки курсов */
.courses-section h5 {
  color: #333;
  font-weight: 600;
}

.course-card {
  background: #ffffff;
  border: 2px solid #e9ecef;
  border-radius: 0.5rem;
  padding: 1rem;
  cursor: pointer;
  transition: all 0.2s ease;
  height: 100%;
}

.course-card:hover {
  border-color: #007bff;
  box-shadow: 0 2px 8px rgba(0, 123, 255, 0.1);
  transform: translateY(-2px);
}

.course-card.active {
  border-color: #007bff;
  background-color: #e3f2fd;
  box-shadow: 0 4px 12px rgba(0, 123, 255, 0.2);
}

.course-header {
  margin-bottom: 0.75rem;
}

.course-title {
  color: #333;
  font-weight: 600;
  margin-bottom: 0.25rem;
  line-height: 1.3;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

.course-shortname {
  font-size: 0.8rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.course-stats {
  display: flex;
  gap: 1rem;
  margin-top: 0.75rem;
}

.stat {
  display: flex;
  align-items: center;
  gap: 0.25rem;
  font-size: 0.85rem;
  color: #6c757d;
}

.stat i {
  width: 1rem;
}

/* Секция с оценками выбранного курса */
.selected-course-grades {
  background-color: #f8f9fa;
  border-radius: 0.5rem;
  padding: 1.5rem;
  border: 1px solid #dee2e6;
}

.course-grades-header {
  margin-bottom: 1rem;
}

.course-grades-header h5 {
  color: #155724;
  font-weight: 600;
  margin-bottom: 0;
}

/* Контент табов */
.tab-content {
  background: #ffffff;
  border-radius: 0.5rem;
  padding: 1.5rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Анимации */
.tab-pane {
  animation: fadeIn 0.3s ease-in-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Адаптивность */
@media (max-width: 768px) {
  .summary-example-container {
    padding: 0.5rem;
  }
  
  .nav-tabs-container {
    padding: 0.75rem;
  }
  
  .nav-link {
    padding: 0.5rem 1rem;
    margin-right: 0.25rem;
    font-size: 0.9rem;
  }
  
  .tab-content {
    padding: 1rem;
  }
  
  .course-stats {
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .selected-course-grades {
    padding: 1rem;
  }
}

@media (max-width: 576px) {
  .nav-link {
    padding: 0.5rem 0.75rem;
    font-size: 0.85rem;
  }
  
  .nav-link i {
    display: none; /* Скрываем иконки на очень маленьких экранах */
  }
  
  .course-title {
    font-size: 0.9rem;
  }
  
  .stat {
    font-size: 0.8rem;
  }
}
</style> 