# CDO Education Scoring

Moodle local plugin for CDO Education Scoring functionality.

## Requirements

- Moodle 4.5.0 or later
- PHP 8.1 or later

## Installation

1. Copy this plugin to `local/cdo_education_scoring` directory in your Moodle installation.
2. Log in as administrator and visit the notifications page to complete the installation.

## Usage

This plugin provides scoring functionality for CDO Education.

## License

This plugin is licensed under the GNU General Public License v3.0.

