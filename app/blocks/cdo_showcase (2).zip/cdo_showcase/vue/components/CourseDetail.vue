<script setup>
import {onMounted, onBeforeMount, watch, ref, computed} from 'vue';
import {useRoute, useRouter} from 'vue-router';
import {useGeneralStore} from '../store/storeGeneral';
import {useLangStore} from "../store/storeLang";
import CourseCard from './CourseCard.vue';
import GradeTable from './GradeTable.vue';
import CourseEnrolledUsers from './CourseEnrolledUsers.vue';
import StudentsGradeTable from "./StudentsGradeTable.vue";
import CourseToolbar from './CourseToolbar.vue';
import { exportTeacherReport } from '../utils/excelExport';
import notification from 'core/notification';
import { CATEGORY_KEYWORDS, getCategoryType } from '../store/constants';

const route = useRoute();
const router = useRouter();
const generalStore = useGeneralStore();
const langStore = useLangStore();

const isLoading = ref(true);
const courseData = ref(null);
const grades = ref({
  grade1: 0,
  grade2: 0,
  grade3: 0,
  total_grade: 0
});

// Добавляем вычисляемое свойство для courseId
const courseId = computed(() => {
  const id = route.params.courseId;
  return id ? parseInt(id) : null;
});

async function getGrades() {
  try {
    if (!courseId.value) return;

    const result = await generalStore.getStudentGrades(courseId.value, generalStore.userEmail);
    if (result) {
      grades.value = result;
    }
  } catch (error) {
    // Error in getGrades
  }
}

async function loadCourseScale() {
  try {
    if (!courseId.value) return;
    
    // Принудительно загружаем шкалу через getStudentGrades для РОП пользователей
    await generalStore.getStudentGrades(courseId.value, generalStore.userEmail);
  } catch (error) {
    // Error loading course scale
  }
}

async function loadCourseData() {
  isLoading.value = true;
  try {
    if (!courseId.value) {
      return;
    }

    // Если курсы еще не загружены, ждем их загрузки
    if (!generalStore.userCourses.length) {
      await generalStore.getUserCourses();
    }

    courseData.value = generalStore.userCourses.find(item => item.course.id === courseId.value);

    if (courseData.value) {
      if (!generalStore.isROP) {
        // Для обычных студентов загружаем оценки (вместе с ними придет шкала)
        await getGrades();
      } else {
        // Для РОП пользователей также загружаем шкалу если её нет
        if (!courseData.value.course.scale?.gradescales?.length) {
          await loadCourseScale();
        }
      }
    }
  } catch (error) {
    // Error loading course data
  } finally {
    isLoading.value = false;
  }
}

// Следим за изменением ID курса
watch(courseId, async (newId) => {
  if (newId) {
    await loadCourseData();
  }
}, {immediate: true});

const goBack = () => {
  router.push('/');
};

// Функция для парсинга оценок студента по категориям (аналогично StudentsGradeTable)
function parseStudentGrades(gradeitems) {
  const grades = {
    frtk1: null,
    frtk2: null,
    individual: null,
    total: null
  };

  // Собираем только категории
  const categories = {};
  
  gradeitems.forEach(item => {
    if (item.itemtype === 'category') {
      categories[item.id] = {
        id: item.id,
        name: item.itemname || '',
        gradeValue: item.graderaw !== null && item.graderaw !== undefined ? item.graderaw : null,
        weight: item.weightraw
      };
    } else if (item.itemtype === 'course') {
      // Итоговая оценка курса
      grades.total = item.graderaw !== null && item.graderaw !== undefined ? item.graderaw : null;
    }
  });

  // Сортируем категории по весу
  const categoryKeys = Object.keys(categories);
  const sortedCategories = categoryKeys.sort((a, b) => {
    const catA = categories[a];
    const catB = categories[b];
    
    // Сортируем по весу (weightraw) - обычно ФРТК1 имеет больший вес
    if (catA.weight !== undefined && catB.weight !== undefined) {
      return catB.weight - catA.weight;
    }
    
    // Если весов нет, сортируем по id
    return parseInt(a) - parseInt(b);
  });

  // Обрабатываем каждую категорию
  sortedCategories.forEach((categoryId) => {
    const category = categories[categoryId];
    
    // Определяем тип категории используя функцию из store
    const categoryType = getCategoryType(category.name);
    
    // Назначаем оценку
    if (categoryType && category.gradeValue !== null && category.gradeValue !== undefined) {
      grades[categoryType] = category.gradeValue;
    }
  });

  return grades;
}

const handleExportTeacherReport = () => {
    if (!courseData.value) {
        notification.addNotification({
            message: langStore.strings.course_data_not_found || 'Данные курса не найдены.',
            type: 'error'
        });
        return;
    }

    try {
        const course = courseData.value.course;

        const disciplineName = course.fullname || '';

        const students = (course.user_grades?.usergrades || []).map(usergrade => {
            // Парсим оценки студента
            const parsedGrades = parseStudentGrades(usergrade.gradeitems || []);
            
            return {
                id: usergrade.userid,
                fullname: usergrade.userfullname,
                finalGrade: parsedGrades.total,
                frtk1: parsedGrades.frtk1,
                frtk2: parsedGrades.frtk2,
                individual: parsedGrades.individual,
            };
        });

        const validStudents = students.filter(s => s.finalGrade !== null && s.finalGrade !== undefined);
        const averageGrade = validStudents.length > 0
            ? (validStudents.reduce((sum, student) => sum + student.finalGrade, 0) / validStudents.length).toFixed(2)
            : 0;

        const scale = course.scale?.gradescales;
        const gradingScale = (scale && scale.length)
            ? scale.map(item => `${item.gradename}: ${item.minimum} - ${item.maximum}`).join('; ')
            : 'N/A';
        
        const success = exportTeacherReport(
            disciplineName,
            averageGrade,
            gradingScale,
            students
        );

        if (success) {
            notification.addNotification({
                message: langStore.strings.report_export_success || 'Отчет успешно выгружен',
                type: 'success'
            });
        } else {
            throw new Error('Export function returned false');
        }
      } catch (error) {
        // Ошибка при экспорте отчета
        notification.addNotification({
            message: langStore.strings.report_export_error || 'Ошибка при выгрузке отчета',
            type: 'error'
        });
    }
};
</script>

<template>
  <div class="course-detail-container">
    <div class="course-detail">
      <div v-if="isLoading" class="text-center p-5">
        <div class="spinner-border text-primary" role="status">
          <span class="visually-hidden"></span>
        </div>
      </div>

      <div v-else-if="courseData" class="card">
        <div class="card-header">
          <div class="header-top d-flex justify-content-between align-items-start">
            <h1 class="card-title mb-0">{{ courseData.course.fullname }}</h1>
            <button @click="goBack" class="btn btn-secondary btn-sm flex-shrink-0">
              <i class="fa fa-arrow-left mr-1"></i>{{ langStore.strings.coursedetail_backbutton || 'Назад' }}
            </button>
          </div>
          <!-- Панель инструментов курса -->
          <div class="header-toolbar">
            <CourseToolbar 
              :course="courseData.course"
              :config-name="courseData.config?.name || ''"
              :is-teacher="courseData.isTeacher || generalStore.isROP"
              @export-teacher-report="handleExportTeacherReport"
            />
          </div>
        </div>
        <CourseCard :course="courseData.course" :showDetails="true"/>
        <div class="card-footer">
          <div class="grades-section">
            <template v-if="courseData.isTeacher || generalStore.isROP">
<!--              <CourseEnrolledUsers :course="courseData.course" />-->
              <StudentsGradeTable :course-id="courseData.course.id"
              ></StudentsGradeTable>
            </template>
            <template v-else>
              <h3>{{ langStore.strings.coursedetail_gradessectiontitle || 'Оценки:' }}</h3>
              <GradeTable
                  :grade1="grades.grade1"
                  :grade2="grades.grade2"
                  :grade3="grades.grade3"
                  :course-id="courseId"
                  :total-grade="grades.total_grade"
                  :average-grade="grades.average_grade"/>
            </template>
          </div>
        </div>
      </div>

      <div v-else class="alert alert-warning">
        Курс не найден
      </div>
    </div>
  </div>
</template>

<style scoped>
.course-detail-container {
  max-width: 100%;
  margin: 0 auto;
}

.course-title {
  color: #495057;
  margin-bottom: 1rem;
}

.courses-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1rem;
}

.error-container {
  text-align: center;
  padding: 2rem;
}

.error-message {
  color: #721c24;
  background-color: #f8d7da;
  border: 1px solid #f5c6cb;
  border-radius: 0.375rem;
  padding: 1rem;
  margin: 1rem 0;
}

.back-button {
  margin-bottom: 1rem;
}

.config-badge-detail {
  display: inline-block;
  background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
  color: white;
  padding: 6px 12px;
  border-radius: 15px;
  font-size: 0.75rem;
  font-weight: 600;
  margin-bottom: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.config-badge-detail .fa {
  margin-right: 4px;
}

.course-detail {
  padding: 20px;
}

.card {
  max-width: 800px;
  margin: 0 auto;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.card-header {
  background-color: #f8f9fa;
  border-bottom: 1px solid #dee2e6;
  padding: 1rem;
}

.header-top {
  margin-bottom: 0.75rem;
  gap: 1rem;
}

.card-header .card-title {
  font-size: 1.4rem;
  margin: 0;
  line-height: 1.3;
  word-wrap: break-word;
  word-break: break-word;
  hyphens: auto;
  flex: 1;
  min-width: 0; /* Позволяет тексту сжиматься */
}

.header-toolbar {
  margin-top: 0.5rem;
}

.card-footer {
  background-color: #f8f9fa;
  border-top: 1px solid #dee2e6;
  padding: 1rem;
}



.card-title {
  font-size: 2rem;
  margin-bottom: 1rem;
}

.card-text {
  font-size: 1.1rem;
  line-height: 1.6;
}

.grades-section {
  margin-top: 1rem;
}

.grades-section h3 {
  font-size: 1.5rem;
  margin-bottom: 1rem;
  color: #495057;
}

.table {
  margin-top: 1rem;
}

h3 {
  margin-top: 1.5rem;
  margin-bottom: 1rem;
}

ul {
  list-style: none;
  padding-left: 0;
}

li {
  margin-bottom: 0.5rem;
}

.btn-secondary {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.btn-secondary i {
  font-size: 0.9rem;
}

/* Стили панели инструментов в детальной карточке */
.header-toolbar :deep(.course-toolbar) {
  margin-bottom: 0;
  margin-top: 0;
}

.header-toolbar :deep(.course-toolbar .token-badge) {
  font-size: 0.8rem;
  padding: 6px 10px;
  max-width: 200px;
}

.header-toolbar :deep(.course-toolbar .grade-scale-btn) {
  font-size: 0.8rem;
  padding: 6px 10px;
}

/* Адаптивность для мобильных устройств */
@media (max-width: 992px) {
  .card-header .card-title {
    font-size: 1.2rem;
  }
  
  .header-toolbar :deep(.course-toolbar .token-badge),
  .header-toolbar :deep(.course-toolbar .grade-scale-btn) {
    font-size: 0.75rem;
    padding: 5px 8px;
  }
}

@media (max-width: 768px) {
  .header-top {
    flex-direction: column;
    gap: 0.5rem;
    margin-bottom: 0.5rem;
  }
  
  .card-header .card-title {
    font-size: 1.1rem;
    margin-bottom: 0.5rem;
  }
  
  .btn-secondary {
    align-self: flex-start;
  }
  
  .header-toolbar :deep(.course-toolbar) {
    flex-direction: column;
    align-items: stretch;
    gap: 0.5rem;
  }
  
  .header-toolbar :deep(.course-toolbar .token-badge),
  .header-toolbar :deep(.course-toolbar .grade-scale-btn) {
    width: 100%;
    text-align: center;
    justify-content: center;
    font-size: 0.8rem;
  }
}

@media (max-width: 576px) {
  .card-header {
    padding: 0.75rem;
  }
  
  .card-header .card-title {
    font-size: 1rem;
    line-height: 1.4;
  }
  
  .btn-secondary {
    font-size: 0.8rem;
    padding: 0.25rem 0.5rem;
  }
}
</style>