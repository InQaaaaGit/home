<template>
  <div class="grade-table-container">
    <!-- Прогресс загрузка -->
    <div v-if="loading" class="progress-loader">
      <div class="progress">
        <div class="progress-bar progress-bar-striped progress-bar-animated" 
             role="progressbar" 
             aria-valuenow="100" 
             aria-valuemin="0" 
             aria-valuemax="100" 
             style="width: 100%">
          {{ langStore.strings.gradetable_loading || 'Загрузка оценок...' }}
        </div>
      </div>
    </div>

    <!-- Основная таблица -->
    <div v-else class="table-responsive">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col" class="grade-column">{{ langStore.strings.gradetable_header_grade1 || 'ФРТК1' }}</th>
            <th scope="col" class="grade-column">{{ langStore.strings.gradetable_header_grade2 || 'ФРТК2' }}</th>
            <th scope="col" class="grade-column">{{ langStore.strings.gradetable_header_grade3 || 'Индивидуальные достижения' }}</th>
            <th scope="col" class="grade-column">{{ langStore.strings.total_grade || 'Итоговый балл' }}</th>
            <th scope="col" class="grade-column">{{ langStore.strings.average_grade || 'Средний балл' }}</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="grade-column">{{ formatGrade(grade1) }}</td>
            <td class="grade-column">{{ formatGrade(grade2) }}</td>
            <td class="grade-column">{{ formatGrade(grade3) }}</td>
            <td class="grade-column total-grade">{{ formatGrade(totalGrade) }}</td>
            <td class="grade-column average-grade">{{ formatGrade(computedAverageGrade) }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, nextTick, computed } from 'vue';
import { useGeneralStore } from '../store/storeGeneral';
import { useLangStore } from '../store/storeLang';
import * as moodleAjax from 'core/ajax';
import notification from 'core/notification';
import { formatGradeWithPercentage, getMaxGradeFromScale } from '../utils/gradeFormatting';

const generalStore = useGeneralStore();
const langStore = useLangStore();
const loading = ref(true);

const props = defineProps({
  courseId: {
    type: [String, Number],
    required: true
  },
  grade1: {
    type: [String, Number],
    default: null
  },
  grade2: {
    type: [String, Number],
    default: null
  },
  grade3: {
    type: [String, Number],
    default: null
  },
  totalGrade: {
    type: [String, Number],
    default: null
  },
  averageGrade: {
    type: [String, Number],
    default: null
  }
});

const emit = defineEmits(['grades-loaded']);

// Вычисленное свойство для среднего балла за дисциплину
const computedAverageGrade = computed(() => {
  if (props.averageGrade !== null && props.averageGrade !== undefined) {
    return props.averageGrade;
  }
  
  // Если средний балл не передан, вычисляем его из имеющихся оценок
  const validGrades = [props.grade1, props.grade2, props.grade3]
    .filter(grade => grade !== null && grade !== undefined && !isNaN(grade));
  
  if (validGrades.length === 0) {
    return null;
  }
  
  const sum = validGrades.reduce((acc, grade) => acc + parseFloat(grade), 0);
  return (sum / validGrades.length).toFixed(2);
});

// Функция форматирования оценок
const formatGrade = (grade) => {
  if (grade === null || grade === undefined) {
    return '-';
  }
  
  const numGrade = parseFloat(grade);
  if (isNaN(numGrade)) {
    return grade.toString();
  }
  
  // Получаем максимальную оценку из шкалы курса
  const course = generalStore.getCourse(props.courseId);
  const maxGrade = course?.scale ? getMaxGradeFromScale(course.scale) : 100;
  
  return formatGradeWithPercentage(grade, course?.scale, maxGrade);
};

const loadGrades = async () => {
  // Проверяем наличие courseId перед загрузкой
  if (!props.courseId) {
    // CourseId is required for loading grades
    loading.value = false;
    return;
  }

  // Устанавливаем loading в true и ждем следующего тика для отрисовки
  loading.value = true;
  await nextTick();

  try {
    // Получаем конфиг для данного курса из store
    const courseConfig = generalStore.getCourseConfig(props.courseId);
    if (!courseConfig) {
      throw new Error('Configuration not found for this course');
    }

    const result = await moodleAjax.call([{
      methodname: 'block_cdo_showcase_get_user_grades_by_config',
      args: {
        configid: courseConfig.id,
        courseid: props.courseId,
        email: generalStore.userEmail
      }
    }])[0];

    // Эмитим событие с загруженными оценками
    emit('grades-loaded', result);
    
  } catch (error) {
    // Error loading grades
    await notification.addNotification({
      message: error.message || 'Error loading grades',
      type: 'error'
    });
  } finally {
    // Добавляем небольшую задержку перед скрытием прогресс-бара
    // чтобы пользователь успел его увидеть
    setTimeout(() => {
      loading.value = false;
    }, 300);
  }
};

// Загружаем оценки только если есть courseId
onMounted(() => {
  // Отключаем автоматическую загрузку - оценки должны приходить через props
  loading.value = false;
});

// Следим за изменением courseId
watch(() => props.courseId, async (newId, oldId) => {
  // Отключаем автоматическую загрузку при изменении courseId
  loading.value = false;
}, { immediate: true });

</script>

<style scoped>
.grade-table-container {
  position: relative;
  min-height: 100px;
  width: 100%;
  max-width: 100%;
  margin: 0 auto;
  padding: 1rem;
  height: auto;
  display: flex;
  flex-direction: column;
}

.table-responsive {
  width: 100%;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  min-height: 120px;
}

.table {
  width: 100%;
  margin-bottom: 0;
  font-size: 0.9rem;
  table-layout: fixed;
  border-collapse: separate;
  border-spacing: 0;
}

.table thead {
  height: 48px;
}

.table th {
  background-color: #f8f9fa;
  font-weight: 600;
  white-space: normal;
  height: 48px;
  vertical-align: middle;
  padding: 0.5rem;
  position: sticky;
  top: 0;
  z-index: 1;
}

.table td {
  white-space: normal;
  height: 48px;
  vertical-align: middle;
  padding: 0.5rem;
}

.grade-column {
  width: 20%;
  min-width: 120px;
  text-align: center;
  vertical-align: middle;
  word-wrap: break-word;
}

.total-grade {
  font-weight: 600;
  color: #0d6efd;
}

.average-grade {
  font-weight: 600;
  color: #198754;
}

/* Стили для прогресс-бара */
.progress-loader {
  padding: 2rem 1rem;
}

.progress {
  height: 1.5rem;
  background-color: #e9ecef;
  border-radius: 0.5rem;
  overflow: hidden;
}

.progress-bar {
  background-color: #007bff;
  color: white;
  font-size: 0.875rem;
  font-weight: 500;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* Анимация появления таблицы */
.table-responsive {
  animation: fadeIn 0.3s ease-in-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Медиа-запросы для адаптивности */
@media (max-width: 768px) {
  .grade-table-container {
    padding: 0.5rem;
  }
  
  .table {
    font-size: 0.8rem;
    min-width: 500px; /* Минимальная ширина для 5 колонок */
  }
  
  .grade-column {
    min-width: 90px;
    padding: 0.375rem 0.25rem;
  }
  
  .table th {
    font-size: 0.75rem;
    line-height: 1.1;
  }
}

@media (max-width: 576px) {
  .grade-table-container {
    padding: 0.25rem;
  }
  
  .table {
    font-size: 0.7rem;
    min-width: 450px;
  }
  
  .grade-column {
    min-width: 80px;
    padding: 0.25rem 0.125rem;
  }
  
  .table th {
    font-size: 0.65rem;
    line-height: 1;
    padding: 0.25rem 0.125rem;
  }
  
  /* Сокращенные заголовки для мобильных */
  .table th:nth-child(3)::after {
    content: " (ИД)";
  }
  
  .table th:nth-child(4)::after {
    content: " (ИБ)";
  }
  
  .table th:nth-child(5)::after {
    content: " (СБ)";
  }
}
</style> 