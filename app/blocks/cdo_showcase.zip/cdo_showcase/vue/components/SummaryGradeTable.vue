<template>
  <div class="summary-grade-table-container">
    <!-- Прогресс загрузки -->
    <div v-if="loading" class="progress-loader">
      <div class="progress">
        <div class="progress-bar progress-bar-striped progress-bar-animated" 
             role="progressbar" 
             aria-valuenow="100" 
             aria-valuemin="0" 
             aria-valuemax="100" 
             style="width: 100%">
          {{ langStore.strings.summary_loading || 'Загрузка сводной информации...' }}
        </div>
      </div>
    </div>

    <!-- Основной контент -->
    <div v-else class="summary-content">
      <!-- Заголовок сводной таблицы -->
      <div class="summary-header mb-4">
        <div class="row align-items-center">
          <div class="col-md-8">
            <h4 class="mb-1">
              <i class="fa fa-chart-bar me-2 text-primary"></i>
              {{ langStore.strings.summary_title || 'Сводная таблица успеваемости' }}
            </h4>
            <p class="text-muted mb-0">
              {{ langStore.strings.summary_description || 'Агрегированные данные по всем курсам и студентам' }}
            </p>
          </div>
          <div class="col-md-4 text-end">
            <!-- Статистика -->
            <div class="summary-stats">
              <div class="stat-item">
                <small class="text-muted">{{ langStore.strings.total_courses || 'Всего курсов' }}</small>
                <div class="stat-value">{{ totalCourses }}</div>
              </div>
              <div class="stat-item">
                <small class="text-muted">{{ langStore.strings.total_students || 'Всего студентов' }}</small>
                <div class="stat-value">{{ totalUniqueStudents }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Поиск студентов -->
      <div class="search-section mb-3">
        <div class="row align-items-center">
          <div class="col-md-6">
            <div class="search-box">
              <input 
                v-model="searchQuery" 
                type="text" 
                class="form-control" 
                :placeholder="langStore.strings.search_student || 'Поиск студента...'"
                @input="onSearch">
              <i class="fa fa-search search-icon"></i>
            </div>
          </div>
          <div class="col-md-6 text-end">
            <small class="text-muted">
              {{ langStore.strings.showing || 'Показано' }}: {{ filteredStudents.length }} 
              {{ langStore.strings.students || 'студентов' }}
            </small>
          </div>
        </div>
      </div>

      <!-- Подсказка для мобильных устройств -->
      <div class="mobile-scroll-hint d-md-none mb-2">
        <small class="text-muted">
          <i class="fa fa-hand-point-right me-1"></i>
          {{ langStore.strings.scroll_horizontally || 'Прокрутите горизонтально для просмотра всех колонок' }}
        </small>
      </div>

      <!-- Сводная таблица -->
      <div class="table-responsive">
        <table class="table table-bordered table-hover">
          <thead class="table-header-sticky">
            <tr>
              <th scope="col" class="student-column">
                {{ langStore.strings.student_name || 'Студент' }}
              </th>
              <th scope="col" class="grade-column text-center">
                {{ langStore.strings.avg_frtk1 || 'Средний ФРТК1' }}
              </th>
              <th scope="col" class="grade-column text-center">
                {{ langStore.strings.avg_frtk2 || 'Средний ФРТК2' }}
              </th>
              <th scope="col" class="grade-column text-center">
                {{ langStore.strings.avg_individual || 'Средние инд. достижения' }}
              </th>
              <th scope="col" class="total-column text-center">
                {{ langStore.strings.overall_average || 'Общий средний' }}
              </th>
              <th scope="col" class="courses-column text-center">
                {{ langStore.strings.courses_count || 'Курсов' }}
              </th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="student in paginatedStudents" 
                :key="student.id" 
                class="student-row">
              <td class="student-info">
                <div class="d-flex align-items-center">
                  <img v-if="student.profileimageurlsmall" 
                       :src="student.profileimageurlsmall" 
                       :alt="student.fullname"
                       class="student-avatar me-2">
                  <i v-else class="fa fa-user-circle text-secondary me-2 student-icon"></i>
                  <div>
                    <div class="student-name">{{ student.fullname }}</div>
                    <small class="text-muted">{{ student.email }}</small>
                  </div>
                </div>
              </td>
              <td class="grade-cell text-center">
                <span class="summary-grade-badge" :class="getSummaryGradeClass(student.averages.frtk1)">
                  {{ formatSummaryGrade(student.averages.frtk1) }}
                </span>
                <div class="grade-details">
                  <small class="text-muted">{{ student.counts.frtk1 }} курс(ов)</small>
                </div>
              </td>
              <td class="grade-cell text-center">
                <span class="summary-grade-badge" :class="getSummaryGradeClass(student.averages.frtk2)">
                  {{ formatSummaryGrade(student.averages.frtk2) }}
                </span>
                <div class="grade-details">
                  <small class="text-muted">{{ student.counts.frtk2 }} курс(ов)</small>
                </div>
              </td>
              <td class="grade-cell text-center">
                <span class="summary-grade-badge" :class="getSummaryGradeClass(student.averages.individual)">
                  {{ formatSummaryGrade(student.averages.individual) }}
                </span>
                <div class="grade-details">
                  <small class="text-muted">{{ student.counts.individual }} курс(ов)</small>
                </div>
              </td>
              <td class="total-cell text-center">
                <span class="summary-total-badge" :class="getSummaryTotalGradeClass(student.averages.overall)">
                  {{ formatSummaryGrade(student.averages.overall) }}
                </span>
                <div class="grade-details">
                  <small class="text-muted">{{ student.averages.overallCount }} оценок</small>
                </div>
              </td>
              <td class="courses-cell text-center">
                <span class="courses-badge">
                  {{ student.coursesCount }}
                </span>
                <div class="grade-details">
                  <small class="text-muted">из {{ totalCourses }}</small>
                </div>
              </td>
            </tr>
            <tr v-if="filteredStudents.length === 0" class="empty-row">
              <td colspan="6" class="text-center text-muted py-4">
                <i class="fa fa-users fa-2x mb-2"></i><br>
                {{ searchQuery ? 
                   (langStore.strings.no_students_found || 'Студенты не найдены') :
                   (langStore.strings.no_students || 'Нет данных о студентах') 
                }}
              </td>
            </tr>
            
            <!-- Общая строка со средними по всем студентам -->
            <tr v-if="filteredStudents.length > 0" class="global-average-row">
              <td class="average-label">
                <div class="d-flex align-items-center">
                  <i class="fa fa-globe text-success me-2"></i>
                  <div>
                    <div class="average-title">{{ langStore.strings.global_average || 'Общий средний по группе' }}</div>
                    <small class="text-muted">
                      {{ langStore.strings.all_students || 'Все студенты' }}
                    </small>
                  </div>
                </div>
              </td>
              <td class="average-cell text-center">
                <span class="global-average-badge" :class="getSummaryGradeClass(globalAverages.frtk1)">
                  {{ formatSummaryGrade(globalAverages.frtk1) }}
                </span>
              </td>
              <td class="average-cell text-center">
                <span class="global-average-badge" :class="getSummaryGradeClass(globalAverages.frtk2)">
                  {{ formatSummaryGrade(globalAverages.frtk2) }}
                </span>
              </td>
              <td class="average-cell text-center">
                <span class="global-average-badge" :class="getSummaryGradeClass(globalAverages.individual)">
                  {{ formatSummaryGrade(globalAverages.individual) }}
                </span>
              </td>
              <td class="average-cell text-center">
                <span class="global-total-badge" :class="getSummaryTotalGradeClass(globalAverages.overall)">
                  {{ formatSummaryGrade(globalAverages.overall) }}
                </span>
              </td>
              <td class="average-cell text-center">
                <span class="global-courses-badge">
                  {{ globalAverages.averageCoursesPerStudent.toFixed(1) }}
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Пагинация -->
      <div v-if="totalPages > 1" class="pagination-container">
        <nav aria-label="Summary pagination">
          <ul class="pagination pagination-sm justify-content-center">
            <li class="page-item" :class="{ disabled: currentPage === 1 }">
              <button class="page-link" @click="goToPage(1)" :disabled="currentPage === 1">
                <i class="fa fa-angle-double-left"></i>
              </button>
            </li>
            <li class="page-item" :class="{ disabled: currentPage === 1 }">
              <button class="page-link" @click="goToPage(currentPage - 1)" :disabled="currentPage === 1">
                <i class="fa fa-angle-left"></i>
              </button>
            </li>
            
            <li v-for="page in visiblePages" 
                :key="page" 
                class="page-item" 
                :class="{ active: page === currentPage }">
              <button class="page-link" @click="goToPage(page)">
                {{ page }}
              </button>
            </li>
            
            <li class="page-item" :class="{ disabled: currentPage === totalPages }">
              <button class="page-link" @click="goToPage(currentPage + 1)" :disabled="currentPage === totalPages">
                <i class="fa fa-angle-right"></i>
              </button>
            </li>
            <li class="page-item" :class="{ disabled: currentPage === totalPages }">
              <button class="page-link" @click="goToPage(totalPages)" :disabled="currentPage === totalPages">
                <i class="fa fa-angle-double-right"></i>
              </button>
            </li>
          </ul>
        </nav>
        
        <!-- Информация о пагинации -->
        <div class="pagination-info text-center mt-2">
          <small class="text-muted">
            {{ langStore.strings.showing || 'Показано' }} 
            {{ startIndex + 1 }}-{{ Math.min(endIndex, filteredStudents.length) }} 
            {{ langStore.strings.of || 'из' }} 
            {{ filteredStudents.length }} 
            {{ langStore.strings.students || 'студентов' }}
          </small>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch, nextTick } from 'vue';
import { useGeneralStore } from '../store/storeGeneral';
import { useLangStore } from '../store/storeLang';
import { formatGradeWithPercentage, getMaxGradeFromScale, getGradeClass, getTotalGradeClass } from '../utils/gradeFormatting';
import { CATEGORY_KEYWORDS, getCategoryType } from '../store/constants';

const generalStore = useGeneralStore();
const langStore = useLangStore();

const props = defineProps({
  studentsPerPage: {
    type: Number,
    default: 15
  }
});

// Состояние компонента
const loading = ref(true);
const searchQuery = ref('');
const currentPage = ref(1);

// Функция парсинга оценок (такая же как в StudentsGradeTable)
function parseStudentGrades(gradeitems) {
  const grades = {
    frtk1: null,
    frtk2: null,
    individual: null,
    total: null
  };

  // Используем константы из store
  const categoryKeywords = CATEGORY_KEYWORDS;

  const categories = {};
  
  gradeitems.forEach(item => {
    if (item.itemtype === 'category') {
      categories[item.id] = {
        id: item.id,
        name: item.itemname || '',
        gradeValue: item.graderaw,
        weight: item.weightraw,
        instance: item.iteminstance
      };
    } else if (item.itemtype === 'course') {
      grades.total = item.graderaw;
    }
  });

  const categoryKeys = Object.keys(categories);
  const sortedCategories = categoryKeys.sort((a, b) => {
    const catA = categories[a];
    const catB = categories[b];
    
    if (catA.weight !== undefined && catB.weight !== undefined) {
      return catB.weight - catA.weight;
    }
    
    return parseInt(a) - parseInt(b);
  });


  sortedCategories.forEach((categoryId, index) => {
    const category = categories[categoryId];
    
    // Определяем тип категории используя функцию из store
    const categoryType = getCategoryType(category.name);

    if (categoryType && category.gradeValue !== null && category.gradeValue !== undefined) {
      grades[categoryType] = category.gradeValue;
    }
  });

  return grades;
}

// Агрегация данных по всем курсам
const aggregatedStudents = computed(() => {
  const studentMap = new Map();

  // Проходим по всем курсам
  generalStore.userCourses.forEach(courseItem => {
    const course = courseItem.course;
    
    if (!course.user_grades?.usergrades) return;

    // Проходим по всем студентам в курсе
    course.user_grades.usergrades.forEach(usergrade => {
      const studentId = usergrade.userid;
      const studentData = course.enrolled_users?.find(user => user.id === studentId) || {};
      
      if (!studentMap.has(studentId)) {
        studentMap.set(studentId, {
          id: studentId,
          fullname: usergrade.userfullname,
          email: studentData.email || '',
          profileimageurlsmall: studentData.profileimageurlsmall || '',
          courses: [],
          grades: {
            frtk1: [],
            frtk2: [],
            individual: [],
            total: []
          }
        });
      }

      const student = studentMap.get(studentId);
      const grades = parseStudentGrades(usergrade.gradeitems || []);
      
      student.courses.push({
        courseId: course.id,
        courseName: course.fullname,
        grades: grades
      });

      // Добавляем оценки в массивы для расчета средних
      if (grades.frtk1 !== null && grades.frtk1 !== undefined) {
        student.grades.frtk1.push(parseFloat(grades.frtk1));
      }
      if (grades.frtk2 !== null && grades.frtk2 !== undefined) {
        student.grades.frtk2.push(parseFloat(grades.frtk2));
      }
      if (grades.individual !== null && grades.individual !== undefined) {
        student.grades.individual.push(parseFloat(grades.individual));
      }
      if (grades.total !== null && grades.total !== undefined) {
        student.grades.total.push(parseFloat(grades.total));
      }
    });
  });

  // Вычисляем средние для каждого студента
  return Array.from(studentMap.values()).map(student => {
    const averages = {
      frtk1: student.grades.frtk1.length > 0 
        ? student.grades.frtk1.reduce((a, b) => a + b, 0) / student.grades.frtk1.length 
        : null,
      frtk2: student.grades.frtk2.length > 0 
        ? student.grades.frtk2.reduce((a, b) => a + b, 0) / student.grades.frtk2.length 
        : null,
      individual: student.grades.individual.length > 0 
        ? student.grades.individual.reduce((a, b) => a + b, 0) / student.grades.individual.length 
        : null,
    };

    // Общий средний балл (по всем непустым типам оценок)
    const allGrades = [
      ...student.grades.frtk1,
      ...student.grades.frtk2,
      ...student.grades.individual
    ];
    
    averages.overall = allGrades.length > 0 
      ? allGrades.reduce((a, b) => a + b, 0) / allGrades.length 
      : null;
    averages.overallCount = allGrades.length;

    return {
      ...student,
      averages,
      counts: {
        frtk1: student.grades.frtk1.length,
        frtk2: student.grades.frtk2.length,
        individual: student.grades.individual.length,
        total: student.grades.total.length
      },
      coursesCount: student.courses.length
    };
  });
});

// Статистика
const totalCourses = computed(() => generalStore.userCourses.length);
const totalUniqueStudents = computed(() => aggregatedStudents.value.length);

// Поиск и фильтрация
const filteredStudents = computed(() => {
  if (!searchQuery.value.trim()) {
    return aggregatedStudents.value;
  }

  const query = searchQuery.value.toLowerCase().trim();
  return aggregatedStudents.value.filter(student => 
    student.fullname.toLowerCase().includes(query) ||
    student.email.toLowerCase().includes(query)
  );
});

// Глобальные средние по всем студентам
const globalAverages = computed(() => {
  if (filteredStudents.value.length === 0) {
    return {
      frtk1: null,
      frtk2: null,
      individual: null,
      overall: null,
      averageCoursesPerStudent: 0
    };
  }

  const sums = {
    frtk1: { total: 0, count: 0 },
    frtk2: { total: 0, count: 0 },
    individual: { total: 0, count: 0 },
    overall: { total: 0, count: 0 }
  };

  let totalCoursesSum = 0;

  filteredStudents.value.forEach(student => {
    totalCoursesSum += student.coursesCount;

    Object.keys(sums).forEach(gradeType => {
      const average = student.averages[gradeType];
      if (average !== null && average !== undefined && !isNaN(average)) {
        sums[gradeType].total += parseFloat(average);
        sums[gradeType].count++;
      }
    });
  });

  return {
    frtk1: sums.frtk1.count > 0 ? sums.frtk1.total / sums.frtk1.count : null,
    frtk2: sums.frtk2.count > 0 ? sums.frtk2.total / sums.frtk2.count : null,
    individual: sums.individual.count > 0 ? sums.individual.total / sums.individual.count : null,
    overall: sums.overall.count > 0 ? sums.overall.total / sums.overall.count : null,
    averageCoursesPerStudent: filteredStudents.value.length > 0 ? totalCoursesSum / filteredStudents.value.length : 0
  };
});

// Пагинация
const totalPages = computed(() => Math.ceil(filteredStudents.value.length / props.studentsPerPage));
const startIndex = computed(() => (currentPage.value - 1) * props.studentsPerPage);
const endIndex = computed(() => startIndex.value + props.studentsPerPage);

const paginatedStudents = computed(() => {
  return filteredStudents.value.slice(startIndex.value, endIndex.value);
});

const visiblePages = computed(() => {
  const pages = [];
  const maxVisiblePages = 5;
  let start = Math.max(1, currentPage.value - Math.floor(maxVisiblePages / 2));
  let end = Math.min(totalPages.value, start + maxVisiblePages - 1);

  if (end - start < maxVisiblePages - 1) {
    start = Math.max(1, end - maxVisiblePages + 1);
  }

  for (let i = start; i <= end; i++) {
    pages.push(i);
  }

  return pages;
});

// Методы компонента
function goToPage(page) {
  if (page >= 1 && page <= totalPages.value) {
    currentPage.value = page;
  }
}

function onSearch() {
  currentPage.value = 1;
}

function formatSummaryGrade(grade) {
  if (grade === null || grade === undefined) {
    return '-';
  }
  
  const numGrade = parseFloat(grade);
  if (isNaN(numGrade)) {
    return grade.toString();
  }
  
  // Для сводной таблицы используем стандартную максимальную оценку 100
  // так как это агрегированные данные из разных курсов
  return formatGradeWithPercentage(grade, null, 100);
}

function getSummaryGradeClass(grade) {
  if (grade === null || grade === undefined) {
    return 'summary-grade-empty';
  }
  
  const numGrade = parseFloat(grade);
  if (isNaN(numGrade)) {
    return 'summary-grade-empty';
  }
  
  // Для сводной таблицы используем стандартную максимальную оценку 100
  return getGradeClass(grade, 100);
}

function getSummaryTotalGradeClass(grade) {
  if (grade === null || grade === undefined) {
    return 'summary-total-grade-empty';
  }
  
  const numGrade = parseFloat(grade);
  if (isNaN(numGrade)) {
    return 'summary-total-grade-empty';
  }
  
  // Для сводной таблицы используем стандартную максимальную оценку 100
  return getTotalGradeClass(grade, 100);
}

// Следим за изменениями
watch(searchQuery, () => {
  currentPage.value = 1;
});

// Инициализация
onMounted(async () => {
  await nextTick();
  loading.value = false;
});
</script>

<style scoped>
.summary-grade-table-container {
  position: relative;
  width: 100%;
  margin: 0 auto;
  padding: 1rem;
}

/* Прогресс-бар */
.progress-loader {
  padding: 2rem 1rem;
}

.progress {
  height: 1.5rem;
  background-color: #e9ecef;
  border-radius: 0.5rem;
  overflow: hidden;
}

.progress-bar {
  background-color: #007bff;
  color: white;
  font-size: 0.875rem;
  font-weight: 500;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* Заголовок */
.summary-header h4 {
  color: #333;
  font-weight: 600;
}

.summary-stats {
  display: flex;
  gap: 1rem;
}

.stat-item {
  text-align: center;
}

.stat-value {
  font-size: 1.5rem;
  font-weight: 700;
  color: #007bff;
}

/* Поиск */
.search-box {
  position: relative;
}

.search-box input {
  padding-right: 2.5rem;
}

.search-icon {
  position: absolute;
  right: 0.75rem;
  top: 50%;
  transform: translateY(-50%);
  color: #6c757d;
  pointer-events: none;
}

/* Подсказка для мобильных устройств */
.mobile-scroll-hint {
  text-align: center;
  padding: 0.5rem;
  background-color: #f8f9fa;
  border-radius: 0.25rem;
  border-left: 3px solid #007bff;
}

/* Таблица */
.table-responsive {
  border-radius: 0.5rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  overflow-x: auto;
  overflow-y: visible;
  -webkit-overflow-scrolling: touch;
  max-width: 100%;
}

.table {
  margin-bottom: 0;
  font-size: 0.9rem;
  min-width: 700px;
  table-layout: auto;
}

.table-header-sticky {
  background-color: #f8f9fa;
  position: sticky;
  top: 0;
  z-index: 10;
}

.table th {
  border-bottom: 2px solid #dee2e6;
  font-weight: 600;
  padding: 0.75rem 0.5rem;
  vertical-align: middle;
  line-height: 1.2;
  height: auto;
  min-height: 60px;
}

.table td {
  padding: 0.75rem 0.5rem;
  vertical-align: middle;
  border-bottom: 1px solid #dee2e6;
}

/* Колонки */
.student-column {
  width: 30%;
  min-width: 200px;
  max-width: 300px;
}

.grade-column {
  width: 15%;
  min-width: 120px;
  max-width: 150px;
}

.total-column {
  width: 15%;
  min-width: 120px;
  max-width: 150px;
}

.courses-column {
  width: 10%;
  min-width: 80px;
  max-width: 100px;
}

/* Информация о студенте */
.student-info {
  max-width: 300px;
  overflow: hidden;
}

.student-info .d-flex {
  align-items: center;
  min-width: 0;
}

.student-info div:last-child {
  min-width: 0;
  flex: 1;
}

.student-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  object-fit: cover;
  flex-shrink: 0;
}

.student-icon {
  font-size: 1.5rem;
  flex-shrink: 0;
}

.student-name {
  font-weight: 500;
  color: #333;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  line-height: 1.2;
}

.student-info small {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 0.75rem;
}

/* Оценки в сводной таблице */
.summary-grade-badge, .summary-total-badge {
  display: inline-block;
  padding: 0.25rem 0.5rem;
  border-radius: 0.25rem;
  font-weight: 600;
  min-width: 50px;
  font-size: 0.85rem;
  margin-bottom: 0.25rem;
}

.grade-details {
  margin-top: 0.25rem;
}

.grade-details small {
  font-size: 0.7rem;
}

/* Цвета для сводных оценок */
.summary-grade-empty, .summary-total-grade-empty {
  background-color: #f8f9fa;
  color: #6c757d;
  border: 1px solid #dee2e6;
}

.summary-grade-excellent {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.summary-grade-good {
  background-color: #d1ecf1;
  color: #0c5460;
  border: 1px solid #bee5eb;
}

.summary-grade-satisfactory {
  background-color: #fff3cd;
  color: #856404;
  border: 1px solid #ffeaa7;
}

.summary-grade-poor {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}

.summary-total-grade-excellent {
  background-color: #28a745;
  color: white;
}

.summary-total-grade-good {
  background-color: #17a2b8;
  color: white;
}

.summary-total-grade-satisfactory {
  background-color: #ffc107;
  color: #212529;
}

.summary-total-grade-poor {
  background-color: #dc3545;
  color: white;
}

/* Счетчик курсов */
.courses-badge {
  display: inline-block;
  padding: 0.25rem 0.5rem;
  border-radius: 0.25rem;
  font-weight: 600;
  min-width: 40px;
  font-size: 0.9rem;
  background-color: #e3f2fd;
  color: #1976d2;
  border: 1px solid #bbdefb;
  margin-bottom: 0.25rem;
}

/* Строки таблицы */
.student-row:hover {
  background-color: #f8f9fa;
}

.empty-row td {
  padding: 3rem 1rem;
}

/* Глобальная строка средних */
.global-average-row {
  background-color: #e8f5e8;
  border-top: 3px solid #28a745;
  font-weight: 600;
}

.global-average-row:hover {
  background-color: #e8f5e8;
}

.average-label {
  background-color: #d4edda;
  border-right: 1px solid #dee2e6;
}

.average-title {
  font-weight: 700;
  color: #155724;
  font-size: 0.9rem;
}

.average-cell {
  background-color: #e8f5e8;
}

.global-average-badge, .global-total-badge, .global-courses-badge {
  display: inline-block;
  padding: 0.375rem 0.75rem;
  border-radius: 0.375rem;
  font-weight: 700;
  min-width: 60px;
  font-size: 0.9rem;
  border: 2px solid #28a745;
  background-color: #28a745;
  color: white;
}

/* Пагинация */
.pagination-container {
  margin-top: 1.5rem;
}

.pagination .page-link {
  color: #007bff;
  border-color: #dee2e6;
  padding: 0.375rem 0.75rem;
}

.pagination .page-link:hover {
  color: #0056b3;
  background-color: #e9ecef;
  border-color: #dee2e6;
}

.pagination .page-item.active .page-link {
  background-color: #007bff;
  border-color: #007bff;
  color: white;
}

.pagination .page-item.disabled .page-link {
  color: #6c757d;
  background-color: #fff;
  border-color: #dee2e6;
  cursor: not-allowed;
}

.pagination-info {
  margin-top: 0.5rem;
}

/* Анимация появления */
.summary-content {
  animation: fadeIn 0.3s ease-in-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Адаптивность */
@media (max-width: 992px) {
  .summary-grade-table-container {
    padding: 0.75rem;
  }
  
  .table {
    min-width: 650px;
  }
  
  .summary-stats {
    flex-direction: column;
    gap: 0.5rem;
  }
}

@media (max-width: 768px) {
  .summary-grade-table-container {
    padding: 0.5rem;
  }
  
  .table {
    font-size: 0.8rem;
    min-width: 600px;
  }
  
  .table th, .table td {
    padding: 0.5rem 0.375rem;
  }
  
  .student-column {
    min-width: 180px;
  }
  
  .grade-column, .total-column {
    min-width: 100px;
  }
  
  .courses-column {
    min-width: 70px;
  }
  
  .student-avatar {
    width: 28px;
    height: 28px;
  }
  
  .student-icon {
    font-size: 1.25rem;
  }
  
  .summary-header .row {
    flex-direction: column;
    gap: 1rem;
  }
  
  .search-section .row {
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .search-section .col-md-6:last-child {
    text-align: start !important;
  }
}

@media (max-width: 576px) {
  .summary-grade-table-container {
    padding: 0.25rem;
  }
  
  .table {
    font-size: 0.75rem;
    min-width: 550px;
  }
  
  .table th, .table td {
    padding: 0.375rem 0.25rem;
  }
  
  .student-column {
    min-width: 160px;
  }
  
  .grade-column, .total-column {
    min-width: 90px;
  }
  
  .courses-column {
    min-width: 60px;
  }
  
  .summary-grade-badge, .summary-total-badge {
    padding: 0.125rem 0.25rem;
    font-size: 0.7rem;
    min-width: 40px;
  }
  
  .courses-badge {
    padding: 0.125rem 0.25rem;
    font-size: 0.75rem;
    min-width: 30px;
  }
  
  .student-avatar {
    width: 24px;
    height: 24px;
  }
  
  .student-icon {
    font-size: 1rem;
  }
  
  .student-name {
    font-size: 0.8rem;
  }
  
  .student-info small {
    font-size: 0.65rem;
  }
  
  .grade-details small {
    font-size: 0.6rem;
  }
  
  .stat-value {
    font-size: 1.2rem;
  }
}
</style> 