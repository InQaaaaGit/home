import confirm_deleted from 'tool_cdo_config/modals/confirm_deleted';

export const init = () => {
    (new confirm_deleted()).init();
};
