import { createRouter, createWebHashHistory } from 'vue-router';
import Showcase from './components/Showcase.vue';
import CourseDetail from './components/CourseDetail.vue';
import StudentsGradeTable from './components/StudentsGradeTable.vue';
import GlobalSummary from './components/GlobalSummary.vue';

const routes = [
  {
    path: '/',
    name: 'showcase',
    component: Showcase,
    meta: {
      transition: 'fade'
    }
  },
  {
    path: '/course/:courseId',
    name: 'CourseDetail',
    component: CourseDetail,
    props: true,
    meta: {
      transition: 'fade'
    }
  },
  {
    path: '/course/:courseId/grades',
    name: 'StudentsGradeTable',
    component: StudentsGradeTable,
    props: true,
    meta: {
      transition: 'fade'
    }
  },
  {
    path: '/summary',
    name: 'GlobalSummary',
    component: GlobalSummary,
    meta: {
      transition: 'fade'
    }
  }
];

const router = createRouter({
  history: createWebHashHistory(),
  routes
});

// Добавляем глобальный хук навигации
router.afterEach(() => {
  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  });
});

export default router; 