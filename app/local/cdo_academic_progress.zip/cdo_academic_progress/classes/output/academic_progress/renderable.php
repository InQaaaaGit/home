<?php

namespace local_cdo_academic_progress\output\academic_progress;

use coding_exception;
use renderer_base;
use Throwable;
use tool_cdo_config\di;
use tool_cdo_config\exceptions\cdo_config_exception;
use tool_cdo_config\exceptions\cdo_type_response_exception;

class renderable implements \renderable, \templatable
{
    private string $template = 'local_cdo_academic_progress/main';

    public function get_file_rpd(string $guid_file)
    {
        $options = di::get_instance()->get_request_options();
        $options->set_properties(["file_id" => $guid_file]);

        try {
            return [
                'file_body' => di::get_instance()
                    ->get_request('get_file_binary')
                    ->request($options)
                    ->get_request_result()
            ];
        } catch (Throwable $e) {
            return [
                'error_message' => $e->getMessage()
            ];
        }
    }

    /**
     * @throws cdo_type_response_exception
     * @throws cdo_config_exception
     * @throws coding_exception
     */
    public function get_academic_progress(): array
    {
        global $USER;

        $options = di::get_instance()->get_request_options();
        $options->set_properties(["id" => $USER->id]);
        if (is_siteadmin()) {
            $options->set_properties(["id" => 24192078]);
        }
        #$options->set_properties(["user_id" => 5]);

        $data = di::get_instance()
            ->get_request('get_academic_progress')
            ->request($options)
            ->get_request_result()
            ->to_array();
        $i = 1;
        foreach ($data as $data_gradebook) {
            foreach ($data_gradebook['data'] as &$item) {
                //foreach ($gradebook as &$item) {
                    if ($i === 1) {
                        $item['active'] = 'active';
                        $item['show'] = 'show';
                    }
                    $i++;
                    foreach ($item['attestation'] as &$attestation) {
                        if (!empty($attestation['hours']))
                            $attestation['hours'] = $attestation['hours'] . " / " . round($attestation['hours'] / 36, 2);
                    }
                }
            //}
        }
        try {
            return [
                'progress' => $data
            ];
        } catch (Throwable $e) {
            return [
                'error_message' => $e->getMessage()
            ];
        }
    }

    /**
     * @throws cdo_type_response_exception
     * @throws cdo_config_exception
     * @throws coding_exception
     */
    public function export_for_template(renderer_base $output): array
    {
        global $USER;
        $array = $this->get_academic_progress();
        $array['template'] = $this->template;
        $array['fio'] = fullname($USER);
        return $array;
    }
}