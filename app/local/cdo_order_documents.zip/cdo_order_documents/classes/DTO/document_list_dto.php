<?php

namespace local_cdo_order_documents\DTO;

use tool_cdo_config\request\DTO\base_dto;

class document_list_dto extends base_dto
{

    protected function get_object_name(): string
    {
        return 'document_list';
    }

    public function build(object $data): base_dto
    {
      #  $this->
        return $this;
    }
}