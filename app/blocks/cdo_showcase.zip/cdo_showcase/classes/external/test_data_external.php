<?php

namespace block_cdo_showcase\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;
use context_system;
use core\exception\moodle_exception;

/**
 * External API для создания тестовых данных
 */
class test_data_external extends external_api
{
    /**
     * Returns description of create_test_users() parameters
     * @return external_function_parameters
     */
    public static function create_test_users_parameters(): external_function_parameters
    {
        return new external_function_parameters(
            array(
                'count' => new external_value(PARAM_INT, 'Number of users to create', VALUE_DEFAULT, 50)
            )
        );
    }

    /**
     * Returns description of create_test_users() result value
     * @return external_single_structure
     */
    public static function create_test_users_returns(): external_single_structure
    {
        return new external_single_structure(
            array(
                'success' => new external_value(PARAM_BOOL, 'Operation success'),
                'message' => new external_value(PARAM_TEXT, 'Result message'),
                'users_created' => new external_value(PARAM_INT, 'Number of users created'),
                'group_id' => new external_value(PARAM_INT, 'Group ID', VALUE_OPTIONAL),
                'group_name' => new external_value(PARAM_TEXT, 'Group name', VALUE_OPTIONAL)
            )
        );
    }

    /**
     * Create test users and add them to a global group
     * @param int $count Number of users to create
     * @return array
     * @throws moodle_exception
     */
    public static function create_test_users(int $count = 50): array
    {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/user/lib.php');
        require_once($CFG->dirroot . '/cohort/lib.php');
        
        // Parameter validation
        $params = self::validate_parameters(self::create_test_users_parameters(),
            array('count' => $count)
        );

        // Context validation
        $context = context_system::instance();
        self::validate_context($context);
        
        // Check capabilities
        require_capability('moodle/user:create', $context);
        require_capability('moodle/cohort:manage', $context);

        try {
            $transaction = $DB->start_delegated_transaction();
            
            // Ограничиваем количество пользователей
            $count = min(max($params['count'], 1), 100);
            
            // Создаем или находим когорту (глобальную группу)
            $cohort_name = 'CDO Showcase Test Users';
            $cohort = $DB->get_record('cohort', ['name' => $cohort_name]);
            
            if (!$cohort) {
                // Создаем когорту (глобальную группу пользователей)
                $cohort = new \stdClass();
                $cohort->contextid = $context->id; // Системный контекст
                $cohort->name = $cohort_name;
                $cohort->idnumber = 'cdo_showcase_test_users';
                $cohort->description = 'Автоматически созданная когорта для тестирования плагина CDO Showcase';
                $cohort->descriptionformat = FORMAT_HTML;
                $cohort->visible = 1;
                $cohort->timecreated = time();
                $cohort->timemodified = time();
                
                $cohort->id = cohort_add_cohort($cohort);
            }

            $users_created = 0;
            $existing_users = [];

            // Генерируем тестовых пользователей
            for ($i = 1; $i <= $count; $i++) {
                $username = "testuser_cdo_" . sprintf('%03d', $i);
                
                // Проверяем, существует ли уже такой пользователь
                if ($DB->record_exists('user', ['username' => $username])) {
                    $existing_users[] = $username;
                    continue;
                }

                $user = new \stdClass();
                $user->username = $username;
                $user->password = hash_internal_user_password('TestPassword123!');
                $user->firstname = 'Тестовый';
                $user->lastname = 'Пользователь ' . $i;
                $user->email = "testuser{$i}@cdo-showcase.test";
                $user->city = 'Москва';
                $user->country = 'RU';
                $user->confirmed = 1;
                $user->mnethostid = $CFG->mnet_localhost_id;
                $user->timecreated = time();
                $user->timemodified = time();
                
                // Создаем пользователя
                $user_id = user_create_user($user, false, false);
                
                if ($user_id) {
                    $users_created++;
                    
                    // Добавляем пользователя в когорту
                    if ($cohort) {
                        cohort_add_member($cohort->id, $user_id);
                    }
                }
            }

            $transaction->allow_commit();

            $message = "Успешно создано пользователей: {$users_created}";
            if (!empty($existing_users)) {
                $message .= ". Пропущено уже существующих: " . count($existing_users);
            }
            if ($cohort) {
                $message .= ". Когорта: {$cohort->name}";
            }

            return [
                'success' => true,
                'message' => $message,
                'users_created' => $users_created,
                'group_id' => $cohort ? $cohort->id : null,
                'group_name' => $cohort ? $cohort->name : null
            ];

        } catch (\Exception $e) {
            if (isset($transaction)) {
                $transaction->rollback($e);
            }
            
            debugging('Error in create_test_users: ' . $e->getMessage(), DEBUG_DEVELOPER);
            throw new moodle_exception('error_creating_test_users', 'block_cdo_showcase', '', $e->getMessage());
        }
    }
} 