<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

use block_cdo_showcase\external\test_data_external;

// Проверяем права доступа
admin_externalpage_setup('blocksettings_cdo_showcase_link');

$context = context_system::instance();
require_capability('moodle/user:create', $context);
require_capability('moodle/cohort:manage', $context);

// Обрабатываем POST запрос
if ($_SERVER['REQUEST_METHOD'] === 'POST' && confirm_sesskey()) {
    $count = optional_param('count', 50, PARAM_INT);
    
    try {
        // Вызываем наш external API метод
        $result = test_data_external::create_test_users($count);
        
        if ($result['success']) {
            \core\notification::add(
                $result['message'],
                \core\notification::SUCCESS
            );
        } else {
            \core\notification::add(
                'Ошибка при создании тестовых пользователей',
                \core\notification::ERROR
            );
        }
    } catch (Exception $e) {
        \core\notification::add(
            'Ошибка: ' . $e->getMessage(),
            \core\notification::ERROR
        );
    }
    
    // Перенаправляем обратно на страницу настроек
    redirect(new moodle_url('/blocks/cdo_showcase/extend_settings/settings.php'));
}

// Если это GET запрос, показываем форму подтверждения
$PAGE->set_url('/blocks/cdo_showcase/create_test_users.php');
$PAGE->set_context($context);
$PAGE->set_title(get_string('create_test_users', 'block_cdo_showcase'));
$PAGE->set_heading(get_string('create_test_users', 'block_cdo_showcase'));

echo $OUTPUT->header();

echo $OUTPUT->heading(get_string('create_test_users', 'block_cdo_showcase'));

echo html_writer::tag('p', get_string('create_test_users_desc', 'block_cdo_showcase'));

// Форма подтверждения
echo html_writer::start_tag('form', [
    'method' => 'post',
    'action' => $PAGE->url->out()
]);

echo html_writer::empty_tag('input', [
    'type' => 'hidden',
    'name' => 'sesskey',
    'value' => sesskey()
]);

echo html_writer::start_tag('div', ['class' => 'form-group']);
echo html_writer::tag('label', get_string('user_count', 'block_cdo_showcase'), [
    'for' => 'count'
]);
echo html_writer::empty_tag('input', [
    'type' => 'number',
    'name' => 'count',
    'id' => 'count',
    'value' => '50',
    'min' => '1',
    'max' => '100',
    'class' => 'form-control',
    'style' => 'width: 100px; display: inline-block; margin-left: 10px;'
]);
echo html_writer::end_tag('div');

echo html_writer::tag('div', '', ['style' => 'margin: 20px 0;']);

echo html_writer::tag('button', get_string('create_users', 'block_cdo_showcase'), [
    'type' => 'submit',
    'class' => 'btn btn-primary',
    'onclick' => 'return confirm("' . get_string('confirm_create_users', 'block_cdo_showcase') . '");'
]);

echo html_writer::tag('a', get_string('cancel'), [
    'href' => new moodle_url('/blocks/cdo_showcase/extend_settings/settings.php'),
    'class' => 'btn btn-secondary',
    'style' => 'margin-left: 10px;'
]);

echo html_writer::end_tag('form');

echo $OUTPUT->footer(); 