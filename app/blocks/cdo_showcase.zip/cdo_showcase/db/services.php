<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

$functions = [
    'block_cdo_showcase_get_settings' => [
        'classname' => 'block_cdo_showcase\external\settings_external',
        'methodname' => 'get_settings',
        'classpath' => 'blocks/cdo_showcase/classes/external/settings_external.php',
        'description' => 'Get all showcase settings',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => 'block/cdo_showcase:addinstance',
    ],
    'block_cdo_showcase_save_settings' => [
        'classname' => 'block_cdo_showcase\external\settings_external',
        'methodname' => 'save_settings',
        'classpath' => 'blocks/cdo_showcase/classes/external/settings_external.php',
        'description' => 'Save showcase settings',
        'type' => 'write',
        'ajax' => true,
        'capabilities' => 'block/cdo_showcase:addinstance',
    ],
    'block_cdo_showcase_delete_setting' => [
        'classname' => 'block_cdo_showcase\external\settings_external',
        'methodname' => 'delete_setting',
        'classpath' => 'blocks/cdo_showcase/classes/external/settings_external.php',
        'description' => 'Delete a showcase setting',
        'type' => 'write',
        'ajax' => true,
        'capabilities' => 'block/cdo_showcase:addinstance',
    ],
    'block_cdo_showcase_get_token_users' => [
        'classname' => 'block_cdo_showcase\external\token_users_external',
        'methodname' => 'get_token_users',
        'classpath' => 'blocks/cdo_showcase/classes/external/token_users_external.php',
        'description' => 'Get users assigned to a token',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => 'block/cdo_showcase:addinstance',
    ],
    'block_cdo_showcase_assign_users_to_token' => [
        'classname' => 'block_cdo_showcase\external\token_users_external',
        'methodname' => 'assign_users_to_token',
        'classpath' => 'blocks/cdo_showcase/classes/external/token_users_external.php',
        'description' => 'Assign users to a token',
        'type' => 'write',
        'ajax' => true,
        'capabilities' => 'block/cdo_showcase:addinstance',
    ],
    /*'block_cdo_showcase_get_users_courses' => [
        'classname' => 'block_cdo_showcase\api\courses',
        'methodname' => 'get_users_courses',
        'classpath' => 'blocks/cdo_showcase/classes/api/courses.php',
        'description' => '',
        'type' => 'read',
        'ajax' => true,
    ],*/
   /* 'block_cdo_showcase_get_courses' => [
        'classname' => 'block_cdo_showcase\api\courses',
        'methodname' => 'get_courses',
        'classpath' => 'blocks/cdo_showcase/classes/api/courses.php',
        'description' => '',
        'type' => 'read',
        'ajax' => true,
    ],*/
    /*'block_cdo_showcase_get_grade_items' => [
        'classname' => 'block_cdo_showcase\api\gradereport',
        'methodname' => 'get_grade_items',
        'classpath' => 'blocks/cdo_showcase/classes/api/gradereport.php',
        'description' => 'Get grade items for course, user and group',
        'type' => 'read',
        'ajax' => true,
      //  'capabilities' => 'block/cdo_showcase:view',
    ],*/
    'block_cdo_showcase_get_user_courses_by_config' => [
        'classname' => 'block_cdo_showcase\external\courses_external',
        'methodname' => 'get_user_courses_by_config',
        'classpath' => 'blocks/cdo_showcase/classes/external/courses_external.php',
        'description' => 'Get user courses by configuration ID',
        'type' => 'read',
        //'capabilities' => 'block/cdo_showcase:view',
        'ajax' => true
    ],
    'block_cdo_showcase_get_user_grades_by_config' => [
        'classname' => 'block_cdo_showcase\external\grades_external',
        'methodname' => 'get_user_grades_by_config',
        'classpath' => 'blocks/cdo_showcase/classes/external/grades_external.php',
        'description' => 'Get user grades by configuration ID and course ID',
        'type' => 'read',
        //'capabilities' => 'block/cdo_showcase:view',
        'ajax' => true
    ],
    'block_cdo_showcase_search_courses' => [
        'classname' => 'block_cdo_showcase\external\courses_external',
        'methodname' => 'search_courses',
        'classpath' => 'blocks/cdo_showcase/classes/external/courses_external.php',
        'description' => 'Search courses',
        'type' => 'read',
        'ajax' => true
    ],
    'block_cdo_showcase_save_user_courses' => [
        'classname' => 'block_cdo_showcase\external\user_courses_external',
        'methodname' => 'save_user_courses',
        'classpath' => 'blocks/cdo_showcase/classes/external/user_courses_external.php',
        'description' => 'Save courses for a user by email',
        'type' => 'write',
        'ajax' => true,
        'capabilities' => 'block/cdo_showcase:addinstance',
    ],
    'block_cdo_showcase_get_user_courses' => [
        'classname' => 'block_cdo_showcase\external\user_courses_external',
        'methodname' => 'get_user_courses',
        'classpath' => 'blocks/cdo_showcase/classes/external/user_courses_external.php',
        'description' => 'Get courses for a user by email',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => 'block/cdo_showcase:addinstance',
    ],
    'block_cdo_showcase_get_user_token_usage' => [
        'classname' => 'block_cdo_showcase\external\token_usage_external',
        'methodname' => 'get_user_token_usage',
        'classpath' => 'blocks/cdo_showcase/classes/external/token_usage_external.php',
        'description' => 'Get token usage information for a user',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => 'block/cdo_showcase:addinstance',
    ],
    'block_cdo_showcase_get_user_status' => [
        'classname' => 'block_cdo_showcase\external\user_status_external',
        'methodname' => 'get_user_status',
        'classpath' => 'blocks/cdo_showcase/classes/external/user_status_external.php',
        'description' => 'Get current user status including ROP status',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => '',
    ],
    'block_cdo_showcase_get_rop_courses' => [
        'classname' => 'block_cdo_showcase\external\rop_courses_external',
        'methodname' => 'get_rop_courses',
        'classpath' => 'blocks/cdo_showcase/classes/external/rop_courses_external.php',
        'description' => 'Get assigned courses for ROP user by email',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => '',
    ],
    'block_cdo_showcase_get_rop_config' => [
        'classname' => 'block_cdo_showcase\external\rop_courses_external',
        'methodname' => 'get_rop_config',
        'classpath' => 'blocks/cdo_showcase/classes/external/rop_courses_external.php',
        'description' => 'Get config assigned to ROP user by email',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => '',
    ],
    'block_cdo_showcase_create_test_users' => [
        'classname' => 'block_cdo_showcase\external\test_data_external',
        'methodname' => 'create_test_users',
        'classpath' => 'blocks/cdo_showcase/classes/external/test_data_external.php',
        'description' => 'Create test users and add them to a global group',
        'type' => 'write',
        'ajax' => true,
        'capabilities' => 'moodle/user:create,moodle/cohort:manage',
    ],
];

$services = [
    'cdo_block_cdo_showcase' => [
        'functions' => [
            'block_cdo_showcase_get_user_courses_by_config',
            'block_cdo_showcase_get_user_grades_by_config',
            'block_cdo_showcase_get_token_users',
            'block_cdo_showcase_assign_users_to_token',
            'block_cdo_showcase_search_courses',
            'core_course_get_courses',
            'core_webservice_get_site_info'
        ],
        'requiredcapability' => '',
        'restrictedusers' => 0,
        'enabled' => 1,
    ]
];
