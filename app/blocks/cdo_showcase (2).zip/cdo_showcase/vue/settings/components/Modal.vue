<script setup>
import { ref, watch } from 'vue';

const props = defineProps({
  show: {
    type: Boolean,
    required: true
  },
  title: {
    type: String,
    required: true
  },
  subtitle: {
    type: String,
    default: ''
  },
  icon: {
    type: String,
    default: ''
  },
  slideDirection: {
    type: String,
    default: 'slide-in'
  },
  width: {
    type: String,
    default: '600px'
  }
});

const emit = defineEmits(['close', 'save']);

const isClosing = ref(false);

watch(() => props.show, (newValue) => {
  if (!newValue) {
    isClosing.value = true;
    setTimeout(() => {
      isClosing.value = false;
    }, 300);
  }
});

const handleClose = () => {
  emit('close');
};

const handleSave = () => {
  emit('save');
};
</script>

<template>
  <div v-if="show || isClosing" class="modal-overlay" @click.self="handleClose">
    <div 
      class="modal-content" 
      :class="[slideDirection, { 'closing': isClosing }]"
      :style="{ maxWidth: width }"
    >
      <div class="modal-header">
        <h3>
          <i v-if="icon" :class="icon"></i>
          {{ title }}
          <small v-if="subtitle">{{ subtitle }}</small>
        </h3>
        <button @click="handleClose" class="close-button">
          <i class="fa fa-times"></i>
        </button>
      </div>
      <div class="modal-body">
        <slot></slot>
      </div>
      <div v-if="$slots.footer" class="modal-footer">
        <slot name="footer"></slot>
      </div>
    </div>
  </div>
</template>

<style scoped>
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
  backdrop-filter: blur(2px);
}

.modal-content {
  background-color: white;
  border-radius: 8px;
  width: 90%;
  max-height: 80vh;
  display: flex;
  flex-direction: column;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease, opacity 0.3s ease;
}

.modal-content.slide-in {
  animation: slideIn 0.3s ease forwards;
}

.modal-content.slide-out,
.modal-content.closing {
  animation: slideOut 0.3s ease forwards;
}

@keyframes slideIn {
  from {
    transform: translateX(100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}

@keyframes slideOut {
  from {
    transform: translateX(0);
    opacity: 1;
  }
  to {
    transform: translateX(100%);
    opacity: 0;
  }
}

.modal-header {
  padding: 1rem;
  border-bottom: 1px solid #dee2e6;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.modal-header h3 {
  margin: 0;
  font-size: 1.25rem;
  color: #333;
  display: flex;
  align-items: center;
  gap: 10px;
}

.modal-header h3 small {
  font-size: 0.8em;
  color: #666;
  font-weight: normal;
}

.modal-header h3 .fa {
  color: #2196F3;
}

.close-button {
  background: none;
  border: none;
  font-size: 1.25rem;
  color: #666;
  cursor: pointer;
  padding: 0.5rem;
  transition: color 0.2s ease;
}

.close-button:hover {
  color: #333;
}

.modal-body {
  padding: 1rem;
  overflow-y: auto;
  flex-grow: 1;
}

.modal-footer {
  padding: 1rem;
  border-top: 1px solid #dee2e6;
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
}

/* Анимации для кнопок в футере */
.modal-footer button {
  transition: all 0.2s ease;
}

.modal-footer button:hover {
  transform: translateY(-1px);
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.modal-footer button:active {
  transform: translateY(0);
  box-shadow: none;
}
</style> 