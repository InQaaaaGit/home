<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace block_cdo_showcase\external;

defined('MOODLE_INTERNAL') || die();

use block_cdo_showcase\external\traits\external_api_request_trait;
use block_cdo_showcase\local\controller;
use context_system;

use core_enrol_external;
use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use core_external\external_value;
use core_external\external_warnings;
use gradereport_user\external\user;


use block_cdo_showcase\local\helper\rop_courses_helper;
use dml_exception;
use moodle_exception;

global $CFG;
require_once $CFG->dirroot . '/course/externallib.php';
require_once $CFG->dirroot . '/enrol/externallib.php';
require_once $CFG->dirroot . '/grade/report/user/classes/external/user.php';

/**
 * External API class for ROP courses management
 *
 * @package    block_cdo_showcase
 * @category   external
 * @copyright  2024 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class rop_courses_external extends external_api
{
    use external_api_request_trait;

    /**
     * Returns description of get_rop_courses() parameters
     *
     * @return external_function_parameters
     */
    public static function get_rop_courses_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            'configid' => new external_value(PARAM_INT, 'Configuration ID'),
            'email' => new external_value(PARAM_EMAIL, 'User email'),
            'apiRequestParam' => new external_value(PARAM_TEXT, 'Course selection category parameter', VALUE_OPTIONAL)
        ]);
    }

    /**
     * Get assigned courses for ROP user by configuration ID and email
     *
     * @param int $configid Configuration ID
     * @param string $email User email
     * @param string $apiRequestParam Course selection category parameter
     * @return array
     * @throws moodle_exception
     */
    public static function get_rop_courses(int $configid, string $email, string $apiRequestParam = ''): array
    {
        // Parameter validation
        $params = self::validate_parameters(self::get_rop_courses_parameters(),
            array('configid' => $configid, 'email' => $email, 'apiRequestParam' => $apiRequestParam));

        // Context validation
        $context = context_system::instance();
        self::validate_context($context);

        // Get configuration
        $config = controller::get_setting($params['configid']);
        if (!$config->token_status) {
            throw new moodle_exception('invalidtoken', 'block_cdo_showcase');
        }

        try {
            // Get locally assigned courses filtered by config_id
            $assigned_rop_courses = rop_courses_helper::get_user_assigned_courses($params['email'], $params['configid']);

            if (empty($assigned_rop_courses)) {
                // Если у РОП пользователя нет назначенных курсов для данного конфига, возвращаем пустой массив
                return [];
            }

            // Extract course IDs from assigned courses
            $course_ids = array_map(function ($course) {
                return (int)$course['id'];
            }, $assigned_rop_courses);

            // Используем category_id из настроек подключения, если параметр не передан
            $apiRequestParam = !empty($params['apiRequestParam']) 
                ? $params['apiRequestParam'] 
                : (!empty($config->category_id) ? $config->category_id : get_config('block_cdo_showcase', 'api_request_param'));

            // Make request to external API to get specific courses
            $result = self::make_request(
                $config->url,
                $config->token,
                'tool_cdo_showcase_tools_get_courses',
                [
                    'options' => ['ids' => $course_ids],
                    'apiRequestParam' => $apiRequestParam
                ]
            );

            // Transform result to include assignment information
            $filtered_courses = [];
            if (is_array($result)) {
                // Create index of assigned courses for quick lookup
                $assigned_index = [];
                foreach ($assigned_rop_courses as $assigned_course) {
                    $assigned_index[$assigned_course['id']] = $assigned_course;
                }

                foreach ($result as $course) {
                    $assigned_info = $assigned_index[$course['id']];
                    $filtered_courses[] = [ //daBUm8H4V0Amu5zYAjUj
                        'id' => $course['id'],
                        'fullname' => $course['fullname'],
                        'shortname' => $course['shortname'],
                        'summary' => $course['summary'] ?? '',
                        'courseimage' => $course['courseimage'] ?? '',
                        'enrolled_users' => $course['enrolled_users'] ?? [],
                        'config_id' => $params['configid'],
                        'assigned_date' => $assigned_info['assigned_date'],
                        'teachers' => $course['teachers'] ?? [],
                        'user_grades' => $course['user_grades'] ?? [],
                        'scale' =>  $course['scale'] ?? [],
                    ];
                }
            }

            return $filtered_courses;

        } catch (moodle_exception $e) {
            debugging('External API error in get_rop_courses: ' . $e->getMessage(), DEBUG_DEVELOPER);
            throw $e;
        } catch (\Exception $e) {
            debugging('Unexpected error in get_rop_courses: ' . $e->getMessage(), DEBUG_DEVELOPER);
            throw new moodle_exception('error_getting_rop_courses', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Returns description of get_rop_courses() result value
     *
     * @return external_multiple_structure
     */
    public static function get_rop_courses_returns(): external_multiple_structure
    {
        return new external_multiple_structure(
            new external_single_structure([
                'id' => new external_value(PARAM_INT, 'Course ID'),
                'fullname' => new external_value(PARAM_TEXT, 'Course full name'),
                'shortname' => new external_value(PARAM_TEXT, 'Course short name'),
                'summary' => new external_value(PARAM_RAW, 'Course summary'),
                'courseimage' => new external_value(PARAM_RAW, 'Course image'),
                'config_id' => new external_value(PARAM_INT, 'Config ID'),
                'assigned_date' => new external_value(PARAM_INT, 'Assignment date'),
                'teachers' => new external_multiple_structure(
                    new external_single_structure(
                        [
                            'id' => new external_value(PARAM_INT, 'userid'),
                            'firstname' => new external_value(PARAM_TEXT, 'firstname'),
                            'lastname' => new external_value(PARAM_TEXT, 'lastname'),
                            'middlename' => new external_value(PARAM_TEXT, 'middlename'),
                            'email' => new external_value(PARAM_TEXT, 'email'),
                        ]
                    ),
                    'Teachers list'
                ),
                'enrolled_users' => core_enrol_external::get_enrolled_users_returns(),
                'user_grades' => user::get_grade_items_returns(),
                'scale' => new external_single_structure([
                    'gradescales' => new external_multiple_structure(
                        new external_single_structure([
                            'minimum' => new external_value(
                                PARAM_TEXT,
                                'Minimum percentage for this grade (e.g., "90,00 %")'
                            ),
                            'maximum' => new external_value(
                                PARAM_TEXT,
                                'Maximum percentage for this grade (e.g., "100,00 %")'
                            ),
                            'gradename' => new external_value(
                                PARAM_TEXT,
                                'Name of the grade (e.g., "Отлично", "Хорошо")'
                            ),
                            /*  'lettercode' => new external_value(
                                  PARAM_TEXT,
                                  'Letter code (A, B, C, D, F, etc.)',
                                  VALUE_OPTIONAL
                              ),*/
                            'gradevalue' => new external_value(
                                PARAM_FLOAT,
                                'Numeric grade value for calculations',
                                VALUE_OPTIONAL
                            ),
                        ])
                    ),
                    'courseid' => new external_value(
                        PARAM_INT,
                        'Course ID that was processed'
                    ),
                    'userid' => new external_value(
                        PARAM_INT,
                        'User ID filter (0 if all users)'
                    ),
                    'warnings' => new external_warnings(),
                ])
            ])
        );
    }

    /**
     * Returns description of get_rop_config() parameters
     *
     * @return external_function_parameters
     */
    public static function get_rop_config_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            'email' => new external_value(PARAM_EMAIL, 'User email')
        ]);
    }

    /**
     * Get config assigned to ROP user by email
     *
     * @param string $email User email
     * @return array
     * @throws moodle_exception
     */
    public static function get_rop_config(string $email): array
    {
        global $DB;

        // Parameter validation
        $params = self::validate_parameters(self::get_rop_config_parameters(),
            array('email' => $email));

        // Context validation
        $context = context_system::instance();
        self::validate_context($context);

        try {
            // Сначала проверяем существование таблиц
            $dbman = $DB->get_manager();

            $user_courses_table = new \xmldb_table('block_cdo_showcase_user_courses');
            $settings_table = new \xmldb_table('block_cdo_showcase');

            if (!$dbman->table_exists($user_courses_table)) {
                debugging('Table block_cdo_showcase_user_courses does not exist', DEBUG_DEVELOPER);
                return [];
            }

            if (!$dbman->table_exists($settings_table)) {
                debugging('Table block_cdo_showcase does not exist', DEBUG_DEVELOPER);
                return [];
            }

            // Получаем конфиг, к которому назначен РОП пользователь
            $sql = "SELECT DISTINCT cs.id, cs.name, cs.url, cs.category_id, cs.token, cs.token_status, cs.timecreated, cs.timemodified
                    FROM {block_cdo_showcase_user_courses} uc
                    JOIN {block_cdo_showcase} cs ON cs.id = uc.config_id
                    WHERE uc.user_email = ?";

            $configs = $DB->get_records_sql($sql, [$params['email']]);

            if (empty($configs)) {
                debugging('No config found for ROP user: ' . $params['email'], DEBUG_DEVELOPER);
                return [];
            }
            $return_configs = [];
            foreach ($configs as $config) {
                $return_configs[] = [
                    'id' => (int)$config->id,
                    'token_name' => $config->name ?? '',
                    'url' => $config->url ?? '',
                    'category_id' => $config->category_id !== null ? (int)$config->category_id : null,
                    'token' => $config->token ?? '',
                    'token_status' => $config->token_status, // Если конфиг найден, считаем его активным
                    'timecreated' => (int)($config->timecreated ?? 0),
                    'timemodified' => (int)($config->timemodified ?? 0)
                ];
            }
            // Берем первый найденный конфиг
            //$config = reset($configs);

            return $return_configs;

        } catch (dml_exception $e) {
            debugging('Database error in get_rop_config: ' . $e->getMessage(), DEBUG_DEVELOPER);
            throw new moodle_exception('error_getting_rop_config', 'block_cdo_showcase', '', 'Database error: ' . $e->getMessage());
        } catch (\Exception $e) {
            debugging('Error in get_rop_config: ' . $e->getMessage(), DEBUG_DEVELOPER);
            throw new moodle_exception('error_getting_rop_config', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Returns description of get_rop_config() result value
     *
     * @return external_multiple_structure
     */
    public static function get_rop_config_returns(): external_multiple_structure
    {
        return new external_multiple_structure(new external_single_structure([
            'id' => new external_value(PARAM_INT, 'Config ID'),
            'token_name' => new external_value(PARAM_TEXT, 'Token name'),
            'url' => new external_value(PARAM_URL, 'Token URL'),
            'category_id' => new external_value(PARAM_INT, 'Category ID on donor site', VALUE_OPTIONAL),
            'token' => new external_value(PARAM_TEXT, 'Token value'),
            'token_status' => new external_value(PARAM_BOOL, 'Token status'),
            'timecreated' => new external_value(PARAM_INT, 'Time created'),
            'timemodified' => new external_value(PARAM_INT, 'Time modified'),

        ]));

    }
} 