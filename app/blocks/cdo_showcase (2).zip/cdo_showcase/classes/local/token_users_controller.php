<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace block_cdo_showcase\local;

use dml_exception;
use stdClass;
use moodle_exception;

/**
 * Controller class for managing token users
 *
 * @package   block_cdo_showcase
 * @copyright 2024 Your Name <your.email@example.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class token_users_controller {
    /** @var string Table name */
    private const TABLE = 'block_cdo_showcase_token_users';

    /**
     * Get all users for a token
     *
     * @param int $token_id Token ID
     * @return array Array of token users
     * @throws dml_exception
     */
    public static function get_token_users(int $token_id): array {
        global $DB;
        //return $DB->get_records(self::TABLE, ['token_id' => $token_id], 'timecreated ASC');

        return $DB->get_records_sql('SELECT DISTINCT u.id, uc.user_email email, u.firstname, u.lastname
                                        FROM {block_cdo_showcase_user_courses} uc
                                        INNER JOIN {user} u ON u.email = uc.user_email
                                        WHERE uc.config_id=  ?', [$token_id]);
    }

    /**
     * Get a single token user record by ID
     *
     * @param int $id Record ID
     * @return stdClass|null Record object or null if not found
     */
    public static function get_token_user(int $id): ?stdClass {
        global $DB;
        return $DB->get_record(self::TABLE, ['id' => $id]);
    }

    /**
     * Assign users to a token
     *
     * @param int $token_id Token ID
     * @param array $user_emails Array of user emails
     * @return bool True if successful
     * @throws moodle_exception
     */
    public static function assign_users(int $token_id, array $user_emails): bool {
        global $DB;

        try {
            // Начинаем транзакцию
            $transaction = $DB->start_delegated_transaction();

            // Удаляем существующие связи для этого токена
            $DB->delete_records(self::TABLE, ['token_id' => $token_id]);

            $time = time();
            $records = [];

            // Создаем новые записи
            foreach ($user_emails as $email) {
                $record = (object)[
                    'token_id' => $token_id,
                    'user_email' => $email,
                    'timecreated' => $time,
                    'timemodified' => $time
                ];
                $records[] = $record;
            }

            // Вставляем все записи одним запросом
            if (!empty($records)) {
                $DB->insert_records(self::TABLE, $records);
            }

            // Завершаем транзакцию
            $transaction->allow_commit();

            return true;
        } catch (\Exception $e) {
            // Откатываем транзакцию в случае ошибки
            if (isset($transaction)) {
                $transaction->rollback($e);
            }
            throw new moodle_exception('error_assigning_users', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Delete all users for a token
     *
     * @param int $token_id Token ID
     * @return bool True if successful
     * @throws moodle_exception
     */
    public static function delete_token_users(int $token_id): bool {
        global $DB;

        try {
            return $DB->delete_records(self::TABLE, ['token_id' => $token_id]);
        } catch (\Exception $e) {
            throw new moodle_exception('error_deleting_token_users', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Check if user is assigned to token
     *
     * @param int $token_id Token ID
     * @param string $user_email User email
     * @return bool True if user is assigned to token
     */
    public static function is_user_assigned(int $token_id, string $user_email): bool {
        global $DB;
        return $DB->record_exists(self::TABLE, [
            'token_id' => $token_id,
            'user_email' => $user_email
        ]);
    }
} 