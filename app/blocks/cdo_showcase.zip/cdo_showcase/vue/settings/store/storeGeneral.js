import {defineStore} from 'pinia'
import * as moodleStorage from 'core/localstorage';
import * as moodleAjax from 'core/ajax';
import {exception} from "core/notification";


export const useGeneralStore = defineStore('general', {
    state: () => (
        {
            settings: [],
            lastSaveResult: null,
            lastDeleteResult: null,
            tokenCheckResult: null,
            savingRows: {},
            currentTokenUsers: []
        }
    ),
    actions: {
        async loadSettings() {
            const request = {
                methodname: 'block_cdo_showcase_get_settings',
                args: {
                },
            };
            this.settings = await moodleAjax.call([request])[0];
        },
        async saveSettings(settings) {
            this.savingRows[settings.id || 'new'] = true;
            try {
                const request = {
                    methodname: 'block_cdo_showcase_save_settings',
                    args: {
                        settings: [settings]
                    }
                };
                this.lastSaveResult = await moodleAjax.call([request])[0];
                return true;
            } catch (error) {
                throw error;
            } finally {
                this.savingRows[settings.id || 'new'] = false;
            }
        },
        async deleteSetting(id) {
            const request = {
                methodname: 'block_cdo_showcase_delete_setting',
                args: {
                    id: id
                }
            };
            this.lastDeleteResult = await moodleAjax.call([request])[0];
        },
        async checkToken(row) {
            try {
                const response = await fetch(`${row.url}/webservice/rest/server.php`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        'wstoken': row.token,
                        'wsfunction': 'core_webservice_get_site_info',
                        'moodlewsrestformat': 'json'
                    })
                });

                const data = await response.json();
                if (data.hasOwnProperty('errorcode')) {
                    throw new Error(data.message);
                }
                const success = !data.error;
                this.tokenCheckResult = {
                    success: success,
                    message: data.error ? data.error : 'Токен действителен'
                };
                return this.tokenCheckResult;
            } catch (error) {
                this.tokenCheckResult = {
                    success: false,
                    message: 'Ошибка при проверке токена: ' + error.message
                };
                return this.tokenCheckResult;
            }
        },
        async getTokenUsers(row) {
            const request = {
                methodname: 'block_cdo_showcase_get_token_users',
                args: {
                    token_id: row.id
                },
            };
            this.currentTokenUsers = await moodleAjax.call([request])[0];
        }
    }
})