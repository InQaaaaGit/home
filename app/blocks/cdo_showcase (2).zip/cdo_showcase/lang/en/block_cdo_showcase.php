<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

$string['pluginname'] = 'CDO Showcase';
$string['extended_settings'] = 'CDO Showcase - Token Management';
$string['title'] = 'Title';
$string['enabled'] = 'Enabled';
$string['title_help'] = 'Enter the title for the CDO Showcase block';
$string['cdo_showcase:addinstance'] = 'Add a new CDO Showcase block';
$string['cdo_showcase:myaddinstance'] = 'Add a new CDO Showcase block to the My Moodle page';
$string['settings'] = 'Settings';
$string['name'] = 'Name';
$string['token'] = 'Token';
$string['url'] = 'URL';
$string['actions'] = 'Actions';
$string['delete'] = 'Delete';
$string['add_new'] = 'Add New';
$string['save'] = 'Save';

// Vue components strings
$string['showcase_coursedetailbutton'] = 'Details';
$string['coursecard_teacherssectiontitle'] = 'Teachers:';
$string['coursecard_students_count'] = 'Students:';
$string['coursecard_students'] = 'students';
$string['coursecard_more_teachers'] = 'more';
$string['coursedetail_backbutton'] = 'Back';
$string['coursedetail_gradessectiontitle'] = 'Grades:';
$string['gradetable_header_grade1'] = 'Grade 1';
$string['gradetable_header_grade2'] = 'Grade 2';
$string['gradetable_header_grade3'] = 'Achievements';

// Course toolbar strings
$string['toolbar_gradescale_button'] = 'Scale';
$string['toolbar_gradescale_tooltip'] = 'Show grading scale';
$string['toolbar_gradescale_title'] = 'Grading Scale';
$string['toolbar_gradescale_empty'] = 'Grading scale not found';
$string['toolbar_gradescale_error'] = 'Grading scale is unavailable. An error may have occurred while loading data.';
$string['close'] = 'Close';

// External API errors
$string['externalapierror'] = 'Error connecting to external API: {$a}';
$string['invalidjsonresponse'] = 'Invalid JSON response from external API';
$string['invalidwsfunction'] = 'Invalid web service function';
$string['token_valid'] = 'Token is valid';
$string['invalidtoken'] = 'Invalid or inactive token';
$string['invalidresponse'] = 'Invalid response from external API';

// HTTP errors
$string['error_400'] = 'Bad request - the server could not understand the request';
$string['error_401'] = 'Unauthorized - authentication is required';
$string['error_403'] = 'Forbidden - the server refuses to authorize the request';
$string['error_404'] = 'Not found - the requested resource does not exist';
$string['error_500'] = 'Internal server error - the server encountered an unexpected condition';
$string['error_http'] = 'HTTP error {$a} occurred while connecting to external API';

// CURL errors
$string['error_connection'] = 'Could not connect to the external API server';
$string['error_timeout'] = 'Connection to external API timed out';
$string['error_ssl'] = 'SSL connection error occurred';
$string['error_curl'] = 'CURL error: {$a}';

// Version compatibility
$string['unsupported_moodle_version'] = 'This plugin supports only Moodle 4.5.3-4.5.4 LTS. Current Moodle version: {$a}. Please use Moodle 4.5.3 or 4.5.4 LTS for proper plugin functionality.';

// SSL verification settings
$string['ssl_verification'] = 'SSL Verification';
$string['ssl_verification_desc'] = 'Enable or disable SSL certificate verification for external API requests. Disabling may be required for self-signed certificates or test environments.';
$string['ssl_verification_enabled'] = 'Enabled';
$string['ssl_verification_disabled'] = 'Disabled';

// Block settings
$string['block_settings'] = 'Block Settings';
$string['test_mode'] = 'Test Mode';
$string['test_mode_desc'] = 'Enable test mode for debugging. In test mode, fixed values are used instead of real user data.';
$string['test_mode_enabled'] = 'Enabled';
$string['test_mode_disabled'] = 'Disabled';
$string['test_email'] = 'Test Email';
$string['test_email_desc'] = 'Email address to use in test mode. Only used when test mode is enabled.';
$string['test_isrop'] = 'Test isROP Value';
$string['test_isrop_desc'] = 'isROP value to use in test mode. Only used when test mode is enabled.';
$string['test_isrop_enabled'] = 'Enabled (true)';
$string['test_isrop_disabled'] = 'Disabled (false)';
$string['api_request_param'] = 'Course Selection Category';
$string['api_request_param_desc'] = 'Category parameter for course selection. This parameter will be included in all external API calls along with the email for filtering courses by category.';

// Global summary strings
$string['global_summary'] = 'Overall';
$string['global_summary_title'] = 'Overall - Summary Across All Courses';
$string['global_summary_description'] = 'Aggregated data of all students across all courses';
$string['loading_global_summary'] = 'Loading summary information...';
$string['back'] = 'Back';
$string['refresh'] = 'Refresh';
$string['showing'] = 'Showing';
$string['of'] = 'of';
$string['students'] = 'students';
$string['student_name'] = 'Student';
$string['search_student'] = 'Search student...';
$string['avg_frtk1'] = 'Average FRTK1';
$string['avg_frtk2'] = 'Average FRTK2';
$string['avg_individual'] = 'Average Individual Achievements';
$string['overall_average'] = 'Overall Average';
$string['courses_count'] = 'Courses';
$string['status'] = 'Status';
$string['actions'] = 'Actions';
$string['courses_details'] = 'Course Details';
$string['course_name'] = 'Course';
$string['individual_achievements'] = 'Individual Achievements';
$string['total_grade'] = 'Total';
$string['total_courses'] = 'Total Courses';
$string['total_students'] = 'Total Students';
$string['no_students_found'] = 'No students found';
$string['try_different_search'] = 'Try changing search parameters';
$string['overall_statistics'] = 'Overall Statistics';
$string['average_values'] = 'Average Values';
$string['scroll_horizontally'] = 'Scroll horizontally to view all columns';

// Toolbar strings
$string['my_courses'] = 'My Courses';
$string['courses_description'] = 'Manage courses and view statistics';

// Test data strings
$string['test_data'] = 'Test Data';
$string['create_test_users'] = 'Create Test Users';
$string['create_test_users_desc'] = 'Creates test users and places them in a global cohort "CDO Showcase Test Users". Useful for demonstrating plugin functionality.';
$string['create_test_users_button'] = 'Create Test Users';
$string['user_count'] = 'Number of users (1-100):';
$string['create_users'] = 'Create Users';
$string['confirm_create_users'] = 'Are you sure you want to create test users? This action cannot be undone.';
$string['error_creating_test_users'] = 'Error creating test users: {$a}'; 