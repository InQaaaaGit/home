<script setup >
const props = defineProps({
      'strings': {type: Object, required: false},
      'formData': {type: Object, required: false},
    }
);
</script>

<template>

</template>

<style scoped>

</style>