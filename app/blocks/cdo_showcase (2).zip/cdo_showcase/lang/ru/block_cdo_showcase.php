<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_cdo_showcase', language 'ru'
 *
 * @package   block_cdo_showcase
 * @copyright 2024 Your Name <your.email@example.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'CDO Showcase';
$string['extended_settings'] = 'CDO Showcase - Управление токенами';
$string['settings'] = 'Настройки';
$string['name'] = 'Наименование';
$string['url'] = 'URL';
$string['token'] = 'Токен';
$string['actions'] = 'Действия';
$string['delete'] = 'Удалить';
$string['add_new'] = 'Добавить строку';
$string['save'] = 'Сохранить';
$string['settings_saved'] = 'Настройки сохранены';
$string['settings_error'] = 'Ошибка при сохранении настроек';
$string['required_field'] = 'Это поле обязательно для заполнения';
$string['invalid_url'] = 'Неверный формат URL';
$string['invalid_token'] = 'Неверный формат токена';
$string['move_up'] = 'Переместить вверх';
$string['move_down'] = 'Переместить вниз';
$string['delete_row'] = 'Удалить строку';
$string['no_settings'] = 'Настроек пока нет. Добавьте первую настройку.';

// Строки панели инструментов курса
$string['toolbar_gradescale_button'] = 'Шкала';
$string['toolbar_gradescale_tooltip'] = 'Показать шкалу оценивания';
$string['toolbar_gradescale_title'] = 'Шкала оценивания';
$string['toolbar_gradescale_empty'] = 'Шкала оценивания не найдена';
$string['toolbar_gradescale_error'] = 'Шкала оценивания недоступна. Возможно, произошла ошибка при загрузке данных.';
$string['close'] = 'Закрыть';

// Error messages
$string['error_creating_setting'] = 'Ошибка при создании настройки: {$a}';
$string['error_updating_setting'] = 'Ошибка при обновлении настройки: {$a}';
$string['error_deleting_setting'] = 'Ошибка при удалении настройки: {$a}';
$string['missing_id'] = 'Отсутствует ID настройки';
$string['missing_name'] = 'Отсутствует наименование';
$string['missing_url'] = 'Отсутствует URL';
$string['missing_token'] = 'Отсутствует токен';

$string['cdo_showcase:addinstance'] = 'Добавить новый блок Витрина ЦДО';
$string['cdo_showcase:myaddinstance'] = 'Добавить новый блок Витрина ЦДО на страницу Панель управления';

// Vue components strings
$string['showcase_coursedetailbutton'] = 'Подробнее';
$string['coursecard_teacherssectiontitle'] = 'Преподаватели:';
$string['coursecard_students_count'] = 'Студенты:';
$string['coursecard_students'] = 'студентов';
$string['coursecard_more_teachers'] = 'еще';
$string['coursedetail_backbutton'] = 'Назад';
$string['coursedetail_gradessectiontitle'] = 'Оценки:';
$string['gradetable_header_grade1'] = 'ФРТК1';
$string['gradetable_header_grade2'] = 'ФРТК2';
$string['gradetable_header_grade3'] = 'Индивидуальные достижения';

// Version compatibility
$string['unsupported_moodle_version'] = 'Этот плагин поддерживает только Moodle 4.5.3-4.5.4 LTS. Текущая версия Moodle: {$a}. Пожалуйста, используйте Moodle 4.5.3 или 4.5.4 LTS для корректной работы плагина.';

// SSL verification settings
$string['ssl_verification'] = 'SSL-верификация';
$string['ssl_verification_desc'] = 'Включить или отключить проверку SSL-сертификатов при выполнении внешних API-запросов. Отключение может потребоваться для самоподписанных сертификатов или тестовых сред.';
$string['ssl_verification_enabled'] = 'Включена';
$string['ssl_verification_disabled'] = 'Отключена';

// Block settings
$string['block_settings'] = 'Настройки блока';
$string['test_mode'] = 'Тестовый режим';
$string['test_mode_desc'] = 'Включить тестовый режим для отладки. В тестовом режиме используются фиксированные значения вместо реальных данных пользователя.';
$string['test_mode_enabled'] = 'Включен';
$string['test_mode_disabled'] = 'Отключен';
$string['test_email'] = 'Тестовый email';
$string['test_email_desc'] = 'Email адрес для использования в тестовом режиме. Используется только когда тестовый режим включен.';
$string['test_isrop'] = 'Тестовое значение isROP';
$string['test_isrop_desc'] = 'Значение isROP для использования в тестовом режиме. Используется только когда тестовый режим включен.';
$string['test_isrop_enabled'] = 'Включено (true)';
$string['test_isrop_disabled'] = 'Отключено (false)';
$string['api_request_param'] = 'Категория отбора курсов';
$string['api_request_param_desc'] = 'Параметр категории для отбора курсов. Этот параметр будет включен во все внешние API вызовы вместе с email для фильтрации курсов по категории.';

// Global summary strings
$string['global_summary'] = 'Общее';
$string['global_summary_title'] = 'Общее - Сводка по всем курсам';
$string['global_summary_description'] = 'Агрегированные данные всех студентов по всем курсам';
$string['loading_global_summary'] = 'Загрузка сводной информации...';
$string['back'] = 'Назад';
$string['refresh'] = 'Обновить';
$string['showing'] = 'Показано';
$string['of'] = 'из';
$string['students'] = 'студентов';
$string['student_name'] = 'Студент';
$string['search_student'] = 'Поиск студента...';
$string['avg_frtk1'] = 'Средний ФРТК1';
$string['avg_frtk2'] = 'Средний ФРТК2';
$string['avg_individual'] = 'Средние инд. достижения';
$string['overall_average'] = 'Общий средний';
$string['courses_count'] = 'Курсов';
$string['status'] = 'Статус';
$string['actions'] = 'Действия';
$string['courses_details'] = 'Детали по курсам';
$string['course_name'] = 'Курс';
$string['individual_achievements'] = 'Инд. достижения';
$string['total_grade'] = 'Итого';
$string['total_courses'] = 'Всего курсов';
$string['total_students'] = 'Всего студентов';
$string['no_students_found'] = 'Студенты не найдены';
$string['try_different_search'] = 'Попробуйте изменить параметры поиска';
$string['overall_statistics'] = 'Общая статистика';
$string['average_values'] = 'Средние значения';
$string['scroll_horizontally'] = 'Прокрутите горизонтально для просмотра всех колонок';

// Toolbar strings
$string['my_courses'] = 'Мои курсы';
$string['courses_description'] = 'Управление курсами и просмотр статистики';

// Test data strings
$string['test_data'] = 'Тестовые данные';
$string['create_test_users'] = 'Создать тестовых пользователей';
$string['create_test_users_desc'] = 'Создает тестовых пользователей и помещает их в глобальную когорту "CDO Showcase Test Users". Полезно для демонстрации функциональности плагина.';
$string['create_test_users_button'] = 'Создать тестовых пользователей';
$string['user_count'] = 'Количество пользователей (1-100):';
$string['create_users'] = 'Создать пользователей';
$string['confirm_create_users'] = 'Вы уверены, что хотите создать тестовых пользователей? Это действие нельзя отменить.';
$string['error_creating_test_users'] = 'Ошибка при создании тестовых пользователей: {$a}'; 