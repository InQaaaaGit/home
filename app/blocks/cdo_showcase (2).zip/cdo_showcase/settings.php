<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    // SSL verification setting
    $settings->add(new admin_setting_configselect(
        'block_cdo_showcase/ssl_verification',
        get_string('ssl_verification', 'block_cdo_showcase'),
        get_string('ssl_verification_desc', 'block_cdo_showcase'),
        1, // Default: enabled
        array(
            1 => get_string('ssl_verification_enabled', 'block_cdo_showcase'),
            0 => get_string('ssl_verification_disabled', 'block_cdo_showcase')
        )
    ));

    // Block settings section
    $settings->add(new admin_setting_heading(
        'block_cdo_showcase/block_settings_heading',
        get_string('block_settings', 'block_cdo_showcase'),
        ''
    ));

    // Test mode setting
    $settings->add(new admin_setting_configselect(
        'block_cdo_showcase/test_mode',
        get_string('test_mode', 'block_cdo_showcase'),
        get_string('test_mode_desc', 'block_cdo_showcase'),
        0, // Default: disabled
        array(
            1 => get_string('test_mode_enabled', 'block_cdo_showcase'),
            0 => get_string('test_mode_disabled', 'block_cdo_showcase')
        )
    ));

    // Test email setting
    $settings->add(new admin_setting_configtext(
        'block_cdo_showcase/test_email',
        get_string('test_email', 'block_cdo_showcase'),
        get_string('test_email_desc', 'block_cdo_showcase'),
        'test@example.com',
        PARAM_EMAIL
    ));

    // Test isROP setting
    $settings->add(new admin_setting_configselect(
        'block_cdo_showcase/test_isrop',
        get_string('test_isrop', 'block_cdo_showcase'),
        get_string('test_isrop_desc', 'block_cdo_showcase'),
        1, // Default: enabled
        array(
            1 => get_string('test_isrop_enabled', 'block_cdo_showcase'),
            0 => get_string('test_isrop_disabled', 'block_cdo_showcase')
        )
    ));

    // API Request Parameter setting
    $settings->add(new admin_setting_configtext(
        'block_cdo_showcase/api_request_param',
        get_string('api_request_param', 'block_cdo_showcase'),
        get_string('api_request_param_desc', 'block_cdo_showcase'),
        '', // Default: empty
        PARAM_TEXT
    ));

    // Test data section
    $settings->add(new admin_setting_heading(
        'block_cdo_showcase/test_data_heading',
        get_string('test_data', 'block_cdo_showcase'),
        ''
    ));

    // Create test users button
    $test_users_url = new moodle_url('/blocks/cdo_showcase/create_test_users.php');
    $settings->add(new admin_setting_description(
        'block_cdo_showcase/create_test_users_button',
        get_string('create_test_users', 'block_cdo_showcase'),
        get_string('create_test_users_desc', 'block_cdo_showcase') . '<br><br>' .
        html_writer::link(
            $test_users_url,
            get_string('create_test_users_button', 'block_cdo_showcase'),
            array(
                'class' => 'btn btn-primary',
                'style' => 'margin-top: 10px;'
            )
        )
    ));

    $ADMIN->add('blocksettings', new admin_externalpage(
        'blocksettings_cdo_showcase_link',
        get_string('extended_settings', 'block_cdo_showcase'),
        new moodle_url($CFG->wwwroot . '/blocks/cdo_showcase/extend_settings/settings.php')
    ));
}
