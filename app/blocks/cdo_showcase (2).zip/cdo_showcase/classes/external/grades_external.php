<?php

namespace block_cdo_showcase\external;

use block_cdo_showcase\external\traits\external_api_request_trait;
use block_cdo_showcase\local\controller;
use context_system;
use core\exception\moodle_exception;
use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use core_external\external_value;

require_once $CFG->libdir . '/filelib.php';

class grades_external extends external_api
{
    use external_api_request_trait;

    /**
     * Ключевые слова для поиска категорий оценок
     * Аналог CATEGORY_KEYWORDS из constants.js
     */
    private static function get_category_keywords(): array
    {
        return [
            'grade1' => ['фртк1', 'фртк 1', 'frtk1', 'frtk 1', 'фртк-1', 'тк-1', 'тк 1'],
            'grade2' => ['фртк2', 'фртк 2', 'frtk2', 'frtk 2', 'фртк-2', 'тк-2', 'тк 2'],
            'grade3' => ['индивидуальн', 'достижени', 'individual', 'achievement']
        ];
    }

    /**
     * Функция для проверки соответствия текста ключевым словам
     * Аналог matchesKeywords из constants.js
     *
     * @param string $text Текст для проверки
     * @param array $keywords Массив ключевых слов
     * @return bool true если найдено соответствие
     */
    private static function matches_keywords(string $text, array $keywords): bool
    {
        $textLower = mb_strtolower($text);
        
        foreach ($keywords as $keyword) {
            $keywordLower = mb_strtolower($keyword);
            
            // Проверяем точное совпадение
            if ($textLower === $keywordLower) {
                return true;
            }
            
            // Проверяем, содержит ли текст ключевое слово
            if (mb_strpos($textLower, $keywordLower) !== false) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Функция для определения типа категории по её названию
     * Аналог getCategoryType из constants.js
     *
     * @param string $categoryName Название категории
     * @return string|null Тип категории (grade1, grade2, grade3) или null если не определен
     */
    private static function get_category_type(string $categoryName): ?string
    {
        $keywords = self::get_category_keywords();
        
        foreach ($keywords as $gradeType => $gradeKeywords) {
            if (self::matches_keywords($categoryName, $gradeKeywords)) {
                return $gradeType;
            }
        }
        
        return null;
    }

    /**
     * Returns description of get_user_grades_by_config() parameters
     * @return external_function_parameters
     */
    public static function get_user_grades_by_config_parameters(): external_function_parameters
    {
        return new external_function_parameters(
            array(
                'configid' => new external_value(PARAM_INT, 'Configuration ID'),
                'courseid' => new external_value(PARAM_INT, 'Course ID'),
                'email' => new external_value(PARAM_EMAIL, 'User email', VALUE_REQUIRED)
            )
        );
    }

    /**
     * Returns description of get_user_grades_by_config() result value
     * @return external_single_structure
     */
    public static function get_user_grades_by_config_returns(): external_single_structure
    {
        return new external_single_structure(
            array(
                'grade1' => new external_value(PARAM_RAW, 'First grade (ФРТК1)', VALUE_OPTIONAL),
                'grade2' => new external_value(PARAM_RAW, 'Second grade (ФРТК2)', VALUE_OPTIONAL),
                'grade3' => new external_value(PARAM_RAW, 'Third grade (Индивидуальные достижения)', VALUE_OPTIONAL),
                'total_grade' => new external_value(PARAM_RAW, 'Total grade', VALUE_OPTIONAL),
                'average_grade' => new external_value(PARAM_RAW, 'Average grade for discipline', VALUE_OPTIONAL),
                'grade_date' => new external_value(PARAM_RAW, 'Grade date', VALUE_OPTIONAL),
                'status' => new external_value(PARAM_RAW, 'Grade status (passed/failed/in_progress)', VALUE_OPTIONAL),
                'grade_items' => new external_multiple_structure(
                    new external_single_structure(
                        array(
                            'id' => new external_value(PARAM_INT, 'Grade item ID'),
                            'itemname' => new external_value(PARAM_TEXT, 'Grade item name'),
                            'itemtype' => new external_value(PARAM_TEXT, 'Grade item type'),
                            'weightraw' => new external_value(PARAM_FLOAT, 'Weight of the grade item'),
                            'graderaw' => new external_value(PARAM_FLOAT, 'Raw grade value', VALUE_OPTIONAL),
                            'grademax' => new external_value(PARAM_FLOAT, 'Maximum grade value'),
                            'gradeformatted' => new external_value(PARAM_RAW, 'Formatted grade value', VALUE_OPTIONAL),
                            'percentageformatted' => new external_value(PARAM_TEXT, 'Formatted percentage', VALUE_OPTIONAL),
                            'feedback' => new external_value(PARAM_TEXT, 'Feedback for the grade', VALUE_OPTIONAL),
                            'average_grade' => new external_value(PARAM_FLOAT, 'average_grade for the grade', VALUE_OPTIONAL),
                        )
                    )
                ),
                'scale' => new external_single_structure([
                    'gradescales' => new external_multiple_structure(
                        new external_single_structure([
                            'minimum' => new external_value(
                                PARAM_TEXT,
                                'Minimum percentage for this grade (e.g., "90,00 %")'
                            ),
                            'maximum' => new external_value(
                                PARAM_TEXT,
                                'Maximum percentage for this grade (e.g., "100,00 %")'
                            ),
                            'gradename' => new external_value(
                                PARAM_TEXT,
                                'Name of the grade (e.g., "Отлично", "Хорошо")'
                            ),
                            'gradevalue' => new external_value(
                                PARAM_FLOAT,
                                'Numeric grade value for calculations',
                                VALUE_OPTIONAL
                            ),
                        ])
                    ),
                    'courseid' => new external_value(
                        PARAM_INT,
                        'Course ID that was processed'
                    ),
                    'userid' => new external_value(
                        PARAM_INT,
                        'User ID filter (0 if all users)'
                    ),
                ], VALUE_OPTIONAL)
            )
        );
    }

    /**
     * Get user grades by configuration ID and course ID
     * @param int $configid Configuration ID
     * @param int $courseid Course ID
     * @param string $email User email
     * @return array
     * @throws moodle_exception
     */
    public static function get_user_grades_by_config(int $configid, int $courseid, string $email): array
    {
        // Parameter validation
        $params = self::validate_parameters(self::get_user_grades_by_config_parameters(),
            array(
                'configid' => $configid,
                'courseid' => $courseid,
                'email' => $email
            )
        );

        // Context validation
        $context = context_system::instance();
        self::validate_context($context);

        // Get configuration
        $config = controller::get_setting($params['configid']);
        if (!$config->token_status) {
            throw new moodle_exception('invalidtoken', 'block_cdo_showcase');
        }

        try {
            // Используем метод make_request для выполнения POST-запроса
            $result = self::make_request(
                $config->url,
                $config->token,
                'tool_cdo_showcase_tools_get_grade_items',
                [
                    'courseid' => $params['courseid'],
                    'userid' => $params['email']
                ]
            );

            // Проверяем структуру ответа
            if (!isset($result['usergrades']) || !is_array($result['usergrades'])) {
                throw new moodle_exception('invalidresponse', 'block_cdo_showcase');
            }

            $response = array(
                'grade1' => null,
                'grade2' => null,
                'grade3' => null,
                'total_grade' => null,
                'average_grade' => null,
                'grade_date' => null,
                'status' => 'in_progress',
                'grade_items' => array(),
                'scale' => array(
                    'gradescales' => array(),
                    'courseid' => $params['courseid'],
                    'userid' => 0
                )
            );

            // Обрабатываем первую запись из usergrades
            if (!empty($result['usergrades'][0]['gradeitems'])) {
                $gradeitems = $result['usergrades'][0]['gradeitems'];
                $latestGradeDate = 0;

                foreach ($gradeitems as $item) {
                    // Сохраняем все элементы оценок
                    $response['grade_items'][] = array(
                        'id' => $item['id'],
                        'itemname' => $item['itemname'],
                        'itemtype' => $item['itemtype'],
                        'weightraw' => $item['weightraw'],
                        'graderaw' => $item['graderaw'],
                        'grademax' => $item['grademax'],
                        'gradeformatted' => $item['gradeformatted'],
                        'percentageformatted' => $item['percentageformatted'],
                        'feedback' => $item['feedback'],
                        'average_grade' => $item['average_grade'],
                    );

                    // Обновляем дату последней оценки
                    if ($item['gradedategraded'] && $item['gradedategraded'] > $latestGradeDate) {
                        $latestGradeDate = $item['gradedategraded'];
                    }

                    // Получаем итоговую оценку курса из элемента с типом 'course'
                    if ($item['itemtype'] === 'course') {
                        $response['total_grade'] = $item['graderaw'];
                        // Также берем средний балл из элемента course, если он есть
                        if (isset($item['average_grade']) && $item['average_grade'] !== null) {
                            $response['average_grade'] = $item['average_grade'];
                        }
                        // Отладочная информация
                        debugging('Found course total grade: ' . $item['graderaw'] . ' for course item: ' . $item['itemname'], DEBUG_DEVELOPER);
                    }

                    // Определяем тип оценки по названию используя функцию get_category_type
                    // Аналог логики из constants.js для гибкого поиска по ключевым словам
                    $categoryType = self::get_category_type($item['itemname']);
                    if ($categoryType !== null) {
                       // $response[$categoryType] = $item['graderaw'];
                        $response[$categoryType] = $item['gradeformatted'];
                    }
                }

                // Устанавливаем дату последней оценки
                if ($latestGradeDate > 0) {
                    $response['grade_date'] = date('Y-m-d H:i:s', $latestGradeDate);
                }

                // Определяем статус на основе итоговой оценки курса, если она есть
                if ($response['total_grade'] !== null) {
                    if ($response['total_grade'] >= 60) {
                        $response['status'] = 'passed';
                    } elseif ($response['total_grade'] < 60) {
                        $response['status'] = 'failed';
                    }
                } else {
                    // Если итоговой оценки нет, используем средний балл для определения статуса  
                    if ($response['average_grade'] !== null) {
                        if ($response['average_grade'] >= 60) {
                            $response['status'] = 'passed';
                        } elseif ($response['average_grade'] < 60) {
                            $response['status'] = 'failed';
                        }
                    }
                }
            }

            // Получаем шкалу оценивания для курса
            try {
                $scale_result = self::make_request(
                    $config->url,
                    $config->token,
                    'tool_cdo_showcase_tools_get_course_letter_grades',
                    [
                        'courseid' => $params['courseid']
                    ]
                );

                // Если получили шкалу, добавляем её в ответ
                if (isset($scale_result['gradescales']) && is_array($scale_result['gradescales'])) {
                    $response['scale']['gradescales'] = $scale_result['gradescales'];
                }
            } catch (\Exception $scale_error) {
                // Если не удалось получить шкалу через API, оставляем пустой массив
                debugging('Could not get grade scale: ' . $scale_error->getMessage(), DEBUG_DEVELOPER);
                // Шкала остается пустой, кнопка "Шкала" не будет отображаться
            }

            return $response;

        } catch (moodle_exception $e) {
            debugging('External API error in get_user_grades_by_config: ' . $e->getMessage(), DEBUG_DEVELOPER);
            throw $e;
        } catch (\Exception $e) {
            debugging('Unexpected error in get_user_grades_by_config: ' . $e->getMessage(), DEBUG_DEVELOPER);
            throw new moodle_exception('externalapierror', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

} 