<script setup>
import { ref, onMounted } from 'vue';
import * as moodleAjax from 'core/ajax';
import notification from "core/notification";

// Reactive data
const userTokenUsage = ref(null);
const isLoading = ref(true);
const error = ref(null);

// Load user token usage information
const loadUserTokenUsage = async () => {
  isLoading.value = true;
  error.value = null;
  
  try {
    const result = await moodleAjax.call([{
      methodname: 'block_cdo_showcase_get_user_token_usage',
      args: {} // Используем текущего пользователя
    }])[0];

    userTokenUsage.value = result;
  } catch (err) {
    console.error('Error loading user token usage:', err);
    error.value = 'Ошибка при загрузке информации об использовании токенов';
    await notification.exception(err);
  } finally {
    isLoading.value = false;
  }
};

// Format date
const formatDate = (timestamp) => {
  if (!timestamp) return 'Неизвестно';
  const date = new Date(timestamp * 1000);
  return date.toLocaleDateString('ru-RU', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

// Load data on component mount
onMounted(() => {
  loadUserTokenUsage();
});
</script>

<template>
  <div class="user-token-usage">
    <div class="usage-header">
      <h3>
        <i class="fa fa-user-circle"></i>
        Мое использование токенов
      </h3>
      <button @click="loadUserTokenUsage" class="refresh-button" :disabled="isLoading">
        <i class="fa" :class="isLoading ? 'fa-spinner fa-spin' : 'fa-refresh'"></i>
      </button>
    </div>

    <!-- Loading state -->
    <div v-if="isLoading" class="loading-state">
      <i class="fa fa-spinner fa-spin"></i>
      <span>Загрузка информации...</span>
    </div>

    <!-- Error state -->
    <div v-else-if="error" class="error-state">
      <i class="fa fa-exclamation-triangle"></i>
      <span>{{ error }}</span>
    </div>

    <!-- No assignments -->
    <div v-else-if="!userTokenUsage?.has_assignments" class="no-assignments">
      <i class="fa fa-info-circle"></i>
      <div class="no-assignments-content">
        <h4>Токены не назначены</h4>
        <p>Вам пока не назначены курсы через токены системы.</p>
        <small>Обратитесь к администратору для получения доступа к курсам.</small>
      </div>
    </div>

    <!-- Usage information -->
    <div v-else class="usage-content">
      <!-- Summary -->
      <div class="usage-summary">
        <div class="summary-item">
          <div class="summary-icon tokens">
            <i class="fa fa-key"></i>
          </div>
          <div class="summary-info">
            <span class="summary-number">{{ userTokenUsage.tokens_count }}</span>
            <span class="summary-label">{{ userTokenUsage.tokens_count === 1 ? 'Токен' : 'Токена' }}</span>
          </div>
        </div>
        
        <div class="summary-item">
          <div class="summary-icon courses">
            <i class="fa fa-book"></i>
          </div>
          <div class="summary-info">
            <span class="summary-number">{{ userTokenUsage.total_courses }}</span>
            <span class="summary-label">{{ userTokenUsage.total_courses === 1 ? 'Курс' : 'Курсов' }}</span>
          </div>
        </div>
        
        <div class="summary-item">
          <div class="summary-icon user">
            <i class="fa fa-envelope"></i>
          </div>
          <div class="summary-info">
            <span class="summary-email">{{ userTokenUsage.user_email }}</span>
            <span class="summary-label">Ваш email</span>
          </div>
        </div>
      </div>

      <!-- Tokens list -->
      <div class="tokens-list">
        <div v-for="token in userTokenUsage.tokens" :key="token.config_id" class="token-card">
          <div class="token-header">
            <div class="token-info">
              <h4 class="token-name">
                <i class="fa fa-key"></i>
                {{ token.token_name }}
              </h4>
              <div class="token-meta">
                <span class="token-url">{{ token.token_url }}</span>
                <span class="token-courses-count">{{ token.courses_count }} курсов</span>
              </div>
            </div>
            <div class="token-dates">
              <div class="date-item">
                <small>Назначено:</small>
                <span>{{ formatDate(token.first_assigned) }}</span>
              </div>
              <div class="date-item">
                <small>Изменено:</small>
                <span>{{ formatDate(token.last_modified) }}</span>
              </div>
            </div>
          </div>

          <!-- Courses for this token -->
          <div class="courses-section">
            <h5>Назначенные курсы:</h5>
            <div class="courses-grid">
              <div 
                v-for="course in token.courses" 
                :key="course.id"
                class="course-card"
              >
                <div class="course-info">
                  <span class="course-name">{{ course.fullname }}</span>
                  <span class="course-short">{{ course.shortname }}</span>
                </div>
                <div class="course-meta">
                  <small>Назначен: {{ formatDate(course.timecreated) }}</small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.user-token-usage {
  margin: 20px 0;
  background: white;
  border-radius: 8px;
  border: 1px solid #e1e5e9;
  overflow: hidden;
}

.usage-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.usage-header h3 {
  margin: 0;
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 1.2rem;
}

.refresh-button {
  background: rgba(255, 255, 255, 0.2);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: white;
  padding: 8px 12px;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.refresh-button:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.3);
}

.refresh-button:disabled {
  cursor: not-allowed;
  opacity: 0.7;
}

.loading-state,
.error-state {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px;
  gap: 12px;
  color: #666;
}

.error-state {
  color: #d32f2f;
}

.no-assignments {
  display: flex;
  align-items: center;
  padding: 40px;
  gap: 16px;
  color: #666;
}

.no-assignments .fa {
  font-size: 2rem;
  color: #999;
}

.no-assignments-content h4 {
  margin: 0 0 8px 0;
  color: #333;
}

.no-assignments-content p {
  margin: 0 0 8px 0;
}

.no-assignments-content small {
  color: #999;
}

.usage-content {
  padding: 20px;
}

.usage-summary {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  margin-bottom: 24px;
}

.summary-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px;
  background: #f8f9fa;
  border-radius: 8px;
  border-left: 4px solid #4CAF50;
}

.summary-icon {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 1.2rem;
}

.summary-icon.tokens {
  background: #2196F3;
}

.summary-icon.courses {
  background: #4CAF50;
}

.summary-icon.user {
  background: #FF9800;
}

.summary-info {
  display: flex;
  flex-direction: column;
}

.summary-number,
.summary-email {
  font-size: 1.5rem;
  font-weight: 600;
  color: #333;
  line-height: 1;
}

.summary-email {
  font-size: 1rem;
  font-weight: 500;
}

.summary-label {
  font-size: 0.875rem;
  color: #666;
  margin-top: 4px;
}

.tokens-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.token-card {
  border: 1px solid #e1e5e9;
  border-radius: 8px;
  overflow: hidden;
}

.token-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 16px;
  background: #f8f9fa;
  border-bottom: 1px solid #e1e5e9;
}

.token-info h4 {
  margin: 0 0 8px 0;
  display: flex;
  align-items: center;
  gap: 8px;
  color: #333;
}

.token-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.token-url {
  font-size: 0.875rem;
  color: #666;
  word-break: break-all;
}

.token-courses-count {
  font-size: 0.875rem;
  color: #4CAF50;
  font-weight: 500;
}

.token-dates {
  display: flex;
  flex-direction: column;
  gap: 8px;
  text-align: right;
}

.date-item {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.date-item small {
  color: #999;
  font-size: 0.75rem;
}

.date-item span {
  font-size: 0.875rem;
  color: #666;
}

.courses-section {
  padding: 16px;
}

.courses-section h5 {
  margin: 0 0 12px 0;
  color: #333;
  font-size: 1rem;
}

.courses-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 12px;
}

.course-card {
  padding: 12px;
  border: 1px solid #e1e5e9;
  border-radius: 6px;
  background: white;
  transition: all 0.3s ease;
}

.course-card:hover {
  border-color: #4CAF50;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.course-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-bottom: 8px;
}

.course-name {
  font-weight: 500;
  color: #333;
  line-height: 1.3;
}

.course-short {
  font-size: 0.875rem;
  color: #666;
}

.course-meta small {
  color: #999;
  font-size: 0.75rem;
}

@media (max-width: 768px) {
  .usage-summary {
    grid-template-columns: 1fr;
  }
  
  .token-header {
    flex-direction: column;
    gap: 12px;
  }
  
  .token-dates {
    text-align: left;
  }
  
  .courses-grid {
    grid-template-columns: 1fr;
  }
}
</style> 