<?php

$plugin->version = 2025030702;
$plugin->requires = 2019111200;
$plugin->component = 'block_cdo_survey';
$maturity = MATURITY_ALPHA;
$plugin->dependencies = [
	"tool_cdo_config" => 20220512.01
];
