<script setup>
import {useGeneralStore} from "../store/storeGeneral";
import {useLangStore} from "../store/storeLang";
import {useRouter} from 'vue-router';
import {computed, ref, onMounted, onUnmounted, nextTick} from 'vue';
import CourseCard from './CourseCard.vue';
import { formatScale, exportRopReport } from '../utils/excelExport';
import * as moodleAjax from 'core/ajax';
import { CATEGORY_KEYWORDS, getCategoryType } from '../store/constants';
import notification from 'core/notification';

const generalStore = useGeneralStore();
const langStore = useLangStore();
const router = useRouter();

// Группировка курсов по конфигам
const coursesByConfig = computed(() => {
  const grouped = new Map();
  
  generalStore.userCourses.forEach(courseItem => {
    const configId = courseItem.config?.id || 'unknown';
    const configName = courseItem.config?.name || 'Неизвестный конфиг';
    
    if (!grouped.has(configId)) {
      grouped.set(configId, {
        id: configId,
        name: configName,
        courses: []
      });
    }
    
    grouped.get(configId).courses.push(courseItem);
  });
  
  return Array.from(grouped.values());
});

const goToCourseDetail = (courseId) => {
  router.push(`/course/${courseId}`);
};

const goToGlobalSummary = () => {
  router.push('/summary');
};

// Функция для получения имени текущего пользователя
const getCurrentUserName = () => {
  // Извлекаем имя из email (до символа @)
  const email = generalStore.userEmail;
  if (email) {
    const namePart = email.split('@')[0];
    // Преобразуем в читаемый вид (заменяем точки на пробелы, делаем первую букву заглавной)
    return namePart
      .split('.')
      .map(part => part.charAt(0).toUpperCase() + part.slice(1))
      .join(' ');
  }
  return 'Студент';
};

// Функция для перезагрузки всего приложения
const reloadApp = () => {
  generalStore.reloadApp();
};

// Состояние загрузки для экспорта отчета
const isExportingReport = ref(false);

// Состояние выпадающего меню
const showStudentActionsDropdown = ref(false);
const dropdownButtonRef = ref(null);

// Обработчик клика на кнопку
const handleButtonClick = (event) => {
  console.log('handleButtonClick called!', event);
  console.log('isExportingReport:', isExportingReport.value);
  // Останавливаем всплытие события, чтобы handleClickOutside не сработал
  if (event) {
    event.stopPropagation();
    event.preventDefault();
  }
  toggleStudentActionsDropdown();
};

// Функция для переключения выпадающего меню
const toggleStudentActionsDropdown = () => {
  console.log('toggleStudentActionsDropdown called, current value:', showStudentActionsDropdown.value);
  showStudentActionsDropdown.value = !showStudentActionsDropdown.value;
  console.log('Dropdown toggled to:', showStudentActionsDropdown.value);
  console.log('showStudentActionsDropdown ref:', showStudentActionsDropdown);
};

// Обработчик клика вне выпадающего меню
let clickOutsideTimeout = null;
const handleClickOutside = (event) => {
  // Отменяем предыдущий таймаут, если он есть
  if (clickOutsideTimeout) {
    clearTimeout(clickOutsideTimeout);
  }
  
  // Задерживаем выполнение, чтобы Vue-обработчики успели сработать первыми
  clickOutsideTimeout = setTimeout(() => {
    // Проверяем, был ли клик внутри dropdown или на кнопке
    const dropdown = event.target.closest('.actions-dropdown');
    const button = event.target.closest('button.dropdown-toggle');
    
    // Если клик был внутри dropdown, не закрываем меню
    if (dropdown || button) {
      return;
    }
    
    // Закрываем меню только если оно открыто и клик был вне его
    if (showStudentActionsDropdown.value) {
      showStudentActionsDropdown.value = false;
    }
  }, 10);
};

onMounted(async () => {
  // Ждем, пока DOM полностью отрендерится
  await nextTick();
  
  // Включаем обработчик клика вне меню
  document.addEventListener('click', handleClickOutside);
});

onUnmounted(() => {
  document.removeEventListener('click', handleClickOutside);
  if (clickOutsideTimeout) {
    clearTimeout(clickOutsideTimeout);
  }
});

// Обработчик клика на экспорт в выпадающем меню
const handleExportClick = async () => {
  showStudentActionsDropdown.value = false;
  await exportStudentReport();
};

// Функция экспорта отчета студента
const exportStudentReport = async () => {
  if (isExportingReport.value) return; // Предотвращаем повторные клики
  
  isExportingReport.value = true;
  try {
    // Импортируем функцию экспорта
    const { exportStudentReport: exportReport } = await import('../utils/excelExport');
    
    // Подготавливаем данные для отчета
    const reportData = [];
    
    // Сначала загружаем шкалы для всех курсов
    for (const courseItem of generalStore.userCourses) {
      const course = courseItem.course;
      
      // Принудительно загружаем шкалу для курса, если её нет
      if (!course.scale?.gradescales?.length) {
        try {
          await generalStore.getStudentGrades(course.id, generalStore.userEmail);
        } catch (error) {
          // Ошибка загрузки шкалы курса
        }
      }
    }
    
    generalStore.userCourses.forEach(courseItem => {
      const course = courseItem.course;
      
      if (!course.user_grades?.usergrades) return;

      // Ищем оценки текущего студента
      const studentGrades = course.user_grades.usergrades.find(
        usergrade => {
          const studentData = course.enrolled_users?.find(user => user.id === usergrade.userid);
          return studentData?.email === generalStore.userEmail;
        }
      );

      if (studentGrades) {
        // Парсим оценки - используем ту же логику, что и в StudentReportExport
        const gradeData = parseStudentGrades(studentGrades.gradeitems || []);
        const grades = gradeData.grades || gradeData; // Поддержка старого формата для обратной совместимости
        
        // Вычисляем средний балл всех студентов за дисциплину (как в exportRopReportHandler)
        const allStudents = course.user_grades?.usergrades || [];
        const validStudentsWithGrades = allStudents.map(usergrade => {
          const gradeItem = usergrade.gradeitems?.find(item => item.itemtype === 'course');
          return gradeItem ? gradeItem.graderaw : null;
        }).filter(grade => grade !== null && grade !== undefined && !isNaN(grade));
        
        const averageGrade = validStudentsWithGrades.length > 0
          ? (validStudentsWithGrades.reduce((sum, grade) => sum + parseFloat(grade), 0) / validStudentsWithGrades.length).toFixed(2)
          : null;

        reportData.push({
          course_name: course.fullname,
          frtk1: grades.frtk1 !== null && grades.frtk1 !== undefined ? grades.frtk1 : null,
          frtk2: grades.frtk2 !== null && grades.frtk2 !== undefined ? grades.frtk2 : null,
          individual: grades.individual !== null && grades.individual !== undefined ? grades.individual : null,
          final_grade: grades.total !== null && grades.total !== undefined ? grades.total : null,
          average_grade: averageGrade,
          scale: course.scale || null
        });
      }
    });

    if (reportData.length === 0) {
      await notification.addNotification({
        message: 'Не найдено оценок для экспорта',
        type: 'warning'
      });
      return;
    }

    // Экспортируем отчет
    const success = exportReport(
      reportData, 
      getCurrentUserName(), 
      generalStore.userEmail
    );

    if (success) {
      await notification.addNotification({
        message: 'Отчет успешно выгружен',
        type: 'success'
      });
    } else {
      throw new Error('Failed to export report');
    }
  } catch (error) {
    // Ошибка при экспорте отчета
    await notification.addNotification({
      message: 'Ошибка при выгрузке отчета',
      type: 'error'
    });
  } finally {
    isExportingReport.value = false;
  }
};

const exportRopReportHandler = async () => {
    try {
        if (!generalStore.userCourses.length) {
            await notification.addNotification({
                message: 'Нет курсов для формирования отчета.',
                type: 'warning'
            });
            return;
        }

        const reportData = generalStore.userCourses.map(courseItem => {
            const course = courseItem.course;
            const students = course.user_grades?.usergrades || [];
            
            // Парсим оценки для каждого студента
            const studentsGrades = students.map(usergrade => {
                const gradeData = parseStudentGrades(usergrade.gradeitems || []);
                // parseStudentGrades возвращает объект с grades, gradeItems, totalWeight
                return gradeData.grades || gradeData;
            });
            
            // Вычисляем средние значения (теперь grades содержит числовые значения graderaw)
            const validTotalGrades = studentsGrades
                .map(g => g.total)
                .filter(grade => grade !== null && grade !== undefined && !isNaN(grade));
            
            const validFrtk1Grades = studentsGrades
                .map(g => g.frtk1)
                .filter(grade => grade !== null && grade !== undefined && !isNaN(grade));
            
            const validFrtk2Grades = studentsGrades
                .map(g => g.frtk2)
                .filter(grade => grade !== null && grade !== undefined && !isNaN(grade));
            
            const validIndividualGrades = studentsGrades
                .map(g => g.individual)
                .filter(grade => grade !== null && grade !== undefined && !isNaN(grade));
            
            const average_student_grade = validTotalGrades.length > 0
                ? (validTotalGrades.reduce((sum, grade) => sum + grade, 0) / validTotalGrades.length).toFixed(2)
                : '0.00';
            
            const average_frtk1 = validFrtk1Grades.length > 0
                ? (validFrtk1Grades.reduce((sum, grade) => sum + grade, 0) / validFrtk1Grades.length).toFixed(2)
                : null;
            
            const average_frtk2 = validFrtk2Grades.length > 0
                ? (validFrtk2Grades.reduce((sum, grade) => sum + grade, 0) / validFrtk2Grades.length).toFixed(2)
                : null;
            
            const average_individual = validIndividualGrades.length > 0
                ? (validIndividualGrades.reduce((sum, grade) => sum + grade, 0) / validIndividualGrades.length).toFixed(2)
                : null;

            return {
                discipline_name: course.fullname,
                average_student_grade: average_student_grade,
                average_frtk1: average_frtk1,
                average_frtk2: average_frtk2,
                average_individual: average_individual,
                grading_scale: course.scale
            };
        });
        
        const success = exportRopReport(reportData);

        if (success) {
            await notification.addNotification({
                message: 'Отчет РОП успешно выгружен',
                type: 'success'
            });
        } else {
            throw new Error('Export function returned false');
        }

    } catch (error) {
        // Ошибка при экспорте отчета РОП
        await notification.addNotification({
            message: 'Ошибка при выгрузке отчета РОП',
            type: 'error'
        });
    }
};

// Функция для парсинга оценок студента - точно такая же как в StudentReportExport
function parseStudentGrades(gradeitems) {
  const grades = {
    frtk1: null,    // ФРТК1 - основная категория
    frtk2: null,    // ФРТК2 - дополнительная категория  
    individual: null, // Индивидуальные достижения
    total: null     // Итоговая оценка курса
  };

  const gradeItems = {
    frtk1: null,
    frtk2: null,
    individual: null,
    total: null
  };

  // Используем константы из store
  const categoryKeywords = CATEGORY_KEYWORDS;

  // Собираем только категории
  const categories = {};
  let totalWeight = 0;
  
  gradeitems.forEach(item => {
    if (item.itemtype === 'category') {
      categories[item.id] = {
        id: item.id,
        name: item.itemname || '',
        gradeValue: item.graderaw !== null && item.graderaw !== undefined ? item.graderaw : null, // Используем graderaw для числовых вычислений
        gradeFormatted: item.gradeformatted, // Сохраняем отформатированное значение для отображения
        weight: item.weightraw,
        instance: item.iteminstance
      };
      
      // Суммируем общий вес
      if (item.weightraw) {
        totalWeight += parseFloat(item.weightraw);
      }
    } else if (item.itemtype === 'course') {
      // Итоговая оценка курса - используем graderaw для числовых вычислений
      grades.total = item.graderaw !== null && item.graderaw !== undefined ? item.graderaw : null;
      gradeItems.total = {
        weight: item.weightraw || 0,
        maxGrade: item.grademax || 100
      };
    }
  });

  // Сортируем категории по весу
  const categoryKeys = Object.keys(categories);
  const sortedCategories = categoryKeys.sort((a, b) => {
    const catA = categories[a];
    const catB = categories[b];
    
    // Сортируем по весу (weightraw) - обычно ФРТК1 имеет больший вес
    if (catA.weight !== undefined && catB.weight !== undefined) {
      return catB.weight - catA.weight;
    }
    
    // Если весов нет, сортируем по id
    return parseInt(a) - parseInt(b);
  });

  // Обрабатываем каждую категорию
  sortedCategories.forEach((categoryId, index) => {
    const category = categories[categoryId];
    
    // Определяем тип категории используя функцию из store
    const categoryType = getCategoryType(category.name);
    
    // Назначаем оценку
    if (categoryType && category.gradeValue !== null && category.gradeValue !== undefined) {
      grades[categoryType] = category.gradeValue;
      gradeItems[categoryType] = {
        weight: category.weight || 0,
        maxGrade: category.maxGrade || 100
      };
    }
  });

  // Возвращаем и оценки, и информацию о весах - точно так же как в StudentReportExport
  return {
    grades: grades,
    gradeItems: gradeItems,
    totalWeight: totalWeight
  };
}
</script>

<template>
  <div class="showcase-root">
    <!-- Индикатор перезагрузки -->
    <div v-if="generalStore.isReloading" class="reload-overlay">
      <div class="reload-spinner">
        <div class="spinner-border text-primary" role="status">
          <span class="sr-only">Перезагрузка...</span>
        </div>
        <div class="reload-text">Перезагрузка приложения...</div>
      </div>
    </div>
    
    <!-- Панель инструментов -->
    <div v-if="generalStore.userCourses.length > 0" class="toolbar-panel">
      <div class="container-fluid">
        <div class="row align-items-center">
          <div class="col-lg-8 col-md-7">
            <div class="toolbar-info">
              <h5 class="toolbar-title mb-1">
                <i class="fa fa-th-large me-2 text-primary"></i>
                {{ langStore.strings.my_courses || 'Мои курсы' }}
              </h5>
              <p class="toolbar-description mb-0">
                {{ langStore.strings.courses_description || 'Управление курсами и просмотр статистики' }}
              </p>
            </div>
          </div>
          <div class="col-lg-4 col-md-5">
            <div class="toolbar-actions">
              <!-- Выпадающее меню с действиями для студентов -->
              <div 
                v-if="generalStore.userEmail && !generalStore.isROP"
                class="dropdown actions-dropdown"
                style="position: relative; z-index: 1000;"
              >
                <button 
                  ref="dropdownButtonRef"
                  class="btn btn-outline-secondary btn-sm dropdown-toggle"
                  type="button"
                  @click.stop.prevent="handleButtonClick"
                  @mousedown.stop
                  :disabled="isExportingReport"
                  title="Действия"
                  style="cursor: pointer; pointer-events: auto; z-index: 1001; position: relative;"
                >
                  <i class="fa fa-ellipsis-v"></i>
                </button>
                <ul 
                  v-if="showStudentActionsDropdown"
                  class="dropdown-menu dropdown-menu-end"
                  @click.stop
                >
                  <li>
                    <a 
                      class="dropdown-item"
                      href="#"
                      @click.prevent="handleExportClick"
                      :class="{ 'disabled': isExportingReport }"
                    >
                      <i v-if="!isExportingReport" class="fa fa-file-excel-o me-2"></i>
                      <span v-if="isExportingReport" class="export-loader-dots me-2">
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                      </span>
                      <span v-if="isExportingReport">
                        {{ langStore.strings.preparing_report || 'Подготовка отчета...' }}
                      </span>
                      <span v-else>
                        {{ langStore.strings.export_student_report || 'Выгрузить отчет студента' }}
                      </span>
                    </a>
                  </li>
                </ul>
              </div>
              
              <!-- Кнопка глобального раздела "Общее" - только для преподавателей и РОП -->
              <button 
                v-if="generalStore.isROP || (generalStore.userCourses && generalStore.userCourses.some(course => course.isTeacher))"
                @click="goToGlobalSummary" 
                class="btn btn-success btn-sm"
                title="Глобальный раздел Общее - сводка по всем курсам"
              >
                <i class="fa fa-chart-bar "></i>
                {{ langStore.strings.global_summary || 'Общее' }}
              </button>
              
              <!-- Кнопка экспорта отчета РОП - только для РОП -->
              <button
                  v-if="generalStore.isROP"
                  class="btn btn-info btn-sm"
                  @click="exportRopReportHandler"
                  title="Выгрузить сводный отчет по всем курсам"
              >
                <i class="fa fa-download me-1"></i>
                {{ langStore.strings.export_rop_report || 'Сводный отчет РОП' }}
              </button>
              
              <!-- Кнопка перезагрузки -->
              <button 
                @click="reloadApp" 
                class="btn btn-outline-primary btn-sm"
                :disabled="generalStore.isReloading"
                title="Перезагрузить приложение"
              >
                <i :class="['fa', 'fa-refresh', 'me-1', { 'fa-spin': generalStore.isReloading }]"></i>
                {{ langStore.strings.refresh || 'Обновить' }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Отображение курсов, сгруппированных по конфигам -->
    <div class="container-fluid mt-4 showcase-container" v-if="generalStore.userCourses.length">
      <!-- Если только один конфиг или не нужна группировка, показываем как раньше -->
      <template v-if="coursesByConfig.length === 1">
        <div class="row g-4">
          <div v-for="item in generalStore.userCourses" :key="item.course.id" class="col-12 col-sm-6 col-md-4 mb-4">
            <div class="course-wrapper">
              <CourseCard
                  :course="item"
                  :show-details="false"
              />
              <div class="course-actions">
                <button
                    @click="goToCourseDetail(item.course.id)"
                    class="btn btn-primary mt-3 w-100"
                >
                  <i class="fa fa-info-circle mr-2"></i>{{
                    langStore.strings.showcase_coursedetailbutton || 'Подробнее'
                  }}
                </button>
              </div>
            </div>
          </div>
        </div>
      </template>
      
      <!-- Если несколько конфигов, группируем курсы -->
      <template v-else>
        <div v-for="configGroup in coursesByConfig" :key="configGroup.id" class="config-group mb-5">
          <!-- Заголовок группы конфига -->
          <div class="config-group-header mb-3">
            <h4 class="config-title">
              <i class="fa fa-key me-2 text-primary"></i>
              {{ configGroup.name }}
              <span class="badge bg-secondary ms-2">{{ configGroup.courses.length }} {{ langStore.strings.courses || 'курсов' }}</span>
            </h4>
          </div>
          
          <!-- Курсы данного конфига -->
          <div class="row g-4">
            <div v-for="item in configGroup.courses" :key="item.course.id" class="col-12 col-sm-6 col-md-4 mb-4">
              <div class="course-wrapper">
                <CourseCard
                    :course="item"
                    :show-details="false"
                />
                <div class="course-actions">
                  <button
                      @click="goToCourseDetail(item.course.id)"
                      class="btn btn-primary mt-3 w-100"
                  >
                    <i class="fa fa-info-circle mr-2"></i>{{
                      langStore.strings.showcase_coursedetailbutton || 'Подробнее'
                    }}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </template>
    </div>
    <div v-else class="alert alert-warning">
      {{ langStore.strings.no_data || 'Данные не найдены' }}
    </div>
    <!--     Тестовая кнопка
        <div class="test-controls" v-if="generalStore.configs.length">
          <button @click="testGetCourses" class="test-button">
            Test Get Courses
          </button>
        </div>-->
  </div>
</template>

<style scoped>
.showcase-root {
  width: 100%;
  min-height: 100%;
  position: relative;
}

/* Оставляем только специфичные стили для изображения, если нужно */
.item-image {
  object-fit: cover; /* Масштабируем, чтобы заполнить область без искажений */
  background-color: #f8f9fa; /* Цвет фона для заглушки */
}

/* Можно переопределить стили Bootstrap при необходимости */
.card-title {
  font-weight: 600;
}

/* Добавляем стили для контейнера */
.showcase-container {
  width: 100%;
  max-width: 100%;
  padding: 0 15px;
  margin: 0 auto;
  position: relative;
}

/* Стили для сетки */
.row {
  margin: -1rem;
}

.row > [class*="col-"] {
  padding: 1rem;
}

/* Стили для карточек */
.course-wrapper {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
  padding: 1rem;
}

.course-wrapper:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

/* Адаптивные стили для разных размеров экрана */
@media (max-width: 576px) {
  .showcase-container {
    padding: 0 10px;
  }

  .card {
    margin-bottom: 0.5rem;
  }
}

/* Принудительно устанавливаем ширину колонок */
.col-12 {
  width: 100%;
  flex: 0 0 100%;
  max-width: 100%;
}

.col-sm-6 {
  width: 50%;
  flex: 0 0 50%;
  max-width: 50%;
}

.col-md-4 {
  width: 33.333333%;
  flex: 0 0 33.333333%;
  max-width: 33.333333%;
}

/* Стили для таблицы */
.table {
  margin-bottom: 0;
  font-size: 0.9rem;
}

.table th {
  background-color: #f8f9fa;
  font-weight: 600;
  text-align: center;
}

.table td {
  text-align: center;
  vertical-align: middle;
}

.btn-primary {
  width: 100%;
  margin-top: auto;
}

.teachers-section {
  background-color: #f8f9fa;
  border-radius: 0.25rem;
  padding: 0.5rem;
}

.list-group-item {
  background-color: transparent;
  border: none;
  padding: 0.5rem 0;
}

.list-group-item:not(:last-child) {
  border-bottom: 1px solid rgba(0, 0, 0, .125);
}

.text-muted {
  font-size: 0.9rem;
  font-weight: 500;
}

/* Стили для HTML-контента в summary */
.card-text :deep(p) {
  margin-bottom: 0.5rem;
}

.card-text :deep(img) {
  max-width: 100%;
  height: auto;
  margin: 0.5rem 0;
}

.card-text :deep(a) {
  color: #007bff;
  text-decoration: none;
}

.card-text :deep(a:hover) {
  text-decoration: underline;
}

/* Стили для панели инструментов */
.toolbar-panel {
  background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
  border: 1px solid #dee2e6;
  border-radius: 0.5rem;
  margin-bottom: 1.5rem;
  padding: 1rem 0;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
  position: relative;
  overflow: visible;
}

.toolbar-panel::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 4px;
  background: linear-gradient(90deg, #007bff, #28a745, #007bff);
  border-radius: 0.5rem 0.5rem 0 0;
}

.toolbar-info {
  padding-left: 0.5rem;
}

.toolbar-title {
  color: #495057;
  font-weight: 600;
  margin-bottom: 0.25rem;
}

.toolbar-description {
  color: #6c757d;
  font-size: 0.9rem;
}

.toolbar-actions {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex-wrap: wrap;
  justify-content: flex-end;
  position: relative;
  z-index: 1;
}

.toolbar-actions .btn {
  font-weight: 500;
  padding: 0.375rem 0.75rem;
  border-radius: 0.375rem;
  transition: all 0.3s ease;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  font-size: 0.875rem;
  white-space: nowrap;
  min-width: auto;
  flex-shrink: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 200px;
}

.toolbar-actions .btn i {
  flex-shrink: 0;
  margin-right: 0.25rem;
}

/* Стили для выпадающего меню действий */
.actions-dropdown {
  position: relative !important;
  z-index: 1000;
}

.actions-dropdown .dropdown-toggle {
  padding: 0.375rem 0.5rem;
  min-width: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: visible;
}

.actions-dropdown .dropdown-toggle::after {
  display: none;
}

.actions-dropdown .dropdown-menu {
  position: absolute !important;
  top: 100% !important;
  right: 0 !important;
  min-width: 200px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  border: 1px solid #dee2e6;
  border-radius: 0.375rem;
  padding: 0.25rem 0;
  margin-top: 0.25rem;
  background-color: #fff !important;
  z-index: 9999 !important;
  list-style: none;
  margin-left: 0;
  display: block !important;
  visibility: visible !important;
  opacity: 1 !important;
}

.actions-dropdown .dropdown-item {
  padding: 0.5rem 1rem;
  display: flex;
  align-items: center;
  color: #212529;
  text-decoration: none;
  transition: background-color 0.2s ease;
}

.actions-dropdown .dropdown-item:hover:not(.disabled) {
  background-color: #f8f9fa;
  color: #212529;
}

.actions-dropdown .dropdown-item.disabled {
  opacity: 0.6;
  cursor: not-allowed;
  pointer-events: none;
}

.actions-dropdown .dropdown-item i {
  width: 20px;
  text-align: center;
}

.toolbar-actions .btn:hover:not(:disabled) {
  transform: translateY(-1px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.toolbar-actions .btn:active:not(:disabled) {
  transform: translateY(0);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.toolbar-actions .btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
  transform: none !important;
}

.toolbar-actions .btn-success {
  background: linear-gradient(135deg, #28a745, #20c997);
  border: none;
}

.toolbar-actions .btn-success:hover:not(:disabled) {
  background: linear-gradient(135deg, #218838, #1ea786);
}

.toolbar-actions .btn-outline-primary {
  color: #007bff;
  border-color: #007bff;
  background: transparent;
}

.toolbar-actions .btn-outline-primary:hover:not(:disabled) {
  background: #007bff;
  color: white;
}

/* Адаптивность панели инструментов */
@media (min-width: 1200px) {
  .toolbar-actions {
    justify-content: flex-end;
    gap: 0.75rem;
  }
  
  .toolbar-actions .btn {
    font-size: 0.9rem;
    padding: 0.4rem 0.8rem;
    max-width: 220px;
  }
}

@media (max-width: 1199px) and (min-width: 992px) {
  .toolbar-actions {
    justify-content: flex-end;
    gap: 0.5rem;
  }
  
  .toolbar-actions .btn {
    font-size: 0.85rem;
    padding: 0.35rem 0.7rem;
    max-width: 180px;
  }
}

@media (max-width: 991px) and (min-width: 769px) {
  .toolbar-actions {
    justify-content: flex-end;
    gap: 0.5rem;
  }
  
  .toolbar-actions .btn {
    font-size: 0.8rem;
    padding: 0.3rem 0.6rem;
    max-width: 160px;
  }
}

@media (max-width: 768px) {
  .toolbar-panel {
    margin-bottom: 1rem;
    padding: 0.75rem 0;
  }
  
  .toolbar-panel .row {
    flex-direction: column;
    gap: 1rem;
  }
  
  .toolbar-panel .col-lg-4 {
    text-align: center !important;
  }
  
  .toolbar-actions {
    justify-content: center;
    flex-wrap: wrap;
    gap: 0.5rem;
  }
  
  .toolbar-actions .btn {
    font-size: 0.8rem;
    padding: 0.3rem 0.6rem;
    min-width: 100px;
    flex: 0 0 auto;
    max-width: 150px;
  }
  
  .toolbar-title {
    font-size: 1.1rem;
    text-align: center;
  }
  
  .toolbar-description {
    text-align: center;
    font-size: 0.85rem;
  }
}

@media (max-width: 576px) {
  .toolbar-actions {
    flex-direction: column;
    width: 100%;
    gap: 0.5rem;
  }
  
  .toolbar-actions .btn {
    width: 100%;
    margin-bottom: 0;
    font-size: 0.8rem;
    padding: 0.4rem 0.8rem;
  }
  
  .toolbar-actions .btn:last-child {
    margin-bottom: 0;
  }
}

/* Стили для оверлея перезагрузки */
.reload-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(255, 255, 255, 0.9);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1001;
  backdrop-filter: blur(2px);
}

.reload-spinner {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 15px;
}

.reload-text {
  font-size: 16px;
  font-weight: 500;
  color: #007bff;
}

/* Стили для тестовой кнопки */
.test-controls {
  position: absolute;
  top: 10px;
  right: 10px;
  z-index: 1000;
  background: rgba(255, 255, 255, 0.9);
  padding: 10px;
  border-radius: 4px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.test-button {
  background-color: #4CAF50;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s;
}

.test-button:hover {
  background-color: #45a049;
}

.test-button:active {
  background-color: #3d8b40;
}

/* Стили для группировки конфигов */
.config-group {
  border: 1px solid #dee2e6;
  border-radius: 0.75rem;
  padding: 1.5rem;
  background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  transition: box-shadow 0.3s ease;
}

.config-group:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
}

.config-group-header {
  border-bottom: 2px solid #e9ecef;
  padding-bottom: 1rem;
  margin-bottom: 1.5rem;
}

.config-title {
  color: #495057;
  font-weight: 600;
  font-size: 1.4rem;
  margin: 0;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.config-title .badge {
  font-size: 0.8rem;
  font-weight: 500;
  padding: 0.375rem 0.75rem;
  border-radius: 12px;
}

/* Адаптивность для группировки */
@media (max-width: 768px) {
  .config-group {
    padding: 1rem;
  }
  
  .config-title {
    font-size: 1.2rem;
    flex-direction: column;
    align-items: flex-start;
  }
  
  .config-title .badge {
    align-self: flex-start;
  }
}

@media (max-width: 576px) {
  .config-group {
    padding: 0.75rem;
  }
  
  .config-title {
    font-size: 1rem;
  }
}

/* Индикатор загрузки с перебегающими точками */
.export-loader-dots {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  vertical-align: middle;
}

.export-loader-dots .dot {
  display: inline-block;
  width: 4px;
  height: 4px;
  border-radius: 50%;
  background-color: currentColor;
  animation: export-dots-bounce 1.4s infinite ease-in-out;
}

.export-loader-dots .dot:nth-child(1) {
  animation-delay: -0.32s;
}

.export-loader-dots .dot:nth-child(2) {
  animation-delay: -0.16s;
}

.export-loader-dots .dot:nth-child(3) {
  animation-delay: 0s;
}

@keyframes export-dots-bounce {
  0%, 80%, 100% {
    transform: scale(0.8);
    opacity: 0.5;
  }
  40% {
    transform: scale(1);
    opacity: 1;
  }
}

/* Кнопка в состоянии загрузки */
.btn:disabled {
  opacity: 0.7;
  cursor: not-allowed;
}
</style>