<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace block_cdo_showcase;

defined('MOODLE_INTERNAL') || die();

/*require_once($CFG->libdir . '/externallib.php');*/


use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use core_external\external_value;
use block_cdo_showcase\local\controller;
use invalid_parameter_exception;
use moodle_exception;

/**
 * External API class for block_cdo_showcase
 *
 * @package    block_cdo_showcase
 * @category   external
 * @copyright  2024 Your Name <your.email@example.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class external extends external_api
{
    /**
     * Returns description of get_settings() parameters
     *
     * @return external_function_parameters
     */
    public static function get_settings_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            'conditions'  => new external_multiple_structure(
                new external_single_structure(
                    [
                        'name' => new external_value(PARAM_ALPHANUMEXT, 'option name'),
                        'value' => new external_value(PARAM_RAW, 'option value')
                    ]
                ),
                '',
                VALUE_DEFAULT,
                []
            )
        ]);
    }

    /**
     * Get all showcase settings
     *
     * @param array $conditions
     * @return array
     */
    public static function get_settings(array $conditions = []): array
    {
        //return array_values(controller::get_all_settings(['token_status' => true]));
        $real_conditions = [];
        if (!empty($conditions)) {
            foreach ($conditions as $item) {
                $real_conditions[$item['name']] = $item['value'];
            }

        }
        return array_values(controller::get_all_settings($real_conditions));
    }

    /**
     * Returns description of get_settings() result value
     *
     * @return external_multiple_structure
     */
    public static function get_settings_returns(): external_multiple_structure
    {
        return new external_multiple_structure(
            new external_single_structure([
                'id' => new external_value(PARAM_INT, 'Setting ID'),
                'name' => new external_value(PARAM_TEXT, 'Setting name'),
                'url' => new external_value(PARAM_TEXT, 'Setting URL'),
                'token' => new external_value(PARAM_TEXT, 'Setting token'),
                'token_status' => new external_value(PARAM_BOOL, 'Setting token'),
                'timecreated' => new external_value(PARAM_INT, 'Time created'),
                'timemodified' => new external_value(PARAM_INT, 'Time modified'),
            ])
        );
    }

    /**
     * Returns description of save_settings() parameters
     *
     * @return external_function_parameters
     */
    public static function save_settings_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            'settings' => new external_multiple_structure(
                new external_single_structure([
                    'id' => new external_value(PARAM_INT, 'Setting ID', VALUE_OPTIONAL),
                    'name' => new external_value(PARAM_TEXT, 'Setting name'),
                    'url' => new external_value(PARAM_TEXT, 'Setting URL'),
                    'token' => new external_value(PARAM_TEXT, 'Setting token'),
                    'token_status' => new external_value(PARAM_BOOL, 'Setting token'),
                    'timecreated' => new external_value(PARAM_TEXT, 'Setting token', VALUE_DEFAULT, 0),
                    'timemodified' => new external_value(PARAM_TEXT, 'Setting token', VALUE_DEFAULT, 0),
                    'saved' => new external_value(PARAM_TEXT, 'Setting token', VALUE_DEFAULT, 0),
                ])
            )
        ]);
    }

    /**
     * Save showcase settings
     *
     * @param array $settings Array of settings to save
     * @return array
     * @throws moodle_exception
     */
    public static function save_settings(array $settings): array
    {

        $result = [];
        foreach ($settings as $setting) {
            $data = (object)$setting;
            //  try {

            if (empty($data->id)) {
                $id = controller::create_setting($data);
                $result[] = ['id' => $id, 'success' => true];
            } else {
                $success = controller::update_setting($data);
                $result[] = ['id' => $data->id, 'success' => $success];
            }
            /*} catch (\Exception $e) {
                throw new \Exception()
            }*/
        }
        return $result;
    }

    /**
     * Returns description of save_settings() result value
     *
     * @return external_multiple_structure
     */
    public static function save_settings_returns(): external_multiple_structure
    {
        return new external_multiple_structure(
            new external_single_structure([
                'id' => new external_value(PARAM_INT, 'Setting ID'),
                'success' => new external_value(PARAM_BOOL, 'Operation success'),
                'error' => new external_value(PARAM_TEXT, 'Error message', VALUE_OPTIONAL),
            ])
        );
    }

    /**
     * Returns description of delete_setting() parameters
     *
     * @return external_function_parameters
     */
    public static function delete_setting_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            'id' => new external_value(PARAM_INT, 'Setting ID')
        ]);
    }

    /**
     * Delete a showcase setting
     *
     * @param int $id Setting ID
     * @return array
     */
    public static function delete_setting(int $id): array
    {

        try {
            $success = controller::delete_setting($id);
            return ['success' => $success];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Returns description of delete_setting() result value
     *
     * @return external_single_structure
     */
    public static function delete_setting_returns(): external_single_structure
    {
        return new external_single_structure([
            'success' => new external_value(PARAM_BOOL, 'Operation success'),
            'error' => new external_value(PARAM_TEXT, 'Error message', VALUE_OPTIONAL),
        ]);
    }


} 