import {defineStore} from 'pinia'
import * as moodleAjax from 'core/ajax';
import notification from "core/notification";

export const useGeneralStore = defineStore('general', {
    state: () => ({
        configs: [],
        userCourses: [],
        userEmail: '',
        isROP: false,
        apiRequestParam: '', // Категория отбора курсов для API запросов
        gradesCache: new Map(),
        appKey: 0, // Ключ для принудительного перерендера приложения
        isReloading: false // Состояние перезагрузки приложения
    }),
    actions: {
        // Функция для перезагрузки Vue приложения
        async reloadApp() {
            // Устанавливаем состояние загрузки
            this.isReloading = true;
            
            // Очищаем данные
            this.configs = [];
            this.userCourses = [];
            this.gradesCache.clear();
            
            // Увеличиваем ключ для принудительного перерендера
            this.appKey++;
            
            try {
                // Перезагружаем данные
                if (this.isROP) {
                    await this.fetchROPConfig();
                    await this.getROPCourses();
                } else {
                    await this.fetchConfigs();
                    await this.getUserCourses();
                }
            } finally {
                // Убираем состояние загрузки
                this.isReloading = false;
            }
        },
        setUserEmail(email) {
            this.userEmail = email;
        },
        setUserCourses(courses, config) {
            const coursesWithConfig = courses.map(course => {
                // Находим текущего пользователя в списке enrolled_users
                const currentUser = course.enrolled_users && course.enrolled_users.find(user => user.email === this.userEmail);
                
                // Проверяем, является ли пользователь преподавателем
                // В Moodle роль преподавателя имеет id = 3
                const isTeacher = currentUser && currentUser.roles && currentUser.roles.some(role => role.roleid === 3);

                return {
                    course: {
                        ...course,
                        scale: course.scale || { gradescales: [], courseid: course.id, userid: 0 }
                    },
                    config: config,
                    isTeacher: isTeacher || false
                };
            });

            this.userCourses.push(...coursesWithConfig);
        },
        getCourseConfig(courseId) {
            const courseData = this.userCourses.find(item => item.course.id === courseId);
            return courseData ? courseData.config : null;
        },
        getCourse(courseId) {
            const courseData = this.userCourses.find(item => item.course.id === courseId);
            return courseData ? courseData.course : null;
        },
        async fetchConfigs() {
            try {
                // Для РОП пользователей получаем только назначенный им конфиг
                if (this.isROP) {
                    await this.fetchROPConfig();
                } else {
                    // Для обычных пользователей получаем все активные конфиги
                    const request = {
                        methodname: 'block_cdo_showcase_get_settings',
                        args: {
                            conditions: [
                                {name: 'token_status', value: true}
                            ]
                        },
                    };
                    this.configs = await moodleAjax.call([request])[0];
                }
            } catch (error) {
                await notification.exception(error);
            }
        },
        async fetchROPConfig() {
            try {
                const config = await moodleAjax.call([{
                    methodname: 'block_cdo_showcase_get_rop_config',
                    args: {
                        email: this.userEmail
                    }
                }])[0];

                // Если конфиг найден, добавляем его в массив configs
                if (config.length) {
                    this.configs = config;
                } else {
                    this.configs = [];
                    let message = {
                        message: 'Для данного РОП пользователя не найдено назначенного токена',
                        type: 'warning'
                    }
                    await notification.addNotification(message);
                }
            } catch (error) {
                this.configs = [];
                let message = {
                    message: 'Ошибка при получении конфига РОП: ' + error.message,
                    type: 'error'
                }
                await notification.addNotification(message);
            }
        },
        async getROPCourses() {
            try {
                // Проверяем наличие конфигов
                if (!this.configs || this.configs.length === 0) {
                    throw new Error('No configuration found for ROP user');
                }

                // Очищаем старые курсы перед загрузкой новых
                this.userCourses = [];

                // Итерируем по всем конфигам РОП пользователя
                for (const activeConfig of this.configs) {
                    try {
                        // Используем category_id из конфига, если он есть, иначе используем apiRequestParam
                        const categoryId = activeConfig.category_id !== null && activeConfig.category_id !== undefined 
                            ? activeConfig.category_id 
                            : this.apiRequestParam;
                        
                        const result = await moodleAjax.call([{
                            methodname: 'block_cdo_showcase_get_rop_courses',
                            args: {
                                configid: activeConfig.id,
                                email: this.userEmail,
                                apiRequestParam: categoryId
                            }
                        }])[0];

                        if (result.hasOwnProperty('errorcode')) {
                            let message = {
                                message: `${activeConfig.token_name || 'Конфиг'}: ${result.errorcode} - ${result.error}`,
                                type: 'error'
                            }
                            await notification.addNotification(message);
                        } else {
                            // Преобразуем данные в нужный формат для текущего конфига
                            const ropCourses = result.map(course => ({
                                course: {
                                    id: course.id,
                                    fullname: course.fullname,
                                    shortname: course.shortname,
                                    summary: course.summary,
                                    courseimage: course.courseimage || '',
                                    enrolled_users: course.enrolled_users || [],
                                    user_grades: course.user_grades || [],
                                    scale: course.scale || {},
                                },
                                config: {
                                    id: activeConfig.id,
                                    name: activeConfig.token_name || 'РОП Конфиг',
                                    assigned_date: course.assigned_date
                                },
                                isTeacher: true // ROP пользователи должны видеть интерфейс как преподаватели
                            }));
                            
                            this.userCourses.push(...ropCourses);
                        }
                    } catch (configError) {
                        let message = {
                            message: `${activeConfig.token_name || 'Конфиг'}: Ошибка при получении курсов - ${configError.message}`,
                            type: 'error'
                        }
                        await notification.addNotification(message);
                    }
                }
            } catch (error) {
                let message = {
                    message: "Ошибка при получении курсов РОП: " + error.message,
                    type: 'error'
                }
                await notification.addNotification(message);
            }
        },
        async getUserCourses() {
            if (this.configs.length) {
                await Promise.all(this.configs.map(config => this.getUserCourse(config)));
            } else {
                let message = {
                    message: 'Не найдено настроенных токенов',
                    type: 'error'
                }
                await notification.addNotification(message);
            }
        },
        async getUserCourse(config) {
            try {
                // Используем category_id из конфига, если он есть, иначе используем apiRequestParam
                const categoryId = config.category_id !== null && config.category_id !== undefined 
                    ? config.category_id 
                    : this.apiRequestParam;
                
                const result = await moodleAjax.call([{
                    methodname: 'block_cdo_showcase_get_user_courses_by_config',
                    args: {
                        configid: config.id,
                        email: this.userEmail,
                        apiRequestParam: categoryId
                    }
                }])[0];

                if (result.hasOwnProperty('errorcode')) {
                    let message = {
                        message: result.errorcode + ": " + result.message, type: 'error'
                    }
                    await notification.addNotification(message);
                } else {
                    this.setUserCourses(result, config);
                }
            } catch (error) {
                let message = {
                    message: `Не удалось подключиться к ${config.url}: ${error.message}`, type: 'error'
                }
                await notification.addNotification(message);
            }
        },
        async getStudentGrades(courseId, studentEmail) {
            try {
                // Проверяем кэш
                const cacheKey = `${courseId}-${studentEmail}`;
                if (this.gradesCache.has(cacheKey)) {
                    return this.gradesCache.get(cacheKey);
                }

                const courseConfig = await this.getCourseConfig(courseId);
                if (!courseConfig) {
                    console.error('Config not found for course:', courseId);
                    return null;
                }
                
                const result = await moodleAjax.call([{
                    methodname: 'block_cdo_showcase_get_user_grades_by_config',
                    args: {
                        configid: courseConfig.id,
                        courseid: courseId,
                        email: studentEmail
                    }
                }])[0];

                if (result && !result.exception) {
                    const grades = {
                        grade1: result.grade1 ?? 0,
                        grade2: result.grade2 ?? 0,
                        grade3: result.grade3 ?? 0,
                        total_grade: result.total_grade ?? 0,
                        status: result.status ?? 'in_progress',
                        average_grade: result.average_grade
                    };

                    // Обновляем данные курса с полученной шкалой оценивания
                    if (result.scale) {
                        this.updateCourseScale(courseId, result.scale);
                    }

                    // Сохраняем в кэш
                    this.gradesCache.set(cacheKey, grades);
                    return grades;
                }
                return null;
            } catch (error) {
                console.error('Error in getStudentGrades:', error);
                await notification.addNotification({
                    message: error.message || 'Error getting grades',
                    type: 'error'
                });
                return null;
            }
        },
        clearGradesCache() {
            this.gradesCache.clear();
        },
        updateCourseScale(courseId, scale) {
            // Находим курс и обновляем его данные о шкале
            const courseItem = this.userCourses.find(item => item.course.id === courseId);
            if (courseItem && courseItem.course) {
                courseItem.course.scale = scale;
            }
        },
        async refreshStudentGrades(courseId, studentEmail) {
            try {
                const grades = await this.getStudentGrades(courseId, studentEmail);
                // Обновляем кэш
                const cacheKey = `${courseId}_${studentEmail}`;
                this.gradesCache.set(cacheKey, grades);
                return grades;
            } catch (error) {
                console.error('Error refreshing student grades:', error);
                throw error;
            }
        }
    }
});