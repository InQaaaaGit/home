import App from './components/Settings.vue';
import {createApp} from "vue";
import {createPinia} from 'pinia';

import {useLangStore} from "./store/storeLang";
import {useGeneralStore} from "./store/storeGeneral";

async function init() {
    const pinia = createPinia();
    const app = createApp(App);
    app.use(pinia);
    const lang = useLangStore();
    lang.loadComponentStrings('block_cdo_showcase');
    const general = useGeneralStore();
    await general.loadSettings();
    app.mount('#settings_app');

}

export {
    init
};
