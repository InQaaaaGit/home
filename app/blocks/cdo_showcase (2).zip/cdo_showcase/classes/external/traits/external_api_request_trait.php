<?php

namespace block_cdo_showcase\external\traits;

/**
 * Trait for making external API requests
 * 
 * This trait provides a common method for making HTTP requests to external APIs
 * and can be used by any external API class to avoid code duplication.
 */
trait external_api_request_trait
{
    /**
     * Make a request to external API using standard PHP cURL
     *
     * @param string $url External API URL
     * @param string $token External API token
     * @param string $wsfunction Web service function name
     * @param array $params Additional parameters
     * @return mixed
     * @throws \moodle_exception
     */
    private static function make_request(string $url, string $token, string $wsfunction, array $params = array()): mixed
    {
        
        // Формируем URL с учетом порта
        $parsed_url = parse_url($url);
        $base_url = $parsed_url['scheme'] . '://' . $parsed_url['host'];
        if (isset($parsed_url['port'])) {
            $base_url .= ':' . $parsed_url['port'];
        }
        if (isset($parsed_url['path'])) {
            $base_url .= $parsed_url['path'];
        }
        $api_url = $base_url . '/webservice/rest/server.php';

        // Build POST data manually for compatibility
        $post_parts = array();
        $post_parts[] = 'wstoken=' . urlencode($token);
        $post_parts[] = 'wsfunction=' . urlencode($wsfunction);
        $post_parts[] = 'moodlewsrestformat=json';
        
        // Add additional parameters
        if (!empty($params)) {
            $flattened = self::flatten_params($params);
            foreach ($flattened as $key => $value) {
                $post_parts[] = urlencode($key) . '=' . urlencode($value);
            }
        }
        
        $post_data = implode('&', $post_parts);

        // Initialize cURL
        $curl = curl_init();
        
        // Set cURL options
        curl_setopt_array($curl, array(
            CURLOPT_URL => $api_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $post_data,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/x-www-form-urlencoded'
            )
        ));

        // Get SSL verification setting from Moodle config
        $ssl_verification = get_config('block_cdo_showcase', 'ssl_verification');
        
        // Apply SSL verification settings based on configuration
        if ($ssl_verification == 0) {
            // SSL verification disabled
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        } else {
            // SSL verification enabled (default)
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
        }

        // Execute request
        $response = curl_exec($curl);
        
        // Check for cURL errors
        if ($response === false) {
            $error = curl_error($curl);
            $errno = curl_errno($curl);
            curl_close($curl);
            throw new \moodle_exception('externalapierror', 'block_cdo_showcase', '', "cURL Error ($errno): $error");
        }
        
        // Get HTTP status code
        $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        
        // Check HTTP status
        if ($http_code >= 400) {
            throw new \moodle_exception('externalapierror', 'block_cdo_showcase', '', "HTTP Error: $http_code");
        }

        // Decode response
        $result = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \moodle_exception('invalidjsonresponse', 'block_cdo_showcase', '', 
                'JSON Error: ' . json_last_error_msg() . '. Response: ' . substr($response, 0, 500));
        }

        // Check for API errors
        if (isset($result['exception'])) {
            throw new \moodle_exception('externalapierror', 'block_cdo_showcase', '', 
                isset($result['message']) ? $result['message'] : 'Unknown API error');
        }

        return $result;
    }
    
    /**
     * Flatten complex parameters for proper URL encoding
     * 
     * @param array $params
     * @param string $prefix
     * @return array
     */
    private static function flatten_params(array $params, string $prefix = ''): array
    {
        $result = array();
        
        foreach ($params as $key => $value) {
            $param_key = $prefix ? $prefix . '[' . $key . ']' : $key;
            
            if (is_array($value)) {
                $result = array_merge($result, self::flatten_params($value, $param_key));
            } else {
                $result[$param_key] = $value;
            }
        }
        
        return $result;
    }
} 