<?php

namespace block_cdo_showcase\external;

use block_cdo_showcase\external\traits\external_api_request_trait;
use block_cdo_showcase\local\controller;
use context_system;
use core\exception\moodle_exception;
use core_course_external;
use core_enrol_external;
use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use core_external\external_value;

require_once $CFG->libdir . '/filelib.php';
require_once $CFG->dirroot . '/enrol/externallib.php';

class courses_external extends external_api
{
    use external_api_request_trait;

    /**
     * Returns description of get_user_courses_by_config() parameters
     * @return external_function_parameters
     */
    public static function get_user_courses_by_config_parameters(): external_function_parameters
    {
        return new external_function_parameters(
            array(
                'configid' => new external_value(PARAM_INT, 'Configuration ID'),
                'email' => new external_value(PARAM_EMAIL, 'User email'),
                'apiRequestParam' => new external_value(PARAM_TEXT, 'Course selection category parameter', VALUE_OPTIONAL)
            )
        );
    }

    /**
     * Returns description of get_user_courses_by_config() result value
     * @return external_multiple_structure
     */
    public static function get_user_courses_by_config_returns(): external_multiple_structure
    {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id' => new external_value(PARAM_INT, 'Course ID'),
                    'fullname' => new external_value(PARAM_TEXT, 'Course full name'),
                    'shortname' => new external_value(PARAM_TEXT, 'Course short name'),
                    'summary' => new external_value(PARAM_RAW, 'Course summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_value(PARAM_INT, 'Course summary format', VALUE_OPTIONAL),
                    'courseimage' => new external_value(PARAM_RAW, 'Course image URL', VALUE_OPTIONAL),
                    'enrolled_users' => new external_multiple_structure(
                        new external_single_structure(
                            array(
                                'id' => new external_value(PARAM_INT, 'User ID'),
                                'email' => new external_value(PARAM_EMAIL, 'User email'),
                                'firstname' => new external_value(PARAM_TEXT, 'User first name', VALUE_OPTIONAL),
                                'lastname' => new external_value(PARAM_TEXT, 'User last name', VALUE_OPTIONAL),
                                'profileimageurlsmall' => new external_value(PARAM_URL, 'Profile image URL small', VALUE_OPTIONAL),
                                'roles' => new external_multiple_structure(
                                    new external_single_structure(
                                        array(
                                            'roleid' => new external_value(PARAM_INT, 'Role ID'),
                                            'name' => new external_value(PARAM_TEXT, 'Role name')
                                        )
                                    )
                                )
                            )
                        ), 'Enrolled users', VALUE_OPTIONAL
                    ),
                    'user_grades' => new external_single_structure(
                        array(
                            'usergrades' => new external_multiple_structure(
                                new external_single_structure(
                                    array(
                                        'userid' => new external_value(PARAM_INT, 'User ID'),
                                        'userfullname' => new external_value(PARAM_TEXT, 'User full name'),
                                        'gradeitems' => new external_multiple_structure(
                                            new external_single_structure(
                                                array(
                                                    'id' => new external_value(PARAM_INT, 'Grade item ID'),
                                                    'itemname' => new external_value(PARAM_TEXT, 'Grade item name'),
                                                    'itemtype' => new external_value(PARAM_TEXT, 'Grade item type'),
                                                    'iteminstance' => new external_value(PARAM_INT, 'Grade item instance', VALUE_OPTIONAL),
                                                    'weightraw' => new external_value(PARAM_FLOAT, 'Weight of the grade item', VALUE_OPTIONAL),
                                                    'graderaw' => new external_value(PARAM_FLOAT, 'Raw grade value', VALUE_OPTIONAL),
                                                    'grademax' => new external_value(PARAM_FLOAT, 'Maximum grade value', VALUE_OPTIONAL),
                                                    'gradeformatted' => new external_value(PARAM_RAW, 'Formatted grade value', VALUE_OPTIONAL),
                                                    'percentageformatted' => new external_value(PARAM_TEXT, 'Formatted percentage', VALUE_OPTIONAL),
                                                    'feedback' => new external_value(PARAM_TEXT, 'Feedback for the grade', VALUE_OPTIONAL)
                                                )
                                            ), 'Grade items for user'
                                        )
                                    )
                                ), 'User grades list'
                            )
                        ), 'User grades information', VALUE_OPTIONAL
                    )
                )
            )
        );

    }

    /**
     * Get user courses by configuration ID
     * @param int $configid Configuration ID
     * @param string $email User email
     * @param string $apiRequestParam Course selection category parameter
     * @return array
     * @throws moodle_exception
     */
    public static function get_user_courses_by_config(int $configid, string $email, string $apiRequestParam = ''): array
    {
        // Parameter validation
        $params = self::validate_parameters(self::get_user_courses_by_config_parameters(),
            array('configid' => $configid, 'email' => $email, 'apiRequestParam' => $apiRequestParam));

        // Context validation
        $context = context_system::instance();
        self::validate_context($context);

        // Get configuration
        $config = controller::get_setting($params['configid']);
        if (!$config->token_status) {
            throw new moodle_exception('invalidtoken', 'block_cdo_showcase');
        }

        try {
            // Используем category_id из настроек подключения, если он задан, иначе используем глобальную настройку
            $categoryId = !empty($config->category_id) ? $config->category_id : get_config('block_cdo_showcase', 'api_request_param');
            
            // Используем метод make_request для выполнения POST-запроса
            $result = self::make_request(
                $config->url,
                $config->token,
                'tool_cdo_showcase_tools_get_users_courses',
                [
                    'email' => $params['email'],
                    'returnusercount' => 0,
                    'apiRequestParam' => $categoryId
                ]
            );

            // Проверяем структуру ответа
            if (!is_array($result)) {
                throw new moodle_exception('invalidresponse', 'block_cdo_showcase');
            }

            // Проверяем обязательные поля
            foreach ($result as $course) {
                if (!isset($course['id']) || !isset($course['fullname']) || !isset($course['shortname'])) {
                    throw new moodle_exception('invalidresponse', 'block_cdo_showcase');
                }
            }

            // Обрабатываем результат, чтобы гарантировать наличие всех необходимых полей
            $processed_courses = [];
            foreach ($result as $course) {
                $processed_course = [
                    'id' => $course['id'],
                    'fullname' => $course['fullname'],
                    'shortname' => $course['shortname'],
                    'summary' => $course['summary'] ?? '',
                    'summaryformat' => $course['summaryformat'] ?? 1,
                    'courseimage' => $course['courseimage'] ?? '',
                    'enrolled_users' => [],
                    'user_grades' => [
                        'usergrades' => []
                    ]
                ];

                // Обрабатываем enrolled_users
                if (isset($course['enrolled_users']) && is_array($course['enrolled_users'])) {
                    foreach ($course['enrolled_users'] as $user) {
                        $processed_user = [
                            'id' => $user['id'] ?? 0,
                            'email' => $user['email'] ?? '',
                            'firstname' => $user['firstname'] ?? '',
                            'lastname' => $user['lastname'] ?? '',
                            'profileimageurlsmall' => $user['profileimageurlsmall'] ?? '',
                            'roles' => $user['roles'] ?? []
                        ];
                        $processed_course['enrolled_users'][] = $processed_user;
                    }
                }

                // Обрабатываем user_grades
                if (isset($course['user_grades']) && is_array($course['user_grades'])) {
                    if (isset($course['user_grades']['usergrades']) && is_array($course['user_grades']['usergrades'])) {
                        $processed_course['user_grades']['usergrades'] = $course['user_grades']['usergrades'];
                    }
                }

                $processed_courses[] = $processed_course;
            }

            return $processed_courses;

        } catch (moodle_exception $e) {
            // Логируем ошибку
            debugging('External API error: ' . $e->getMessage(), DEBUG_DEVELOPER);
            throw $e;
        } catch (\Exception $e) {
            // Логируем неожиданные ошибки
            debugging('Unexpected error in get_user_courses_by_config: ' . $e->getMessage(), DEBUG_DEVELOPER);
            throw new moodle_exception('externalapierror', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Returns description of search_courses() parameters
     *
     * @return external_function_parameters
     */
    public static function search_courses_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            'configid' => new external_value(PARAM_INT, 'Configuration ID'),
            'category_id' => new external_value(PARAM_INT, 'Category ID on donor site', VALUE_OPTIONAL)
        ]);
    }

    /**
     * Search courses
     *
     * @param int $configid
     * @param int|null $category_id Optional category ID to override config category_id
     * @return array
     * @throws moodle_exception
     */
    public static function search_courses(int $configid, ?int $category_id = null): array
    {
        // Parameter validation
        $params = self::validate_parameters(self::search_courses_parameters(), ['configid' => $configid, 'category_id' => $category_id]);
        $config = controller::get_setting($params['configid']);
        if (!$config->token_status) {
            throw new moodle_exception('invalidtoken', 'block_cdo_showcase');
        }
        try {
            // Приоритет: переданный category_id > category_id из конфига > глобальная настройка
            $categoryId = null;
            if (!empty($params['category_id'])) {
                $categoryId = $params['category_id'];
            } elseif (!empty($config->category_id)) {
                $categoryId = $config->category_id;
            } else {
                $categoryId = get_config('block_cdo_showcase', 'api_request_param');
            }
            
            $result = self::make_request(
                $config->url,
                $config->token,
                'tool_cdo_showcase_tools_get_courses_by_category',
                [
                    'options' => [],
                    'category_id' => $categoryId
                ]
            );
            
            // Фильтруем результат - исключаем курс с id=1 (стартовый курс Moodle)
            if (is_array($result)) {
                $result = array_filter($result, function($course) {
                    return isset($course['id']) && $course['id'] != 1;
                });
                // Переиндексируем массив для сохранения числовых ключей
                $result = array_values($result);
            }
            
            return $result;
        } catch (\Exception $e) {
            throw new moodle_exception('error_searching_courses', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Returns description of search_courses() result value
     *
     * @return external_multiple_structure
     */
    public static function search_courses_returns(): external_multiple_structure
    {
        global $CFG;
        require_once $CFG->dirroot . '/course/externallib.php';
        return core_course_external::get_courses_returns();
    }
} 