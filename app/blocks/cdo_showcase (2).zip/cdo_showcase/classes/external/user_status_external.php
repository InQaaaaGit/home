<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace block_cdo_showcase\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;
use block_cdo_showcase\local\controller;
use moodle_exception;

/**
 * External API class for user status management
 *
 * @package    block_cdo_showcase
 * @category   external
 * @copyright  2024 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class user_status_external extends external_api
{
    /**
     * Returns description of get_user_status() parameters
     * @return external_function_parameters
     */
    public static function get_user_status_parameters(): external_function_parameters
    {
        return new external_function_parameters([]);
    }

    /**
     * Get current user status (including ROP status)
     * @return array
     */
    public static function get_user_status(): array
    {
        // Context validation
        $context = \context_system::instance();
        self::validate_context($context);

        try {
            return [
                'isROP' => controller::user_has_token_assignments(),
                'tokens_count' => controller::get_user_tokens_count(),
                'courses_count' => controller::get_user_courses_count()
            ];
        } catch (\Exception $e) {
            throw new moodle_exception('error_getting_user_status', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Returns description of get_user_status() result value
     *
     * @return external_single_structure
     */
    public static function get_user_status_returns(): external_single_structure
    {
        return new external_single_structure([
            'isROP' => new external_value(PARAM_BOOL, 'Is user ROP'),
            'tokens_count' => new external_value(PARAM_INT, 'User tokens count'),
            'courses_count' => new external_value(PARAM_INT, 'User courses count'),
        ]);
    }
} 