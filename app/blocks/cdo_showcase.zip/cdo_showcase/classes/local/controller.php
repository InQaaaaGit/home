<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace block_cdo_showcase\local;

use dml_exception;
use stdClass;
use moodle_exception;

/**
 * Controller class for managing CDO showcase settings
 *
 * @package   block_cdo_showcase
 * @copyright 2024 Your Name <your.email@example.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class controller {
    /** @var string Table name */
    private const TABLE = 'block_cdo_showcase';

    /**
     * Get all showcase settings
     *
     * @return array Array of showcase settings
     * @throws dml_exception
     */
    public static function get_all_settings($conditions = []): array {
        global $DB;
        return $DB->get_records(self::TABLE, $conditions, 'timecreated ASC');
    }

    /**
     * Get a single showcase setting by ID
     *
     * @param int $id Setting ID
     * @return stdClass|null Setting object or null if not found
     */
    public static function get_setting(int $id): ?stdClass {
        global $DB;
        return $DB->get_record(self::TABLE, ['id' => $id]);
    }

    /**
     * Create a new showcase setting
     *
     * @param stdClass $data Setting data
     * @return int New setting ID
     * @throws moodle_exception
     */
    public static function create_setting(stdClass $data): int {
        global $DB;

        $time = time();
        $data->timecreated = $time;
        $data->timemodified = $time;

        return $DB->insert_record(self::TABLE, $data);

    }

    /**
     * Update an existing showcase setting
     *
     * @param stdClass $data Setting data
     * @return bool True if successful
     * @throws moodle_exception
     */
    public static function update_setting(stdClass $data): bool {
        global $DB;

        if (empty($data->id)) {
            throw new moodle_exception('missing_id', 'block_cdo_showcase');
        }

        $data->timemodified = time();

        try {
            return $DB->update_record(self::TABLE, $data);
        } catch (\Exception $e) {
            throw new moodle_exception('error_updating_setting', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Delete a showcase setting
     *
     * @param int $id Setting ID
     * @return bool True if successful
     * @throws moodle_exception
     */
    public static function delete_setting(int $id): bool {
        global $DB;

        try {
            return $DB->delete_records(self::TABLE, ['id' => $id]);
        } catch (\Exception $e) {
            throw new moodle_exception('error_deleting_setting', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Check if current user has any token assignments
     * 
     * @param string|null $user_email User email (optional, uses current user if not provided)
     * @return bool True if user has token assignments, false otherwise
     */
    public static function user_has_token_assignments(?string $user_email = null): bool
    {
        global $DB, $USER;
        
        // Use current user's email if not provided
        if (empty($user_email)) {
            $user_email = $USER->email;
        }
        
        // Check if user has any course assignments
        return $DB->record_exists('block_cdo_showcase_user_courses', ['user_email' => $user_email]);
    }

    /**
     * Get count of tokens assigned to user
     * 
     * @param string|null $user_email User email (optional, uses current user if not provided)
     * @return int Number of tokens assigned to user
     */
    public static function get_user_tokens_count(?string $user_email = null): int
    {
        global $DB, $USER;
        
        // Use current user's email if not provided
        if (empty($user_email)) {
            $user_email = $USER->email;
        }
        
        $sql = "SELECT COUNT(DISTINCT config_id) 
                FROM {block_cdo_showcase_user_courses} 
                WHERE user_email = :user_email";
        
        return (int)$DB->count_records_sql($sql, ['user_email' => $user_email]);
    }

    /**
     * Get count of courses assigned to user across all tokens
     * 
     * @param string|null $user_email User email (optional, uses current user if not provided)
     * @return int Number of courses assigned to user
     */
    public static function get_user_courses_count(?string $user_email = null): int
    {
        global $DB, $USER;
        
        // Use current user's email if not provided
        if (empty($user_email)) {
            $user_email = $USER->email;
        }
        
        return $DB->count_records('block_cdo_showcase_user_courses', ['user_email' => $user_email]);
    }

    /**
     * Check if user is assigned to specific token
     * 
     * @param int $config_id Configuration/token ID
     * @param string|null $user_email User email (optional, uses current user if not provided)
     * @return bool True if user is assigned to this token, false otherwise
     */
    public static function user_assigned_to_token(int $config_id, ?string $user_email = null): bool
    {
        global $DB, $USER;
        
        // Use current user's email if not provided
        if (empty($user_email)) {
            $user_email = $USER->email;
        }
        
        return $DB->record_exists('block_cdo_showcase_user_courses', [
            'config_id' => $config_id,
            'user_email' => $user_email
        ]);
    }
} 