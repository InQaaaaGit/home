<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upgrade code for the CDO Showcase block.
 *
 * @package    block_cdo_showcase
 * @copyright  2024 Your Name <your@email.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

function xmldb_block_cdo_showcase_upgrade($oldversion): bool
{
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2024072504) {
        // Define field token_status to be added to block_cdo_showcase.
        $table = new xmldb_table('block_cdo_showcase');
        $field = new xmldb_field('token_status', XMLDB_TYPE_INTEGER, '1', null, false, null, '0', 'token');

        // Conditionally launch add field token_status.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // CDO Showcase savepoint reached.
        upgrade_block_savepoint(true, 2024072504, 'cdo_showcase');
    }

    if ($oldversion < 2024032000) {
        // Define table block_cdo_showcase_settings to be created.
        $table = new xmldb_table('block_cdo_showcase_settings');

        // Adding fields to table block_cdo_showcase_settings.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('name', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
        $table->add_field('url', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
        $table->add_field('port', XMLDB_TYPE_INTEGER, '5', null, null, null, '80');
        $table->add_field('token', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
        $table->add_field('token_status', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

        // Adding keys to table block_cdo_showcase_settings.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for block_cdo_showcase_settings.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Showcase savepoint reached.
        upgrade_block_savepoint(true, 2024032000, 'cdo_showcase');
    }

    if ($oldversion < 2024032001) {
        // Добавляем поле port, если его еще нет
        $table = new xmldb_table('block_cdo_showcase_settings');
        
        // Проверяем существование таблицы перед добавлением поля
        if ($dbman->table_exists($table)) {
            $field = new xmldb_field('port', XMLDB_TYPE_INTEGER, '5', null, null, null, '80', 'url');

            if (!$dbman->field_exists($table, $field)) {
                $dbman->add_field($table, $field);
            }
        }

        // Showcase savepoint reached.
        upgrade_block_savepoint(true, 2024032001, 'cdo_showcase');
    }

    if ($oldversion < 2024032002) {
        // Define table block_cdo_showcase_token_users to be created.
        $table = new xmldb_table('block_cdo_showcase_token_users');

        // Adding fields to table block_cdo_showcase_token_users.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('token_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('user_email', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

        // Adding keys to table block_cdo_showcase_token_users.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('token_id', XMLDB_KEY_FOREIGN, ['token_id'], 'block_cdo_showcase_settings', ['id']);

        // Adding indexes to table block_cdo_showcase_token_users.
        $table->add_index('user_email', XMLDB_INDEX_NOTUNIQUE, ['user_email']);
        $table->add_index('token_user_unique', XMLDB_INDEX_UNIQUE, ['token_id', 'user_email']);

        // Conditionally launch create table for block_cdo_showcase_token_users.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Showcase savepoint reached.
        upgrade_block_savepoint(true, 2024032002, 'cdo_showcase');
    }

    if ($oldversion < 2024120301) {
        // Define table block_cdo_showcase_user_courses to be created.
        $table = new xmldb_table('block_cdo_showcase_user_courses');

        // Adding fields to table block_cdo_showcase_user_courses.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('config_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('user_email', XMLDB_TYPE_CHAR, '100', null, XMLDB_NOTNULL, null, null);
        $table->add_field('course_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

        // Adding keys to table block_cdo_showcase_user_courses.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('config_fk', XMLDB_KEY_FOREIGN, ['config_id'], 'block_cdo_showcase', ['id']);

        // Adding indexes to table block_cdo_showcase_user_courses.
        $table->add_index('config_user', XMLDB_INDEX_NOTUNIQUE, ['config_id', 'user_email']);
        $table->add_index('user_email', XMLDB_INDEX_NOTUNIQUE, ['user_email']);
        $table->add_index('course_id', XMLDB_INDEX_NOTUNIQUE, ['course_id']);
        $table->add_index('timecreated', XMLDB_INDEX_NOTUNIQUE, ['timecreated']);

        // Conditionally launch create table for block_cdo_showcase_user_courses.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Showcase savepoint reached.
        upgrade_block_savepoint(true, 2024120301, 'cdo_showcase');
    }

    if ($oldversion < 2024120302) {
        // Set default SSL verification setting
        set_config('ssl_verification', 1, 'block_cdo_showcase');
        
        // CDO Showcase savepoint reached.
        upgrade_block_savepoint(true, 2024120302, 'cdo_showcase');
    }

    if ($oldversion < 2024120303) {
        // Set default block settings
        set_config('test_mode', 0, 'block_cdo_showcase'); // Test mode disabled by default
        set_config('test_email', 'test@example.com', 'block_cdo_showcase'); // Default test email
        set_config('test_isrop', 1, 'block_cdo_showcase'); // Test isROP enabled by default
        
        // CDO Showcase savepoint reached.
        upgrade_block_savepoint(true, 2024120303, 'cdo_showcase');
    }

    if ($oldversion < 2024120339) {
        // Добавляем поле category_id для хранения идентификатора категории на сайте-доноре
        $table = new xmldb_table('block_cdo_showcase');
        
        // Проверяем существование таблицы перед добавлением поля
        if ($dbman->table_exists($table)) {
            // Добавляем поле category_id
            $field = new xmldb_field('category_id', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'token');

            // Conditionally launch add field category_id.
            if (!$dbman->field_exists($table, $field)) {
                $dbman->add_field($table, $field);
            }

            // Добавляем уникальный индекс на поле token
            $index = new xmldb_index('token_unique', XMLDB_INDEX_UNIQUE, ['token']);
            if (!$dbman->index_exists($table, $index)) {
                $dbman->add_index($table, $index);
            }
        }

        // CDO Showcase savepoint reached.
        upgrade_block_savepoint(true, 2024120339, 'cdo_showcase');
    }

    return true;
} 