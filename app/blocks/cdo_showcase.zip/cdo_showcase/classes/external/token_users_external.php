<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace block_cdo_showcase\external;

defined('MOODLE_INTERNAL') || die();


use context_system;
use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use core_external\external_value;
use block_cdo_showcase\local\token_users_controller;
use moodle_exception;

/**
 * External API class for token users management
 *
 * @package    block_cdo_showcase
 * @category   external
 * @copyright  2024 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class token_users_external extends external_api
{
    /**
     * Returns description of get_token_users() parameters
     *
     * @return external_function_parameters
     */
    public static function get_token_users_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            'token_id' => new external_value(PARAM_INT, 'Token ID')
        ]);
    }

    /**
     * Get users assigned to a token
     *
     * @param int $token_id Token ID
     * @return array
     */
    public static function get_token_users(int $token_id): array
    {
        // Parameter validation
        $params = self::validate_parameters(self::get_token_users_parameters(), ['token_id' => $token_id]);

        // Context validation
        $context = context_system::instance();
        self::validate_context($context);

        // Capability checking
        require_capability('block/cdo_showcase:addinstance', $context);

        try {
            return array_values(token_users_controller::get_token_users($params['token_id']));
        } catch (\Exception $e) {
            throw new moodle_exception('error_getting_token_users', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Returns description of get_token_users() result value
     * @return external_multiple_structure
     */
    public static function get_token_users_returns(): external_multiple_structure
    {
        return new external_multiple_structure(
            new external_single_structure([
                'id' => new external_value(PARAM_INT, 'User ID'),
                'firstname' => new external_value(PARAM_TEXT, 'User first name'),
                'lastname' => new external_value(PARAM_TEXT, 'User last name'),
                'email' => new external_value(PARAM_EMAIL, 'User email')
            ])
        );
    }

    /**
     * Returns description of assign_users_to_token() parameters
     *
     * @return external_function_parameters
     */
    public static function assign_users_to_token_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            'token_id' => new external_value(PARAM_INT, 'Token ID'),
            'user_emails' => new external_multiple_structure(
                new external_value(PARAM_EMAIL, 'User email')
            )
        ]);
    }

    /**
     * Assign users to a token
     *
     * @param int $token_id Token ID
     * @param array $user_emails Array of user emails
     * @return array
     */
    public static function assign_users_to_token(int $token_id, array $user_emails): array
    {
        // Parameter validation
        $params = self::validate_parameters(self::assign_users_to_token_parameters(), [
            'token_id' => $token_id,
            'user_emails' => $user_emails
        ]);

        try {
            $success = token_users_controller::assign_users($params['token_id'], $params['user_emails']);
            return [
                'success' => $success,
                'message' => get_string('users_assigned', 'block_cdo_showcase')
            ];
        } catch (\Exception $e) {
            throw new moodle_exception('error_assigning_users', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Returns description of assign_users_to_token() result value
     *
     * @return external_single_structure
     */
    public static function assign_users_to_token_returns(): external_single_structure
    {
        return new external_single_structure([
            'success' => new external_value(PARAM_BOOL, 'Operation success'),
            'message' => new external_value(PARAM_TEXT, 'Result message')
        ]);
    }
} 