<?php

namespace block_cdo_showcase\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use core_external\external_value;
use moodle_exception;

class token_usage_external extends external_api
{
    /**
     * Returns description of get_user_token_usage() parameters
     *
     * @return external_function_parameters
     */
    public static function get_user_token_usage_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            'user_email' => new external_value(PARAM_EMAIL, 'User email', VALUE_OPTIONAL)
        ]);
    }

    /**
     * Get token usage information for a user (current user if email not provided)
     *
     * @param string|null $user_email User email (optional, uses current user if not provided)
     * @return array
     */
    public static function get_user_token_usage(?string $user_email = null): array
    {
        global $DB, $USER;

        // Parameter validation
        $params = self::validate_parameters(self::get_user_token_usage_parameters(), [
            'user_email' => $user_email
        ]);

        // Context validation
        $context = \context_system::instance();
        self::validate_context($context);

        // Use current user's email if not provided
        if (empty($params['user_email'])) {
            $params['user_email'] = $USER->email;
        }

        try {
            // Получаем информацию о токенах и назначенных курсах
            $sql = "SELECT DISTINCT 
                        uc.config_id,
                        bcs.name as token_name,
                        bcs.url as token_url,
                        COUNT(uc.course_id) as courses_count,
                        MIN(uc.timecreated) as first_assigned,
                        MAX(uc.timemodified) as last_modified
                    FROM {block_cdo_showcase_user_courses} uc
                    LEFT JOIN {block_cdo_showcase} bcs ON bcs.id = uc.config_id
                    WHERE uc.user_email = :user_email
                    GROUP BY uc.config_id, bcs.name, bcs.url
                    ORDER BY last_modified DESC";

            $token_records = $DB->get_records_sql($sql, [
                'user_email' => $params['user_email']
            ]);

            $tokens = [];
            $total_courses = 0;

            foreach ($token_records as $record) {
                // Получаем детальную информацию о курсах для этого токена
                $courses_sql = "SELECT uc.course_id, c.fullname, c.shortname, uc.timecreated
                               FROM {block_cdo_showcase_user_courses} uc
                               LEFT JOIN {course} c ON c.id = uc.course_id
                               WHERE uc.config_id = :config_id AND uc.user_email = :user_email
                               ORDER BY c.fullname";

                $courses = $DB->get_records_sql($courses_sql, [
                    'config_id' => $record->config_id,
                    'user_email' => $params['user_email']
                ]);

                $course_list = [];
                foreach ($courses as $course) {
                    $course_list[] = [
                        'id' => (int)$course->course_id,
                        'fullname' => $course->fullname ?? 'Неизвестный курс',
                        'shortname' => $course->shortname ?? '',
                        'timecreated' => (int)$course->timecreated
                    ];
                }

                $tokens[] = [
                    'config_id' => (int)$record->config_id,
                    'token_name' => $record->token_name ?? 'Неизвестный токен',
                    'token_url' => $record->token_url ?? '',
                    'courses_count' => (int)$record->courses_count,
                    'first_assigned' => (int)$record->first_assigned,
                    'last_modified' => (int)$record->last_modified,
                    'courses' => $course_list
                ];

                $total_courses += (int)$record->courses_count;
            }

            return [
                'user_email' => $params['user_email'],
                'has_assignments' => !empty($tokens),
                'tokens_count' => count($tokens),
                'total_courses' => $total_courses,
                'tokens' => $tokens
            ];

        } catch (\Exception $e) {
            throw new moodle_exception('error_getting_user_token_usage', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Returns description of get_user_token_usage() result value
     *
     * @return external_single_structure
     */
    public static function get_user_token_usage_returns(): external_single_structure
    {
        return new external_single_structure([
            'user_email' => new external_value(PARAM_EMAIL, 'User email'),
            'has_assignments' => new external_value(PARAM_BOOL, 'User has course assignments'),
            'tokens_count' => new external_value(PARAM_INT, 'Number of tokens with assignments'),
            'total_courses' => new external_value(PARAM_INT, 'Total number of assigned courses'),
            'tokens' => new external_multiple_structure(
                new external_single_structure([
                    'config_id' => new external_value(PARAM_INT, 'Configuration ID'),
                    'token_name' => new external_value(PARAM_TEXT, 'Token name'),
                    'token_url' => new external_value(PARAM_TEXT, 'Token URL'),
                    'courses_count' => new external_value(PARAM_INT, 'Number of courses for this token'),
                    'first_assigned' => new external_value(PARAM_INT, 'First assignment time'),
                    'last_modified' => new external_value(PARAM_INT, 'Last modification time'),
                    'courses' => new external_multiple_structure(
                        new external_single_structure([
                            'id' => new external_value(PARAM_INT, 'Course ID'),
                            'fullname' => new external_value(PARAM_TEXT, 'Course full name'),
                            'shortname' => new external_value(PARAM_TEXT, 'Course short name'),
                            'timecreated' => new external_value(PARAM_INT, 'Assignment time')
                        ])
                    )
                ])
            )
        ]);
    }
} 