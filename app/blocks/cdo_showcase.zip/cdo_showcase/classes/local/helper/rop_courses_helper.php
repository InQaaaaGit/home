<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace block_cdo_showcase\local\helper;

defined('MOODLE_INTERNAL') || die();

/**
 * Helper class for ROP courses functionality
 *
 * @package    block_cdo_showcase
 * @copyright  2024 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class rop_courses_helper
{
    /**
     * Get assigned courses for ROP user by email and config_id
     *
     * @param string $email User email
     * @param int|null $config_id Configuration ID (optional, if null returns all courses)
     * @return array
     * @throws \moodle_exception
     */
    public static function get_user_assigned_courses(string $email, ?int $config_id = null): array
    {
        global $DB;
        
        try {
            // Получаем закрепленные курсы пользователя с фильтрацией по config_id
            if ($config_id !== null) {
                $sql = "SELECT uc.*
                        FROM {block_cdo_showcase_user_courses} uc
                        WHERE uc.user_email = ? AND uc.config_id = ?
                        ORDER BY uc.course_id";
                        
                $assigned_courses = $DB->get_records_sql($sql, [$email, $config_id]);
            } else {
                // Для обратной совместимости, если config_id не передан
                $sql = "SELECT uc.*
                        FROM {block_cdo_showcase_user_courses} uc
                        WHERE uc.user_email = ?
                        ORDER BY uc.course_id";
                        
                $assigned_courses = $DB->get_records_sql($sql, [$email]);
            }
            
            $result = [];
            foreach ($assigned_courses as $course_assignment) {
                $result[] = [
                    'id' => $course_assignment->course_id,
                    'config_id' => $course_assignment->config_id,
                    'assigned_date' => $course_assignment->timecreated
                ];
            }
            
            return $result;
        } catch (\Exception $e) {
            throw new \moodle_exception('error_getting_rop_courses', 'block_cdo_showcase', '', null, $e->getMessage());
        }
    }

    /**
     * Check if user has any assigned courses
     *
     * @param string $email User email
     * @return bool
     */
    public static function user_has_assigned_courses(string $email): bool
    {
        global $DB;
        
        return $DB->record_exists('block_cdo_showcase_user_courses', ['user_email' => $email]);
    }

    /**
     * Get count of assigned courses for user
     *
     * @param string $email User email
     * @return int
     */
    public static function get_user_assigned_courses_count(string $email): int
    {
        global $DB;
        
        return $DB->count_records('block_cdo_showcase_user_courses', ['user_email' => $email]);
    }
} 