<script setup>
import {computed, ref} from 'vue';
import {useLangStore} from "../store/storeLang";
import {useGeneralStore} from '../store/storeGeneral';
import GradeTable from './GradeTable.vue';
import StudentReportExport from './StudentReportExport.vue';

const props = defineProps({
  course: {
    type: Object,
    required: true
  }
});

const langStore = useLangStore();
const generalStore = useGeneralStore();

const selectedStudent = ref(null);
const studentGrades = ref({
  grade1: 0,
  grade2: 0,
  grade3: 0,
  total_grade: 0
});
const courseID = computed(() => {
  return props.course.id;
})
// Группируем пользователей по ролям
const groupedUsers = computed(() => {
  if (!props.course?.enrolled_users) {
    return {
      teachers: [],
      students: []
    };
  }

  return props.course.enrolled_users.reduce((acc, user) => {
    const isTeacher = user.roles && user.roles.some(role => role.roleid === 3);
    const isStudent = user.roles && user.roles.some(role => role.roleid === 5);
    
    // Пользователь может быть и преподавателем, и студентом одновременно
    if (isTeacher) {
      acc.teachers.push(user);
    }
    if (isStudent) {
      acc.students.push(user);
    }
    
    return acc;
  }, {teachers: [], students: []});
});

// Проверяем, является ли это ROP курсом
const isROPCourse = computed(() => {
  return !props.course?.enrolled_users || props.course.enrolled_users.length === 0;
});

async function getStudentGrades(student) {
  try {
    selectedStudent.value = student;

    const grades = await generalStore.getStudentGrades(props.course.id, student.email);
    if (grades) {
      studentGrades.value = grades;
    }
  } catch (error) {
    // Error in getStudentGrades
  }
}

function closeGrades() {
  selectedStudent.value = null;
  studentGrades.value = {
    grade1: 0,
    grade2: 0,
    grade3: 0,
    total_grade: 0
  };
}
</script>

<template>
  <div class="enrolled-users-container">
    <div class="enrolled-users-section">
      <div class="row">
        <!-- Секция преподавателей -->
        <div class="col-md-6 mb-4">
          <div class="card h-100">
            <div class="card-header bg-primary text-white">
              <h5 class="mb-0">
                <i class="fa fa-chalkboard-teacher mr-2"></i>
                Преподаватели курса
              </h5>
            </div>
            <div class="card-body">
              <ul class="list-group list-group-flush">
                <li v-for="teacher in groupedUsers.teachers"
                    :key="teacher.id"
                    class="list-group-item d-flex align-items-center">
                  <i class="fa fa-user-circle mr-2 text-primary"></i>
                  <div class="ms-2">
                    <div class="fw-bold">{{ teacher.firstname }} {{ teacher.lastname }}</div>
                    <small class="text-muted">{{ teacher.email }}</small>
                  </div>
                </li>
                <li v-if="!groupedUsers.teachers.length" class="list-group-item text-muted">
                  Нет преподавателей
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- Секция студентов -->
        <div class="col-md-6 mb-4">
          <div class="card h-100">
            <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
              <h5 class="mb-0">
                <i class="fa fa-user-graduate mr-2"></i>
                Студенты курса
              </h5>
              <button v-if="selectedStudent"
                      @click="closeGrades"
                      class="btn btn-sm btn-light">
                <i class="fa fa-times"></i> Закрыть
              </button>
            </div>
            <div class="card-body">
              <!-- Список студентов -->
              <ul v-if="!selectedStudent" class="list-group list-group-flush">
                <li v-for="student in groupedUsers.students"
                    :key="student.id"
                    class="list-group-item d-flex align-items-center student-item">
                  <i class="fa fa-user mr-2 text-info"></i>
                  <div class="ms-2 flex-grow-1" @click="getStudentGrades(student)" style="cursor: pointer;">
                    <div class="fw-bold">{{ student.firstname }} {{ student.lastname }}</div>
                    <small class="text-muted">{{ student.email }}</small>
                  </div>
                  <div class="student-actions d-flex align-items-center">
                    <StudentReportExport 
                      :student-email="student.email"
                      :student-name="`${student.firstname} ${student.lastname}`"
                    />
                    <i class="fa fa-chevron-right text-muted ms-2" @click="getStudentGrades(student)" style="cursor: pointer;"></i>
                  </div>
                </li>
                <li v-if="!groupedUsers.students.length" class="list-group-item text-muted">
                  Нет студентов
                </li>
              </ul>

              <!-- Оценки выбранного студента -->
              <div v-else class="student-grades">
                <h6 class="mb-3">
                  Оценки студента: {{ selectedStudent.firstname }} {{ selectedStudent.lastname }}
                </h6>
                <GradeTable
                    :grade1="studentGrades.grade1"
                    :grade2="studentGrades.grade2"
                    :grade3="studentGrades.grade3"
                    :course-id="courseID"
                    :total-grade="studentGrades.total_grade"/>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<!--    <template v-if="isROPCourse">
      &lt;!&ndash; Специальное отображение для ROP курсов &ndash;&gt;
      <div class="rop-course-info">
        <div class="card">
          <div class="card-header bg-success text-white">
            <h5 class="mb-0">
              <i class="fa fa-user-check mr-2"></i>
              ROP Курс
            </h5>
          </div>
          <div class="card-body">
            <div class="alert alert-info mb-0">
              <i class="fa fa-info-circle mr-2"></i>
              Это курс, назначенный через систему ROP. Для получения подробной информации о студентах и оценках обратитесь к администратору системы.
            </div>
          </div>
        </div>
      </div>
    </template>
    <template v-else>
      &lt;!&ndash; Обычное отображение для курсов с данными о пользователях &ndash;&gt;

    </template>-->
  </div>
</template>

<style scoped>
.enrolled-users-container {
  width: 100%;
  min-height: 100%;
}

.rop-course-info {
  margin-top: 1rem;
}

.rop-course-info .card {
  max-width: 600px;
  margin: 0 auto;
}

.enrolled-users-section {
  margin-top: 1rem;
}

.card {
  border: none;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.card-header {
  border-bottom: none;
  padding: 0.75rem 1rem;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.card-header h5 {
  font-size: 1.1rem;
  margin: 0;
  line-height: 1.2;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: calc(100% - 80px); /* Оставляем место для кнопки "Закрыть" */
}

.list-group-item {
  border: none;
  padding: 0.75rem 1rem;
  transition: background-color 0.2s;
}

.list-group-item:hover {
  background-color: #f8f9fa;
}

.list-group-item:not(:last-child) {
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
}

.fa {
  width: 1.25rem;
  text-align: center;
}

.text-muted {
  font-size: 0.875rem;
}

.fw-bold {
  font-weight: 600;
}

.student-item {
  cursor: pointer;
}

.student-item:hover {
  background-color: #f8f9fa;
  cursor: pointer;
}

.student-actions {
  flex-shrink: 0;
}

.student-actions .btn {
  font-size: 0.75rem;
  padding: 0.25rem 0.5rem;
}

/* Адаптивность для мобильных устройств */
@media (max-width: 768px) {
  .student-actions {
    flex-direction: column;
    gap: 0.25rem;
  }
  
  .student-actions .btn {
    font-size: 0.7rem;
    padding: 0.2rem 0.4rem;
  }
}

.student-grades {
  padding: 1rem;
  background-color: #f8f9fa;
  border-radius: 0.25rem;
}

.btn-light {
  padding: 0.25rem 0.5rem;
  font-size: 0.875rem;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 80px;
}

.btn-light:hover {
  background-color: #e9ecef;
}
</style> 