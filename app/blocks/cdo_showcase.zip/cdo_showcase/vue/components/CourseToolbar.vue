<script setup>
import { ref, computed, onMounted } from 'vue';
import { useLangStore } from '../store/storeLang';

const props = defineProps({
  course: {
    type: Object,
    required: true
  },
  configName: {
    type: String,
    default: ''
  },
  isTeacher: {
    type: Boolean,
    default: false
  }
});

const langStore = useLangStore();
const showGradeScale = ref(false);

// Извлекаем шкалу оценивания из данных курса
const gradeScale = computed(() => {
  if (props.course?.scale?.gradescales) {
    return props.course.scale.gradescales;
  }
  return [];
});

// Проверяем наличие шкалы оценивания
const hasGradeScale = computed(() => {
  return gradeScale.value.length > 0;
});

// Открыть модальное окно шкалы оценивания
const openGradeScaleModal = () => {
  showGradeScale.value = true;
};

// Закрыть модальное окно шкалы оценивания
const closeGradeScaleModal = () => {
  showGradeScale.value = false;
};

// Получить цвет для оценки в зависимости от диапазона
const getGradeColor = (gradename) => {
  const name = gradename.toLowerCase();
  if (name.includes('отлично') || name.includes('excellent') || name.includes('5')) {
    return '#28a745'; // зеленый
  } else if (name.includes('хорошо') || name.includes('good') || name.includes('4')) {
    return '#17a2b8'; // голубой
  } else if (name.includes('удовлетворительно') || name.includes('satisfactory') || name.includes('3')) {
    return '#ffc107'; // желтый
  } else if (name.includes('неудовлетворительно') || name.includes('unsatisfactory') || name.includes('2')) {
    return '#dc3545'; // красный
  }
  return '#6c757d'; // серый по умолчанию
};
</script>

<template>
  <div class="course-toolbar">
    <!-- Баджик названия токена -->
    <div v-if="configName" class="token-badge">
      <i class="fa fa-key mr-1"></i>
      <span>{{ configName }}</span>
    </div>

    <!-- Кнопка шкалы оценивания -->
    <button 
      v-if="hasGradeScale"
      @click="openGradeScaleModal"
      class="btn btn-outline-primary btn-sm grade-scale-btn"
      :title="langStore.strings.toolbar_gradescale_tooltip || 'Показать шкалу оценивания'"
    >
      <i class="fa fa-ruler mr-1"></i>
      {{ langStore.strings.toolbar_gradescale_button || 'Шкала' }}
    </button>

    <!-- Кнопка скачивания отчета преподавателя -->
    <button
        v-if="isTeacher"
        @click="$emit('export-teacher-report')"
        class="btn btn-outline-success btn-sm teacher-report-btn"
        :title="langStore.strings.teacher_report_tooltip || 'Скачать отчет преподавателя'"
    >
      <i class="fa fa-file-excel-o mr-1"></i>
      {{ langStore.strings.teacher_report_button || 'Скачать отчет' }}
    </button>

    <!-- Модальное окно шкалы оценивания -->
    <div 
      v-if="showGradeScale" 
      class="modal fade show d-block" 
      tabindex="-1"
      @click.self="closeGradeScaleModal"
    >
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">
              <i class="fa fa-ruler mr-2"></i>
              {{ langStore.strings.toolbar_gradescale_title || 'Шкала оценивания' }}
            </h5>
            <button 
              type="button" 
              class="btn-close"
              @click="closeGradeScaleModal"
              :aria-label="langStore.strings.close || 'Закрыть'"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div v-if="gradeScale.length > 0" class="grade-scale-container">
              <div 
                v-for="(grade, index) in gradeScale" 
                :key="index"
                class="grade-item"
                :style="{ borderLeftColor: getGradeColor(grade.gradename) }"
              >
                <div class="grade-name">
                  <strong>{{ grade.gradename }}</strong>
                </div>
                <div class="grade-range">
                  <span class="range-text">
                    {{ grade.minimum }} - {{ grade.maximum }}
                  </span>
                  <span v-if="grade.gradevalue" class="grade-value">
                    ({{ grade.gradevalue }})
                  </span>
                </div>
              </div>
            </div>
            <div v-else class="alert alert-warning">
              <i class="fa fa-exclamation-triangle mr-2"></i>
              {{ langStore.strings.toolbar_gradescale_error || 'Шкала оценивания недоступна. Возможно, произошла ошибка при загрузке данных.' }}
            </div>
          </div>
          <div class="modal-footer">
            <button 
              type="button" 
              class="btn btn-secondary"
              @click="closeGradeScaleModal"
            >
              {{ langStore.strings.close || 'Закрыть' }}
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Backdrop для модального окна -->
    <div 
      v-if="showGradeScale" 
      class="modal-backdrop fade show"
    ></div>
  </div>
</template>

<style scoped>
.course-toolbar {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  flex-wrap: wrap;
  margin-bottom: 1rem;
}

/* Стили баджика токена */
.token-badge {
  display: inline-flex;
  align-items: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 500;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.15);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 200px;
}

.token-badge i {
  font-size: 0.75rem;
  margin-right: 4px;
}

/* Стили кнопки шкалы оценивания */
.grade-scale-btn {
  border-radius: 20px;
  font-size: 0.8rem;
  padding: 6px 12px;
  font-weight: 500;
  transition: all 0.2s ease;
  border: 1.5px solid #007bff;
}

.grade-scale-btn:hover {
  background-color: #007bff;
  color: white;
  transform: translateY(-1px);
  box-shadow: 0 3px 6px rgba(0, 123, 255, 0.25);
}

.teacher-report-btn {
    border-radius: 20px;
    font-size: 0.8rem;
    padding: 6px 12px;
    font-weight: 500;
    transition: all 0.2s ease;
    border: 1.5px solid #28a745;
}

.teacher-report-btn:hover {
    background-color: #28a745;
    color: white;
    transform: translateY(-1px);
    box-shadow: 0 3px 6px rgba(40, 167, 69, 0.25);
}

.grade-scale-btn i {
  font-size: 0.75rem;
}

/* Стили модального окна */
.modal {
  z-index: 1055;
}

.modal-backdrop {
  z-index: 1050;
}

.modal-content {
  border-radius: 0.5rem;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
}

.modal-header {
  border-bottom: 1px solid #e9ecef;
  background-color: #f8f9fa;
}

.modal-title {
  color: #495057;
  font-weight: 600;
}

.btn-close {
  background: none;
  border: none;
  font-size: 1.25rem;
  color: #6c757d;
  cursor: pointer;
  padding: 0.5rem;
}

.btn-close:hover {
  color: #000;
}

/* Стили контейнера шкалы */
.grade-scale-container {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.grade-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  background-color: #f8f9fa;
  border-radius: 0.375rem;
  border-left: 4px solid #6c757d;
  transition: all 0.2s ease;
}

.grade-item:hover {
  background-color: #e9ecef;
  transform: translateX(2px);
}

.grade-name {
  font-size: 1rem;
  color: #495057;
}

.grade-range {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  text-align: right;
}

.range-text {
  font-size: 0.9rem;
  color: #6c757d;
  font-weight: 500;
}

.grade-value {
  font-size: 0.8rem;
  color: #007bff;
  font-weight: 600;
  margin-top: 0.25rem;
}

/* Адаптивность */
@media (max-width: 768px) {
  .course-toolbar {
    flex-direction: column;
    align-items: stretch;
    gap: 0.5rem;
  }
  
  .token-badge {
    max-width: 100%;
    justify-content: center;
  }
  
  .grade-scale-btn {
    width: 100%;
    justify-content: center;
  }
  
  .modal-dialog {
    margin: 0.5rem;
  }
  
  .grade-item {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.5rem;
  }
  
  .grade-range {
    align-items: flex-start;
    text-align: left;
  }
}

/* Анимации */
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: scale(0.9);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

.modal.show .modal-content {
  animation: fadeIn 0.15s ease-out;
}
</style> 