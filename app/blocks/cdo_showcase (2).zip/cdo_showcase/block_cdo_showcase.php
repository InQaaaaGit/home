<?php

use block_cdo_showcase\local\controller;

defined('MOODLE_INTERNAL') || die();

class block_cdo_showcase extends block_base {

    const plugin_name = 'block_cdo_showcase';

    public function has_config(): bool
    {
        return true;
    }

    /**
     * @throws coding_exception
     */
    public function init(): void
    {
        $this->title = get_string('pluginname', self::plugin_name);
    }

    public function get_content(): ?stdClass
    {
        global $PAGE, $USER, $CFG;
        if ($this->content !== null) {
            return $this->content;
        }

        // Получаем настройки блока
        $test_mode = get_config('block_cdo_showcase', 'test_mode');
        
        // Определяем email в зависимости от режима
        if ($test_mode) {
            // Тестовый режим - используем настройку
            $email = get_config('block_cdo_showcase', 'test_email');
        } else {
            // Продакшн режим - используем реальный email пользователя
            $email = $USER->email;
        }
        
        // Определяем isROP в зависимости от режима
        if ($test_mode) {
            // Тестовый режим - используем настройку
            $isrop = (bool)get_config('block_cdo_showcase', 'test_isrop');
        } else {
            // Продакшн режим - используем реальное значение
            $isrop = controller::user_has_token_assignments();
        }
        // Получаем настройку категории отбора курсов
        $api_request_param = get_config('block_cdo_showcase', 'api_request_param');
        
        $amd_build = $CFG->cachejs ? self::plugin_name."/showcase-prod-app-lazy" : self::plugin_name."/showcase-dev-app-lazy";
        $PAGE->requires->js_call_amd(
            $amd_build,
            'init',
            [
                'email' => $email,
                'isROP' => $isrop,
                'apiRequestParam' => $api_request_param,
            ]
        );
        $this->content = new stdClass;
        $this->content->text = '
        <div id="main_app">
            <div class="spinner-border text-primary" role="status">
              <span class="sr-only"></span>
            </div>
            <app></app>
        </div>';
        //$this->content->footer = 'Подвал блока.';

        return $this->content;
    }

    // Необязательные методы:
    // public function specialization()
    // public function instance_allow_multiple()
    // public function applicable_formats()
    // public function html_attributes()
    // public function hide_header()
    // public function get_aria_role()
} 