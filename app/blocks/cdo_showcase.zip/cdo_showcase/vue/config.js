import * as moodleAjax from "core/ajax";

class Settings {
    constructor(token = '', url = '') {
        this.token = token;
        this.url = url;
    }

    /**
     * Устанавливает токен
     * @param {string} token - Токен для авторизации
     */
    setToken(token) {
        this.token = token;
    }

    /**
     * Устанавливает URL
     * @param {string} url - Базовый URL
     */
    setUrl(url) {
        this.url = url;
    }

    /**
     * Получает текущий токен
     * @returns {string} Текущий токен
     */
    getToken() {
        return this.token;
    }

    /**
     * Получает текущий URL
     * @returns {string} Текущий URL
     */
    getUrl() {
        return this.url;
    }

    /**
     * Получает массив экземпляров Settings с разными параметрами
     * @returns {Promise<Array<Settings>>} Массив экземпляров Settings
     */

}
const fetchConfigs = async () => {
    try {

        const request = {
            methodname: 'block_cdo_showcase_get_settings',
            args: {
            },
        };
        const tokens = await moodleAjax.call([request])[0];
        let configs = [];
        tokens.forEach(tokenConfig => {
            configs.push(new Settings(tokenConfig.token, tokenConfig.url));
        });
        return configs;
    } catch (error) {
        console.error('Ошибка при получении конфигураций:', error);
        throw error;
    }
}
// Экспортируем класс Settings
export { Settings, fetchConfigs };