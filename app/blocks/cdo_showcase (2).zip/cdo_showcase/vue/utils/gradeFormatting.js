/**
 * Утилиты для форматирования оценок с процентами
 */

/**
 * Получает максимальную оценку из шкалы курса
 * @param {Object} courseScale - Шкала курса
 * @returns {number} Максимальная оценка
 */
export function getMaxGradeFromScale(courseScale) {
  if (!courseScale || !courseScale.gradescales || !Array.isArray(courseScale.gradescales)) {
    return 100; // По умолчанию максимальная оценка 100
  }
  
  // Находим максимальное значение из всех диапазонов шкалы
  let maxGrade = 0;
  courseScale.gradescales.forEach(grade => {
    if (grade.maximum && grade.maximum > maxGrade) {
      maxGrade = grade.maximum;
    }
  });
  
  return maxGrade > 0 ? maxGrade : 100;
}

/**
 * Форматирует оценку с процентом вклада в курс на основе весового коэффициента Moodle
 * @param {number|string|null|undefined} grade - Оценка
 * @param {Object} gradeItem - Объект элемента оценки с весом и максимальной оценкой
 * @param {number} totalWeight - Общий вес всех элементов курса
 * @returns {string} Отформатированная оценка с процентом вклада
 */
export function formatGradeWithContribution(grade, gradeItem = null, totalWeight = null) {
  if (grade === null || grade === undefined) {
    return '-';
  }
  
  const numGrade = parseFloat(grade);
  if (isNaN(numGrade)) {
    return grade.toString();
  }
  
  // Если есть данные об элементе оценки и общем весе, вычисляем процент вклада
  if (gradeItem && gradeItem.weight !== null && gradeItem.weight !== undefined && totalWeight && totalWeight > 0) {
    const contributionPercentage = Math.round((gradeItem.weight / totalWeight) * 100);
    const formattedGrade = numGrade.toFixed(2);
    return `${formattedGrade} (${contributionPercentage}%)`;
  }
  
  // Если нет данных о весе, используем старую логику (процент от максимальной оценки)
  return formatGradeWithPercentage(grade, null, 100);
}

/**
 * Форматирует оценку с процентом от максимальной
 * @param {number|string|null|undefined} grade - Оценка
 * @param {Object} courseScale - Шкала курса (опционально)
 * @param {number} maxGrade - Максимальная оценка (опционально)
 * @returns {string} Отформатированная оценка с процентом
 */
export function formatGradeWithPercentage(grade, courseScale = null, maxGrade = null) {
  if (grade === null || grade === undefined) {
    return '-';
  }
  
  const numGrade = parseFloat(grade);
  if (isNaN(numGrade)) {
    return grade.toString();
  }
  
  // Определяем максимальную оценку
  let maxValue = maxGrade;
  if (!maxValue && courseScale) {
    maxValue = getMaxGradeFromScale(courseScale);
  }
  if (!maxValue) {
    maxValue = 100; // По умолчанию
  }
  
  // Вычисляем процент
  const percentage = Math.round((numGrade / maxValue) * 100);
  
  // Форматируем оценку
  const formattedGrade = numGrade.toFixed(2);
  
  return `${formattedGrade} (${percentage}%)`;
}

/**
 * Форматирует оценку без процента (для случаев, когда процент не нужен)
 * @param {number|string|null|undefined} grade - Оценка
 * @returns {string} Отформатированная оценка
 */
export function formatGrade(grade) {
  if (grade === null || grade === undefined) {
    return '-';
  }
  
  const numGrade = parseFloat(grade);
  if (isNaN(numGrade)) {
    return grade.toString();
  }
  
  return numGrade.toFixed(2);
}

/**
 * Получает CSS класс для оценки в зависимости от её значения
 * @param {number|string|null|undefined} grade - Оценка
 * @param {number} maxGrade - Максимальная оценка
 * @returns {string} CSS класс
 */
export function getGradeClass(grade, maxGrade = 100) {
  if (grade === null || grade === undefined) {
    return 'grade-empty';
  }
  
  const numGrade = parseFloat(grade);
  if (isNaN(numGrade)) {
    return 'grade-empty';
  }
  
  const percentage = (numGrade / maxGrade) * 100;
  
  if (percentage >= 80) return 'grade-excellent';
  if (percentage >= 60) return 'grade-good';
  if (percentage >= 40) return 'grade-satisfactory';
  return 'grade-poor';
}

/**
 * Получает CSS класс для итоговой оценки
 * @param {number|string|null|undefined} grade - Оценка
 * @param {number} maxGrade - Максимальная оценка
 * @returns {string} CSS класс
 */
export function getTotalGradeClass(grade, maxGrade = 100) {
  if (grade === null || grade === undefined) {
    return 'total-grade-empty';
  }
  
  const numGrade = parseFloat(grade);
  if (isNaN(numGrade)) {
    return 'total-grade-empty';
  }
  
  const percentage = (numGrade / maxGrade) * 100;
  
  if (percentage >= 80) return 'total-grade-excellent';
  if (percentage >= 60) return 'total-grade-good';
  if (percentage >= 40) return 'total-grade-satisfactory';
  return 'total-grade-poor';
}
