<?php

namespace block_cdo_showcase\local\api;

use block_cdo_showcase\local\controller;
use context_system;
use core\exception\moodle_exception;
use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use core_external\external_value;
use curl;
require_once $CFG->libdir . '/filelib.php';
class config_usages extends external_api
{
    public static function check_token_parameters(): external_single_structure
    {
        return new external_single_structure(
            array(
                'url' => new external_value(PARAM_URL, 'External API URL'),
                'token' => new external_value(PARAM_TEXT, 'External API token')
            )
        );
    }

    /**
     * Returns description of check_token() result value

     */
    public static function check_token_returns(): external_single_structure
    {
        return new external_single_structure(
            array(
                'success' => new external_value(PARAM_BOOL, 'Token validation result'),
                'message' => new external_value(PARAM_TEXT, 'Result message')
            )
        );
    }
    /**
     * Check token validity
     * @param string $url External API URL
     * @param string $token External API token
     * @return array
     * @throws moodle_exception
     */
    public static function check_token($url, $token): array
    {
        // Parameter validation
        $params = self::validate_parameters(self::check_token_parameters(),
            array('url' => $url, 'token' => $token));

        // Context validation
        $context = \context_system::instance();
        self::validate_context($context);

        // Capability checking
        //require_capability('block/cdo_showcase:addinstance', $context);

        return array(
            'success' => true,
            'message' => get_string('token_valid', 'block_cdo_showcase')
        );
    }

    /**
     * Returns description of get_user_courses_by_config() parameters
     * @return external_function_parameters
     */
    public static function get_user_courses_by_config_parameters(): external_function_parameters
    {
        return new external_function_parameters(
            array(
                'configid' => new external_value(PARAM_INT, 'Configuration ID'),
                'email' => new external_value(PARAM_EMAIL, 'User email')
            )
        );
    }

    /**
     * Returns description of get_user_courses_by_config() result value
     * @return external_multiple_structure
     */
    public static function get_user_courses_by_config_returns(): external_multiple_structure
    {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id' => new external_value(PARAM_INT, 'Course ID'),
                    'fullname' => new external_value(PARAM_TEXT, 'Course full name'),
                    'shortname' => new external_value(PARAM_TEXT, 'Course short name'),
                    'enrolled_users' => new external_multiple_structure(
                        new external_single_structure(
                            array(
                                'id' => new external_value(PARAM_INT, 'User ID'),
                                'email' => new external_value(PARAM_EMAIL, 'User email'),
                                'roles' => new external_multiple_structure(
                                    new external_single_structure(
                                        array(
                                            'roleid' => new external_value(PARAM_INT, 'Role ID'),
                                            'name' => new external_value(PARAM_TEXT, 'Role name')
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
        );
    }

    /**
     * Get user courses by configuration ID
     * @param int $configid Configuration ID
     * @param string $email User email
     * @return array
     * @throws moodle_exception
     */
    public static function get_user_courses_by_config(int $configid, string $email): array
    {
        // Parameter validation
        $params = self::validate_parameters(self::get_user_courses_by_config_parameters(),
            array('configid' => $configid, 'email' => $email));

        // Context validation
        $context = context_system::instance();
        self::validate_context($context);

        // Get configuration
        $config = controller::get_setting($params['configid']);
        if (!$config->token_status) {
            throw new moodle_exception('invalidtoken', 'block_cdo_showcase');
        }

        try {
            // Формируем URL для внешнего API
            $api_url = 'https://eios.cdo-global.ru/webservice/rest/server.php?' . http_build_query([
                'wstoken' => $config->token,
                'wsfunction' => 'block_cdo_showcase_get_users_courses',
                'moodlewsrestformat' => 'json',
                'email' => $params['email']
            ]);

            // Для отладки
            debugging('Using API URL: ' . $api_url, DEBUG_DEVELOPER);

            // Инициализируем curl
            $curl = curl_init();

            // Устанавливаем опции
            curl_setopt_array($curl, array(
                CURLOPT_URL => $api_url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2
            ));

            // Выполняем запрос
            $response = curl_exec($curl);
            $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            $errno = curl_errno($curl);
            $error = curl_error($curl);

            // Для отладки
            debugging('CURL Debug Info: URL=' . $api_url . ', Error=' . $error . ', Errno=' . $errno . ', HTTP Code=' . $httpcode, DEBUG_DEVELOPER);

            // Закрываем соединение
            curl_close($curl);

            // Проверяем HTTP ошибки
            if ($httpcode >= 400) {
                $errormsg = '';
                switch ($httpcode) {
                    case 400:
                        $errormsg = get_string('error_400', 'block_cdo_showcase');
                        break;
                    case 401:
                        $errormsg = get_string('error_401', 'block_cdo_showcase');
                        break;
                    case 403:
                        $errormsg = get_string('error_403', 'block_cdo_showcase');
                        break;
                    case 404:
                        $errormsg = get_string('error_404', 'block_cdo_showcase');
                        break;
                    case 500:
                        $errormsg = get_string('error_500', 'block_cdo_showcase');
                        break;
                    default:
                        $errormsg = get_string('error_http', 'block_cdo_showcase', $httpcode);
                }
                throw new moodle_exception('externalapierror', 'block_cdo_showcase', '', $errormsg);
            }

            // Проверяем ошибки curl
            if ($errno) {
                $errormsg = '';
                switch ($errno) {
                    case CURLE_COULDNT_CONNECT:
                        $errormsg = get_string('error_connection', 'block_cdo_showcase');
                        break;
                    case CURLE_OPERATION_TIMEOUTED:
                        $errormsg = get_string('error_timeout', 'block_cdo_showcase');
                        break;
                    case CURLE_SSL_CONNECT_ERROR:
                        $errormsg = get_string('error_ssl', 'block_cdo_showcase');
                        break;
                    default:
                        $errormsg = get_string('error_curl', 'block_cdo_showcase', $error);
                }
                throw new moodle_exception('externalapierror', 'block_cdo_showcase', '', $errormsg);
            }

            // Пробуем декодировать JSON
            $result = json_decode($response, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new moodle_exception('invalidjsonresponse', 'block_cdo_showcase');
            }

            // Проверяем ошибки API в ответе
            if (isset($result['errorcode'])) {
                throw new moodle_exception($result['errorcode'], 'block_cdo_showcase', '', $result['message']);
            }

            // Проверяем структуру ответа
            if (!is_array($result)) {
                throw new moodle_exception('invalidresponse', 'block_cdo_showcase');
            }

            // Проверяем обязательные поля
            foreach ($result as $course) {
                if (!isset($course['id']) || !isset($course['fullname']) || !isset($course['shortname'])) {
                    throw new moodle_exception('invalidresponse', 'block_cdo_showcase');
                }
            }

            return $result;

        } catch (moodle_exception $e) {
            // Логируем ошибку
            debugging('External API error: ' . $e->getMessage(), DEBUG_DEVELOPER);
            throw $e;
        } catch (\Exception $e) {
            // Логируем неожиданные ошибки
            debugging('Unexpected error in get_user_courses_by_config: ' . $e->getMessage(), DEBUG_DEVELOPER);
            throw new moodle_exception('externalapierror', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Make a request to external API
     *
     * @param string $url External API URL
     * @param string $token External API token
     * @param string $wsfunction Web service function name
     * @param array $params Additional parameters
     * @return mixed
     * @throws \moodle_exception
     */
    private function make_request($url, $token, $wsfunction, $params = array()) {
        $curl = new \curl();
        
        // Prepare request parameters
        $requestparams = array_merge(array(
            'wstoken' => $token,
            'wsfunction' => $wsfunction,
            'moodlewsrestformat' => 'json'
        ), $params);

        // Формируем URL с учетом порта
        $parsed_url = parse_url($url);
        $base_url = $parsed_url['scheme'] . '://' . $parsed_url['host'];
        if (isset($parsed_url['port'])) {
            $base_url .= ':' . $parsed_url['port'];
        }
        if (isset($parsed_url['path'])) {
            $base_url .= $parsed_url['path'];
        }
        $api_url = $base_url . '/webservice/rest/server.php';

        // Make request
        $response = $curl->post($api_url, $requestparams);
        
        if ($curl->get_errno()) {
            throw new \moodle_exception('externalapierror', 'block_cdo_showcase', '', $curl->error);
        }

        // Decode response
        $result = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \moodle_exception('invalidjsonresponse', 'block_cdo_showcase');
        }

        // Check for API errors
        if (isset($result['errorcode'])) {
            throw new \moodle_exception($result['errorcode'], 'block_cdo_showcase', '', $result['message']);
        }

        return $result;
    }
}