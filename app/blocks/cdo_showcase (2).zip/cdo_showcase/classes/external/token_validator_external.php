<?php

namespace block_cdo_showcase\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;

class token_validator_external extends external_api
{
    public static function check_token_parameters(): external_single_structure
    {
        return new external_single_structure(
            array(
                'url' => new external_value(PARAM_URL, 'External API URL'),
                'token' => new external_value(PARAM_TEXT, 'External API token')
            )
        );
    }

    /**
     * Returns description of check_token() result value
     */
    public static function check_token_returns(): external_single_structure
    {
        return new external_single_structure(
            array(
                'success' => new external_value(PARAM_BOOL, 'Token validation result'),
                'message' => new external_value(PARAM_TEXT, 'Result message')
            )
        );
    }

    /**
     * Check token validity
     * @param string $url External API URL
     * @param string $token External API token
     * @return array
     */
    public static function check_token($url, $token): array
    {
        // Parameter validation
        $params = self::validate_parameters(self::check_token_parameters(),
            array('url' => $url, 'token' => $token));

        // Context validation
        $context = \context_system::instance();
        self::validate_context($context);

        return array(
            'success' => true,
            'message' => get_string('token_valid', 'block_cdo_showcase')
        );
    }
} 