<?php

defined('MOODLE_INTERNAL') || die();


function local_cdo_academic_progress_get_fontawesome_icon_map(): array
{
    return [
        'local_cdo_academic_progress:i/table' => 'fa-file-spreadsheet'
    ];
}