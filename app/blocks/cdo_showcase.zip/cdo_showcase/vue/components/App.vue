<script setup>
import { useRoute } from 'vue-router';
import { useGeneralStore } from '../store/storeGeneral';

const route = useRoute();
const generalStore = useGeneralStore();

// Функция для перезагрузки всего приложения
const reloadApp = () => {
  window.location.reload();
};
</script>

<template>
  <div class="app-container">
    <router-view v-slot="{ Component }" :key="generalStore.appKey">
      <transition :name="route.meta.transition || 'fade'" mode="out-in">
        <component :is="Component" />
      </transition>
    </router-view>
  </div>
</template>

<style>
.app-container {
  width: 100%;
  position: relative;
}

/* Анимация появления/исчезновения */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

/* Анимация слайда */
.slide-enter-active,
.slide-leave-active {
  transition: transform 0.3s ease;
}

.slide-enter-from {
  transform: translateX(100%);
}

.slide-leave-to {
  transform: translateX(-100%);
}
</style> 