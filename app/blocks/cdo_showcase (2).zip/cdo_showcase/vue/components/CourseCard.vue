<script setup>
import { useLangStore } from "../store/storeLang";
import { computed } from 'vue';
import {useGeneralStore} from "../store/storeGeneral";

const props = defineProps({
  course: {
    type: Object,
    required: true
  },
  showDetails: {
    type: Boolean,
    default: false
  }
});

const langStore = useLangStore();
const generalStore = useGeneralStore();
// Используем isTeacher из course объекта
const isTeacher = computed(() => props.course.isTeacher || false);

// Получаем количество студентов на курсе
const studentCount = computed(() => {
  if (!props.course?.course?.enrolled_users) return 0;
  
  return props.course.course.enrolled_users.filter(user => 
    user.roles && 
    user.roles.some(role => role.roleid === 5) // roleid 5 - студент
  ).length;
});

// Вычисляемое свойство для получения списка преподавателей (используется только если пользователь не преподаватель)
const courseTeachers = computed(() => {
  if (isTeacher.value || !props.course?.course?.enrolled_users) {
    return [];
  }
  
  const teachers = props.course.course.enrolled_users.filter(user => 
    user.roles && user.roles.some(role => role.roleid === 3)
  );
  
  return teachers.slice(0, 2);
});

// Вычисляем количество оставшихся преподавателей (используется только если пользователь не преподаватель)
const remainingTeachers = computed(() => {
  if (isTeacher.value || !props.course?.course?.enrolled_users) return 0;
  
  const allTeachers = props.course.course.enrolled_users.filter(user => 
    user.roles && user.roles.some(role => role.roleid === 3)
  );
  return Math.max(0, allTeachers.length - 2);
});
</script>

<template>
  <div class="card h-100 shadow-sm" :class="{ 'detail-card': showDetails }" v-if="course.hasOwnProperty('course')">
    <!-- Бейдж с названием конфига -->
<!--    <div v-if="course.config && course.config.name" class="config-badge">
      <i class="fa fa-tag mr-1"></i>{{ course.config.name }}
    </div>-->
    
    <div class="card-body d-flex flex-column">
      <div class="course-title-wrapper">
        <h5 v-if="!showDetails"
            class="card-title"
            :title="course.course.fullname">
          {{ course.course.fullname }}
        </h5>
      </div>

      <!-- Отображение для преподавателя -->
      <template v-if="isTeacher || generalStore.isROP">
        <div class="students-section mt-auto">
          <h6 class="text-muted mb-2">
            <i class="fa fa-graduation-cap mr-2"></i>{{ langStore.strings.coursecard_students_count || 'Студенты:' }}
          </h6>
          <div class="students-count">
            <span class="count-number">{{ studentCount }}</span>
            <span class="count-label">{{ langStore.strings.coursecard_students || 'студентов' }}</span>
          </div>
        </div>
      </template>

      <!-- Отображение для обычного пользователя -->
      <template v-else-if="courseTeachers.length">
        <div class="teachers-section mt-auto">
          <h6 class="text-muted mb-2">
            <i class="fa fa-users mr-2"></i>{{ langStore.strings.coursecard_teacherssectiontitle || 'Преподаватели:' }}
          </h6>
          <ul class="list-group list-group-flush">
            <li v-for="teacher in courseTeachers"
                :key="teacher.id"
                class="list-group-item d-flex align-items-center py-2">
              <i class="fa fa-user-circle mr-2 text-primary"></i>
              <span>{{teacher.firstname}} {{teacher.lastname}}</span>
            </li>
            <li v-if="remainingTeachers > 0" class="list-group-item text-muted py-2">
              <i class="fa fa-ellipsis-h mr-2"></i>
              +{{ remainingTeachers }} {{ langStore.strings.coursecard_more_teachers || 'еще' }}
            </li>
          </ul>
        </div>
      </template>
    </div>
  </div>
</template>

<style scoped>
.card {
  width: 100%;
  margin-bottom: 1rem;
  border: none;
  transition: transform 0.2s ease-in-out;
  position: relative;
}

.card:not(.detail-card):hover {
  transform: translateY(-5px);
}

.course-title-wrapper {
  position: relative;
  min-height: 2.8em;
  margin-bottom: 0.75rem;
  padding-bottom: 0.25rem;
}

.card-title {
  margin: 0;
  font-size: 1.1rem;
  font-weight: 600;
  line-height: 1.4;
  color: #2c3e50;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  position: relative;
  padding-right: 1rem;
}

.card-title::after {
  content: '';
  position: absolute;
  right: 0;
  bottom: 0;
  width: 2.5rem;
  height: 1.4em;
  background: linear-gradient(to right, rgba(255, 255, 255, 0), #fff 80%);
  pointer-events: none;
}

.card-title[title]:hover {
  color: #1a73e8;
  cursor: help;
}

.card-title[title]:hover::after {
  background: linear-gradient(to right, rgba(255, 255, 255, 0), #fff 90%);
}



.teachers-section {
  background-color: #f8f9fa;
  border-radius: 0.25rem;
  padding: 0.5rem;
  margin-top: auto;
}

.list-group-item {
  background-color: transparent;
  border: none;
  padding: 0.5rem 0;
  font-size: 0.9rem;
}

.list-group-item.text-muted {
  font-size: 0.85rem;
  font-style: italic;
}

/* Стили для детальной карточки */
.detail-card {
  max-width: 800px;
  margin: 0 auto;
}

.detail-card .course-title-wrapper {
  min-height: auto;
  margin-bottom: 1.5rem;
}

.detail-card .card-title {
  font-size: 2rem;
  line-height: 1.3;
  -webkit-line-clamp: 3;
  color: #1a202c;
}

.detail-card .card-title::after {
  display: none;
}

.detail-card .teachers-section {
  margin-top: 2rem;
}



.students-section {
  background-color: #f8f9fa;
  border-radius: 0.25rem;
  padding: 0.75rem;
  margin-top: auto;
}

.students-count {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.count-number {
  font-size: 1.2rem;
  font-weight: 600;
  color: #1a73e8;
}

.count-label {
  font-size: 0.9rem;
  color: #6c757d;
}

/* Обновляем стили для детальной карточки */
.detail-card .students-section {
  margin-top: 2rem;
  padding: 1rem;
}

.detail-card .count-number {
  font-size: 2rem;
}

.detail-card .count-label {
  font-size: 1.1rem;
}

/* Стили для бейджа конфига */
.config-badge {
  position: absolute;
  top: 10px;
  left: 10px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 6px 12px;
  border-radius: 15px;
  font-size: 0.85rem;
  font-weight: 500;
  z-index: 10;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
  display: flex;
  align-items: center;
  gap: 4px;
  max-width: calc(100% - 20px);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.config-badge i {
  font-size: 0.8rem;
}
</style> 