<script setup>
import { ref, onMounted, computed } from 'vue';
import { useGeneralStore } from "../store/storeGeneral";
import { useLangStore } from "../store/storeLang";
import { useRouter } from 'vue-router';
import { formatGradeWithPercentage } from '../utils/gradeFormatting';
import { CATEGORY_KEYWORDS, getCategoryType } from '../store/constants';

const generalStore = useGeneralStore();
const langStore = useLangStore();
const router = useRouter();

// Проверка доступа - только для преподавателей и РОП
const hasAccess = computed(() => {
  return generalStore.isROP || (generalStore.userCourses && generalStore.userCourses.some(course => course.isTeacher));
});

// Перенаправление на главную если нет доступа
const checkAccess = () => {
  if (!hasAccess.value) {
    router.push('/');
  }
};

// Реактивные данные
const loading = ref(false);
const searchQuery = ref('');
const selectedConfig = ref('all'); // Фильтр по конфигу

// Pagination state
const currentPage = ref(1);
const studentsPerPage = ref(10);

// Sorting state
const sortField = ref('student_name');
const sortDirection = ref('asc');

// Список уникальных конфигов для фильтра
const availableConfigs = computed(() => {
  const configs = new Map();
  configs.set('all', { id: 'all', name: 'Все конфиги' });
  
  generalStore.userCourses.forEach(courseItem => {
    if (courseItem.config && !configs.has(courseItem.config.id)) {
      configs.set(courseItem.config.id, {
        id: courseItem.config.id,
        name: courseItem.config.name || 'Неизвестный конфиг'
      });
    }
  });
  
  return Array.from(configs.values());
});

// Функция для парсинга оценок студента (такая же как в StudentsGradeTable)
function parseStudentGrades(gradeitems) {
  const grades = {
    frtk1: null,
    frtk2: null,
    individual: null,
    total: null
  };

  // Используем константы из store
  const categoryKeywords = CATEGORY_KEYWORDS;

  const categories = {};
  
  gradeitems.forEach(item => {
    if (item.itemtype === 'category') {
      categories[item.id] = {
        id: item.id,
        name: item.itemname || '',
        gradeValue: item.graderaw,
        weight: item.weightraw,
        instance: item.iteminstance
      };
    } else if (item.itemtype === 'course') {
      grades.total = item.graderaw;
    }
  });

  const categoryKeys = Object.keys(categories);
  const sortedCategories = categoryKeys.sort((a, b) => {
    const catA = categories[a];
    const catB = categories[b];
    
    if (catA.weight !== undefined && catB.weight !== undefined) {
      return catB.weight - catA.weight;
    }
    
    return parseInt(a) - parseInt(b);
  });


  sortedCategories.forEach((categoryId, index) => {
    const category = categories[categoryId];
    
    // Определяем тип категории используя функцию из store
    const categoryType = getCategoryType(category.name);
    
    if (categoryType && category.gradeValue !== null && category.gradeValue !== undefined) {
      grades[categoryType] = category.gradeValue;
    }
  });
  
  return grades;
}

// Агрегация данных из store
const summaryData = computed(() => {
  if (!generalStore.userCourses || generalStore.userCourses.length === 0) {
    return [];
  }

  const studentMap = new Map();

  // Фильтруем курсы по выбранному конфигу
  const filteredCourses = selectedConfig.value === 'all' 
    ? generalStore.userCourses 
    : generalStore.userCourses.filter(courseItem => courseItem.config?.id === selectedConfig.value);

  // Проходим по отфильтрованным курсам
  filteredCourses.forEach(courseItem => {
    const course = courseItem.course;
    
    if (!course.user_grades?.usergrades) return;

    // Проходим по всем студентам в курсе
    course.user_grades.usergrades.forEach(usergrade => {
      const studentId = usergrade.userid;
      const studentData = course.enrolled_users?.find(user => user.id === studentId) || {};
      
      if (!studentMap.has(studentId)) {
        studentMap.set(studentId, {
          student_id: studentId,
          student_email: studentData.email || '',
          student_name: usergrade.userfullname || '',
          courses_data: [],
          grades: {
            frtk1: [],
            frtk2: [],
            individual: [],
            total: []
          }
        });
      }

      const student = studentMap.get(studentId);
      const grades = parseStudentGrades(usergrade.gradeitems || []);
      
      student.courses_data.push({
        course_id: course.id,
        course_name: course.fullname,
        config_name: courseItem.config?.name || 'Неизвестный конфиг',
        grades: grades
      });

      // Добавляем оценки в массивы для расчета средних
      if (grades.frtk1 !== null && grades.frtk1 !== undefined) {
        student.grades.frtk1.push(parseFloat(grades.frtk1));
      }
      if (grades.frtk2 !== null && grades.frtk2 !== undefined) {
        student.grades.frtk2.push(parseFloat(grades.frtk2));
      }
      if (grades.individual !== null && grades.individual !== undefined) {
        student.grades.individual.push(parseFloat(grades.individual));
      }
      if (grades.total !== null && grades.total !== undefined) {
        student.grades.total.push(parseFloat(grades.total));
      }
    });
  });

  // Вычисляем средние для каждого студента
  return Array.from(studentMap.values()).map(student => {
    const calculateAverage = (grades) => {
      return grades.length > 0 ? grades.reduce((sum, grade) => sum + grade, 0) / grades.length : null;
    };

    return {
      student_id: student.student_id,
      student_email: student.student_email,
      student_name: student.student_name,
      courses_data: student.courses_data,
      overall_averages: {
        avg_grade1: calculateAverage(student.grades.frtk1),
        avg_grade2: calculateAverage(student.grades.frtk2),
        avg_grade3: calculateAverage(student.grades.individual),
        avg_total: calculateAverage(student.grades.total),
        courses_count: student.courses_data.length
      }
    };
  });
});

// Глобальная статистика
const globalStatistics = computed(() => {
  if (!summaryData.value || summaryData.value.length === 0) {
    return {
      total_courses: 0,
      total_students: 0
    };
  }

  const uniqueCourses = new Set();
  summaryData.value.forEach(student => {
    student.courses_data.forEach(course => {
      uniqueCourses.add(course.course_id);
    });
  });

  return {
    total_courses: uniqueCourses.size,
    total_students: summaryData.value.length
  };
});

// Вычисляемые свойства
const filteredStudents = computed(() => {
  if (!summaryData.value || !Array.isArray(summaryData.value)) {
    return [];
  }
  
  let filtered = [...summaryData.value];
  
  // Применяем фильтр поиска
  if (searchQuery.value) {
    filtered = filtered.filter(student => {
      if (!student || !student.student_name || !student.student_email) {
        return false;
      }
      return student.student_name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
             student.student_email.toLowerCase().includes(searchQuery.value.toLowerCase());
    });
  }
  
  // Применяем сортировку
  if (sortField.value && filtered.length > 0) {
    filtered.sort((a, b) => {
      let aValue, bValue;
      
      // Проверяем валидность данных
      if (!a || !b || !a.overall_averages || !b.overall_averages) {
        return 0;
      }
      
      switch (sortField.value) {
        case 'student_name':
          aValue = a.student_name || '';
          bValue = b.student_name || '';
          break;
        case 'avg_grade1':
          aValue = a.overall_averages.avg_grade1 || 0;
          bValue = b.overall_averages.avg_grade1 || 0;
          break;
        case 'avg_grade2':
          aValue = a.overall_averages.avg_grade2 || 0;
          bValue = b.overall_averages.avg_grade2 || 0;
          break;
        case 'avg_grade3':
          aValue = a.overall_averages.avg_grade3 || 0;
          bValue = b.overall_averages.avg_grade3 || 0;
          break;
        case 'avg_total':
          aValue = a.overall_averages.avg_total || 0;
          bValue = b.overall_averages.avg_total || 0;
          break;
        case 'courses_count':
          aValue = a.overall_averages.courses_count || 0;
          bValue = b.overall_averages.courses_count || 0;
          break;
        default:
          return 0;
      }
      
      // Сравнение значений
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        const result = aValue.localeCompare(bValue, 'ru');
        return sortDirection.value === 'asc' ? result : -result;
      } else {
        const numA = Number(aValue) || 0;
        const numB = Number(bValue) || 0;
        const result = numA - numB;
        return sortDirection.value === 'asc' ? result : -result;
      }
    });
  }
  
  return filtered;
});

// Pagination computed properties
const totalStudents = computed(() => filteredStudents.value.length);
const totalPages = computed(() => Math.ceil(totalStudents.value / studentsPerPage.value));

const startIndex = computed(() => (currentPage.value - 1) * studentsPerPage.value);
const endIndex = computed(() => startIndex.value + studentsPerPage.value);

const paginatedStudents = computed(() => {
  return filteredStudents.value.slice(startIndex.value, endIndex.value);
});

// Видимые страницы для пагинации
const visiblePages = computed(() => {
  const pages = [];
  const maxVisiblePages = 5;
  let start = Math.max(1, currentPage.value - Math.floor(maxVisiblePages / 2));
  let end = Math.min(totalPages.value, start + maxVisiblePages - 1);

  if (end - start < maxVisiblePages - 1) {
    start = Math.max(1, end - maxVisiblePages + 1);
  }

  for (let i = start; i <= end; i++) {
    pages.push(i);
  }

  return pages;
});

// Статистика по всем студентам
const overallStatistics = computed(() => {
  if (!filteredStudents.value || filteredStudents.value.length === 0) {
    return {
      avg_grade1: 0,
      avg_grade2: 0,
      avg_grade3: 0,
      avg_total: 0,
      avg_courses_count: 0,
      total_students: 0
    };
  }

  let grade1Sum = 0, grade1Count = 0;
  let grade2Sum = 0, grade2Count = 0;
  let grade3Sum = 0, grade3Count = 0;
  let totalSum = 0, totalCount = 0;
  let coursesSum = 0, coursesCount = 0;

  filteredStudents.value.forEach(student => {
    if (student?.overall_averages) {
      const averages = student.overall_averages;
      
      if (averages.avg_grade1 !== null && averages.avg_grade1 !== undefined) {
        grade1Sum += averages.avg_grade1;
        grade1Count++;
      }
      
      if (averages.avg_grade2 !== null && averages.avg_grade2 !== undefined) {
        grade2Sum += averages.avg_grade2;
        grade2Count++;
      }
      
      if (averages.avg_grade3 !== null && averages.avg_grade3 !== undefined) {
        grade3Sum += averages.avg_grade3;
        grade3Count++;
      }
      
      if (averages.avg_total !== null && averages.avg_total !== undefined) {
        totalSum += averages.avg_total;
        totalCount++;
      }
      
      if (averages.courses_count !== null && averages.courses_count !== undefined) {
        coursesSum += averages.courses_count;
        coursesCount++;
      }
    }
  });

  return {
    avg_grade1: grade1Count > 0 ? Math.round((grade1Sum / grade1Count) * 100) / 100 : 0,
    avg_grade2: grade2Count > 0 ? Math.round((grade2Sum / grade2Count) * 100) / 100 : 0,
    avg_grade3: grade3Count > 0 ? Math.round((grade3Sum / grade3Count) * 100) / 100 : 0,
    avg_total: totalCount > 0 ? Math.round((totalSum / totalCount) * 100) / 100 : 0,
    avg_courses_count: coursesCount > 0 ? Math.round((coursesSum / coursesCount) * 100) / 100 : 0,
    total_students: filteredStudents.value.length
  };
});

// Методы
const goBack = () => {
  router.push('/');
};

const formatGrade = (grade) => {
  if (grade === null || grade === undefined) {
    return '-';
  }
  
  const numGrade = parseFloat(grade);
  if (isNaN(numGrade)) {
    return grade.toString();
  }
  
  // Для глобальной сводки используем стандартную максимальную оценку 100
  // так как это агрегированные данные из разных курсов
  return formatGradeWithPercentage(grade, null, 100);
};

const sortBy = (field) => {
  if (sortField.value === field) {
    // Если кликнули по той же колонке, меняем направление
    sortDirection.value = sortDirection.value === 'asc' ? 'desc' : 'asc';
  } else {
    // Если кликнули по новой колонке, устанавливаем asc
    sortField.value = field;
    sortDirection.value = 'asc';
  }
};

const getSortIcon = (field) => {
  if (!sortField.value || sortField.value !== field) {
    return 'fa-sort'; // Неактивная сортировка
  }
  return sortDirection.value === 'asc' ? 'fa-sort-up' : 'fa-sort-down';
};

const getSortClass = (field) => {
  return (sortField.value && sortField.value === field) ? 'sorted-column' : '';
};

const goToPage = (page) => {
  if (page >= 1 && page <= totalPages.value) {
    currentPage.value = page;
  }
};

const onSearch = () => {
  currentPage.value = 1; // Сбрасываем на первую страницу при поиске
};

const onConfigChange = () => {
  currentPage.value = 1; // Сбрасываем на первую страницу при изменении фильтра
};

// Хуки жизненного цикла
onMounted(() => {
  // Проверяем доступ
  checkAccess();
});
</script>

<template>
  <div class="global-summary-container">
    <!-- Сообщение об отсутствии доступа -->
    <div v-if="!hasAccess" class="access-denied">
      <div class="alert alert-warning text-center">
        <i class="fa fa-exclamation-triangle fa-2x mb-3"></i>
        <h4>{{ langStore.strings.access_denied || 'Доступ запрещен' }}</h4>
        <p>{{ langStore.strings.access_denied_summary || 'У вас нет прав для просмотра сводной статистики. Эта функция доступна только преподавателям.' }}</p>
        <button @click="goBack" class="btn btn-primary">
          <i class="fa fa-arrow-left me-1"></i>
          {{ langStore.strings.back || 'Назад' }}
        </button>
      </div>
    </div>

    <!-- Основной контент для пользователей с доступом -->
    <div v-else>
    <!-- Заголовок -->
    <div class="summary-header mb-4">
      <div class="row align-items-center">
        <div class="col-md-8">
          <div class="d-flex align-items-center">
            <button @click="goBack" class="btn btn-outline-secondary me-3">
              <i class="fa fa-arrow-left me-1"></i>
              {{ langStore.strings.back || 'Назад' }}
            </button>
            <div>
              <h3 class="mb-1">
                <i class="fa fa-chart-bar me-2 text-primary"></i>
                {{ langStore.strings.global_summary_title || 'Общее - Сводка по всем курсам' }}
              </h3>
              <p class="text-muted mb-0">
                {{ langStore.strings.global_summary_description || 'Агрегированные данные всех студентов по всем курсам' }}
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4 text-end">
          <!-- Глобальная статистика -->
          <div v-if="globalStatistics" class="global-stats">
            <div class="stat-card">
              <small class="text-muted">{{ langStore.strings.total_courses || 'Всего курсов' }}</small>
              <div class="stat-value">{{ globalStatistics.total_courses }}</div>
            </div>
            <div class="stat-card">
              <small class="text-muted">{{ langStore.strings.total_students || 'Всего студентов' }}</small>
              <div class="stat-value">{{ globalStatistics.total_students }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Основной контент -->
    <div class="summary-content">
      <!-- Поиск и фильтры -->
      <div class="search-section mb-3">
        <div class="row align-items-center mb-3">
          <div class="col-md-6">
            <div class="search-box">
              <input 
                v-model="searchQuery" 
                type="text" 
                class="form-control" 
                :placeholder="langStore.strings.search_student || 'Поиск студента...'"
                @input="onSearch">
              <i class="fa fa-search search-icon"></i>
            </div>
          </div>
          <div class="col-md-6 text-end">
            <small class="text-muted">
              {{ langStore.strings.showing || 'Показано' }} 
              {{ startIndex + 1 }}-{{ Math.min(endIndex, filteredStudents.length) }} 
              {{ langStore.strings.of || 'из' }} 
              {{ filteredStudents.length }} 
              {{ langStore.strings.students || 'студентов' }}
            </small>
          </div>
        </div>
        
        <!-- Фильтр по конфигам (показывается только если несколько конфигов) -->
        <div v-if="availableConfigs.length > 2" class="row">
          <div class="col-md-6">
            <div class="config-filter">
              <label for="configSelect" class="form-label">
                <i class="fa fa-filter me-1"></i>
                {{ langStore.strings.filter_by_config || 'Фильтр по конфигу:' }}
              </label>
              <select 
                id="configSelect"
                v-model="selectedConfig" 
                class="form-select"
                @change="onConfigChange"
              >
                <option 
                  v-for="config in availableConfigs" 
                  :key="config.id" 
                  :value="config.id"
                >
                  {{ config.name }}
                </option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <!-- Подсказка для мобильных -->
      <div class="mobile-scroll-hint d-md-none mb-2">
        <small class="text-muted">
          <i class="fa fa-hand-point-right me-1"></i>
          {{ langStore.strings.scroll_horizontally || 'Прокрутите горизонтально для просмотра всех колонок' }}
        </small>
      </div>

      <!-- Сводная таблица -->
      <div class="table-responsive">
        <table class="table table-bordered table-hover">
                                  <thead class="table-header-sticky">
                          <tr>
                            <th scope="col" class="student-column sortable" :class="getSortClass('student_name')" @click="sortBy('student_name')">
                              <i class="fa fa-user me-1"></i>
                              {{ langStore.strings.student_name || 'Студент' }}
                              <i :class="['fa', getSortIcon('student_name'), 'ms-1', 'sort-icon']"></i>
                            </th>
                            <th scope="col" class="grade-column text-center sortable" :class="getSortClass('avg_grade1')" @click="sortBy('avg_grade1')">
                              {{ langStore.strings.avg_frtk1 || 'Средний ФРТК1' }}
                              <i :class="['fa', getSortIcon('avg_grade1'), 'ms-1', 'sort-icon']"></i>
                            </th>
                            <th scope="col" class="grade-column text-center sortable" :class="getSortClass('avg_grade2')" @click="sortBy('avg_grade2')">
                              {{ langStore.strings.avg_frtk2 || 'Средний ФРТК2' }}
                              <i :class="['fa', getSortIcon('avg_grade2'), 'ms-1', 'sort-icon']"></i>
                            </th>
                            <th scope="col" class="grade-column text-center sortable" :class="getSortClass('avg_grade3')" @click="sortBy('avg_grade3')">
                              {{ langStore.strings.avg_individual || 'Средние инд. достижения' }}
                              <i :class="['fa', getSortIcon('avg_grade3'), 'ms-1', 'sort-icon']"></i>
                            </th>
                            <th scope="col" class="total-column text-center sortable" :class="getSortClass('avg_total')" @click="sortBy('avg_total')">
                              {{ langStore.strings.overall_average || 'Общий средний' }}
                              <i :class="['fa', getSortIcon('avg_total'), 'ms-1', 'sort-icon']"></i>
                            </th>
                            <th scope="col" class="courses-column text-center sortable" :class="getSortClass('courses_count')" @click="sortBy('courses_count')">
                              {{ langStore.strings.courses_count || 'Курсов' }}
                              <i :class="['fa', getSortIcon('courses_count'), 'ms-1', 'sort-icon']"></i>
                            </th>
                          </tr>
                        </thead>
          <tbody>
            <!-- Студенты -->
            <template v-for="(student, index) in paginatedStudents" :key="`student-template-${index}`">
              <tr v-if="student && student.overall_averages" class="student-main-row">
              <td class="student-info">
                <div class="student-details">
                  <strong>{{ student.student_name || 'N/A' }}</strong>
                  <br>
                  <small class="text-muted">{{ student.student_email || 'N/A' }}</small>
                </div>
              </td>
              <td class="text-center">
                <span class="grade-value">
                  {{ formatGrade(student.overall_averages?.avg_grade1) }}
                </span>
              </td>
              <td class="text-center">
                <span class="grade-value">
                  {{ formatGrade(student.overall_averages?.avg_grade2) }}
                </span>
              </td>
              <td class="text-center">
                <span class="grade-value">
                  {{ formatGrade(student.overall_averages?.avg_grade3) }}
                </span>
              </td>
              <td class="text-center">
                <span class="grade-value total-grade">
                  {{ formatGrade(student.overall_averages?.avg_total) }}
                </span>
              </td>
              <td class="text-center">
                <span class="courses-count">
                  {{ student.overall_averages?.courses_count || 0 }}
                </span>
              </td>
            </tr>
            </template>
            
            <!-- Строка общей статистики -->
            <tr v-if="filteredStudents.length > 0" class="statistics-row">
              <td class="statistics-label">
                <strong>{{ langStore.strings.overall_statistics || 'Общая статистика' }}</strong>
                <small class="d-block text-muted">
                  {{ langStore.strings.average_values || 'Средние значения' }}
                </small>
              </td>
              <td class="text-center statistics-value">
                <span class="grade-value statistics-grade">
                  {{ overallStatistics.avg_grade1 > 0 ? overallStatistics.avg_grade1.toFixed(2) : '-' }}
                </span>
              </td>
              <td class="text-center statistics-value">
                <span class="grade-value statistics-grade">
                  {{ overallStatistics.avg_grade2 > 0 ? overallStatistics.avg_grade2.toFixed(2) : '-' }}
                </span>
              </td>
              <td class="text-center statistics-value">
                <span class="grade-value statistics-grade">
                  {{ overallStatistics.avg_grade3 > 0 ? overallStatistics.avg_grade3.toFixed(2) : '-' }}
                </span>
              </td>
              <td class="text-center statistics-value">
                <span class="grade-value statistics-total">
                  {{ overallStatistics.avg_total > 0 ? overallStatistics.avg_total.toFixed(2) : '-' }}
                </span>
              </td>
              <td class="text-center statistics-value">
                <span class="courses-count statistics-courses">
                  {{ overallStatistics.avg_courses_count > 0 ? overallStatistics.avg_courses_count.toFixed(1) : '-' }}
                </span>
              </td>
            </tr>
          </tbody>
          
          <!-- Подвал таблицы со средними баллами -->
          <tfoot v-show="filteredStudents.length > 0" class="table-footer">
            <tr class="average-row">
              <td class="average-label">
                <div class="d-flex align-items-center">
                  <i class="fa fa-chart-bar text-primary me-2"></i>
                  <div>
                    <div class="average-title">
                      <i class="fa fa-calculator me-1"></i>
                      {{ langStore.strings.overall_statistics || 'Общая статистика' }}
                    </div>
                    <small class="text-muted">
                      {{ langStore.strings.based_on || 'На основе' }} {{ filteredStudents.length }} 
                      {{ langStore.strings.students || 'студентов' }}
                    </small>
                  </div>
                </div>
              </td>
              <td class="average-cell text-center">
                <span class="average-badge average-grade-good">
                  {{ overallStatistics.avg_grade1 > 0 ? overallStatistics.avg_grade1.toFixed(2) : '-' }}
                </span>
              </td>
              <td class="average-cell text-center">
                <span class="average-badge average-grade-good">
                  {{ overallStatistics.avg_grade2 > 0 ? overallStatistics.avg_grade2.toFixed(2) : '-' }}
                </span>
              </td>
              <td class="average-cell text-center">
                <span class="average-badge average-grade-good">
                  {{ overallStatistics.avg_grade3 > 0 ? overallStatistics.avg_grade3.toFixed(2) : '-' }}
                </span>
              </td>
              <td class="average-cell text-center">
                <span class="average-total-badge average-total-grade-good">
                  {{ overallStatistics.avg_total > 0 ? overallStatistics.avg_total.toFixed(2) : '-' }}
                </span>
              </td>
              <td class="average-cell text-center">
                <span class="average-badge average-grade-empty">
                  {{ overallStatistics.avg_courses_count > 0 ? overallStatistics.avg_courses_count.toFixed(1) : '-' }}
                </span>
              </td>
            </tr>
          </tfoot>
        </table>
      </div>



      <!-- Пагинация -->
      <div v-if="totalPages > 1" class="pagination-container">
        <nav aria-label="Students pagination">
          <ul class="pagination pagination-sm justify-content-center">
            <li class="page-item" :class="{ disabled: currentPage === 1 }">
              <button class="page-link" @click="goToPage(1)" :disabled="currentPage === 1">
                <i class="fa fa-angle-double-left"></i>
              </button>
            </li>
            <li class="page-item" :class="{ disabled: currentPage === 1 }">
              <button class="page-link" @click="goToPage(currentPage - 1)" :disabled="currentPage === 1">
                <i class="fa fa-angle-left"></i>
              </button>
            </li>
            
            <li v-for="page in visiblePages" 
                :key="page" 
                class="page-item" 
                :class="{ active: page === currentPage }">
              <button class="page-link" @click="goToPage(page)">
                {{ page }}
              </button>
            </li>
            
            <li class="page-item" :class="{ disabled: currentPage === totalPages }">
              <button class="page-link" @click="goToPage(currentPage + 1)" :disabled="currentPage === totalPages">
                <i class="fa fa-angle-right"></i>
              </button>
            </li>
            <li class="page-item" :class="{ disabled: currentPage === totalPages }">
              <button class="page-link" @click="goToPage(totalPages)" :disabled="currentPage === totalPages">
                <i class="fa fa-angle-double-right"></i>
              </button>
            </li>
          </ul>
        </nav>
        
        <!-- Информация о пагинации -->
        <div class="pagination-info text-center mt-2">
          <small class="text-muted">
            {{ langStore.strings.showing || 'Показано' }} 
            {{ startIndex + 1 }}-{{ Math.min(endIndex, totalStudents) }} 
            {{ langStore.strings.of || 'из' }} 
            {{ totalStudents }} 
            {{ langStore.strings.students || 'студентов' }}
          </small>
        </div>
      </div>
      
      <!-- Пустое состояние -->
      <div v-if="filteredStudents.length === 0" class="empty-state text-center py-5">
        <i class="fa fa-search fa-3x text-muted mb-3"></i>
        <h5 class="text-muted">{{ langStore.strings.no_students_found || 'Студенты не найдены' }}</h5>
        <p class="text-muted">{{ langStore.strings.try_different_search || 'Попробуйте изменить параметры поиска' }}</p>
      </div>
    </div>
    </div> <!-- Закрывающий тег для v-else -->
  </div>
</template>

<style scoped>
@import '../styles/table-footer.css';
.global-summary-container {
  padding: 1rem;
}

/* Стили для сообщения об отказе в доступе */
.access-denied {
  max-width: 600px;
  margin: 3rem auto;
  padding: 2rem;
}

.access-denied .alert {
  border: none;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  border-radius: 12px;
}

.access-denied .fa-exclamation-triangle {
  color: #f39c12;
}

.summary-header {
  background: #f8f9fa;
  padding: 1.5rem;
  border-radius: 0.5rem;
  border-left: 4px solid #007bff;
}

.global-stats {
  display: flex;
  gap: 1rem;
}

.stat-card {
  text-align: center;
  padding: 0.5rem;
  background: white;
  border-radius: 0.375rem;
  border: 1px solid #dee2e6;
  min-width: 80px;
}

.stat-value {
  font-size: 1.5rem;
  font-weight: bold;
  color: #007bff;
}

.progress-loader {
  margin: 2rem 0;
}

.search-box {
  position: relative;
}

.search-icon {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: #6c757d;
}

.config-filter {
  margin-bottom: 1rem;
}

.config-filter .form-label {
  font-weight: 600;
  color: #495057;
  margin-bottom: 0.5rem;
  font-size: 0.9rem;
}

.config-filter .form-select {
  border: 1px solid #ced4da;
  border-radius: 0.375rem;
  padding: 0.5rem 0.75rem;
  font-size: 0.9rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

.config-filter .form-select:focus {
  border-color: #80bdff;
  outline: 0;
  box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}

.table-header-sticky {
  position: sticky;
  top: 0;
  background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
  color: #495057;
  z-index: 10;
  border-bottom: 2px solid #dee2e6;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.table-header-sticky th {
  font-weight: 600;
  font-size: 0.9rem;
  padding: 1rem 0.75rem;
  border-bottom: 2px solid #dee2e6;
}

.sortable {
  cursor: pointer;
  user-select: none;
  transition: all 0.2s ease;
  position: relative;
}

.sortable:hover {
  background: linear-gradient(135deg, #e9ecef 0%, #dee2e6 100%);
  color: #343a40;
}

.sorted-column {
  background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
  color: #1976d2;
}

.sort-icon {
  opacity: 0.6;
  font-size: 0.8em;
  margin-left: 0.25rem;
}

.sortable:hover .sort-icon,
.sorted-column .sort-icon {
  opacity: 1;
}

.student-column {
  min-width: 200px;
}

.grade-column {
  width: 120px;
}

.total-column {
  width: 140px;
}

.courses-column {
  width: 100px;
}

.student-main-row {
  background: #f8f9fa;
}

.student-main-row:hover {
  background: #e9ecef;
}

.student-details {
  line-height: 1.2;
}

.grade-value {
  font-weight: 600;
  padding: 0.25rem 0.5rem;
  border-radius: 0.25rem;
  background: #e3f2fd;
  color: #1976d2;
}

.total-grade {
  background: #e8f5e8;
  color: #2e7d32;
  font-size: 1.1em;
}

.courses-count {
  font-weight: 600;
  color: #6c757d;
}

.empty-state {
  padding: 3rem 1rem;
}

.mobile-scroll-hint {
  padding: 0.5rem;
  background: #fff3cd;
  border-radius: 0.375rem;
  border: 1px solid #ffeaa7;
}

/* Адаптивность */
@media (max-width: 768px) {
  .summary-header .row {
    flex-direction: column;
  }
  
  .global-stats {
    justify-content: center;
    margin-top: 1rem;
  }
  
  .stat-card {
    min-width: 70px;
  }
  
  .table th,
  .table td {
    font-size: 0.875rem;
    padding: 0.5rem 0.25rem;
  }
}

/* Пагинация */
.pagination-container {
  margin-top: 1.5rem;
}

.pagination .page-link {
  color: #007bff;
  border-color: #dee2e6;
  padding: 0.375rem 0.75rem;
}

.pagination .page-link:hover {
  color: #0056b3;
  background-color: #e9ecef;
  border-color: #dee2e6;
}

.pagination .page-item.active .page-link {
  background-color: #007bff;
  border-color: #007bff;
  color: white;
}

.pagination .page-item.disabled .page-link {
  color: #6c757d;
  background-color: #fff;
  border-color: #dee2e6;
  cursor: not-allowed;
}

.pagination-info {
  margin-top: 0.5rem;
}

/* Статистический подвал */
.statistics-footer {
  margin-top: 1.5rem;
}

.statistics-footer .card {
  border: none;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  border-radius: 0.5rem;
  overflow: hidden;
}

.statistics-footer .card-header {
  background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
  border: none;
  padding: 1rem 1.25rem;
}

.statistics-footer .card-body {
  padding: 1.5rem;
  background: #f8f9fa;
}

.stat-item {
  text-align: center;
  padding: 1rem;
  background: white;
  border-radius: 0.5rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.stat-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.stat-label {
  font-size: 0.75rem;
  font-weight: 600;
  color: #6c757d;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 0.5rem;
}

.stat-value {
  font-size: 1.5rem;
  font-weight: 700;

  padding: 0.5rem 1rem;
  border-radius: 0.375rem;
  display: inline-block;
  min-width: 80px;
}

.stat-frtk1 {
  background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
}

.stat-frtk2 {
  background: linear-gradient(135deg, #17a2b8 0%, #007bff 100%);
}

.stat-individual {
  background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);
}

.stat-total {
  background: linear-gradient(135deg, #6f42c1 0%, #e83e8c 100%);
}

.stat-courses {
  background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
}

.stat-students {
  background: linear-gradient(135deg, #495057 0%, #343a40 100%);
}

/* Адаптивность для статистики */
@media (max-width: 768px) {
  .statistics-footer .row {
    row-gap: 1rem;
  }
  
  .stat-item {
    padding: 0.75rem;
  }
  
  .stat-value {
    font-size: 1.25rem;
    padding: 0.375rem 0.75rem;
  }
  
  .stat-label {
    font-size: 0.7rem;
  }
}


</style> 