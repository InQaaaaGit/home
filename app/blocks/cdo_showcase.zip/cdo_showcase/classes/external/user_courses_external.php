<?php

namespace block_cdo_showcase\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use core_external\external_value;
use moodle_exception;
use invalid_parameter_exception;

class user_courses_external extends external_api
{
    /**
     * Returns description of save_user_courses() parameters
     *
     * @return external_function_parameters
     */
    public static function save_user_courses_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            'config_id' => new external_value(PARAM_INT, 'Configuration ID'),
            'user_email' => new external_value(PARAM_EMAIL, 'User email'),
            'course_ids' => new external_multiple_structure(
                new external_value(PARAM_INT, 'Course ID')
            )
        ]);
    }

    /**
     * Save courses for a user by email
     *
     * @param int $config_id Configuration ID
     * @param string $user_email User email
     * @param array $course_ids Array of course IDs
     * @return array
     * @throws invalid_parameter_exception
     * @throws moodle_exception
     */
    public static function save_user_courses(int $config_id, string $user_email, array $course_ids): array
    {
        global $DB;

        // Parameter validation
        $params = self::validate_parameters(self::save_user_courses_parameters(), [
            'config_id' => $config_id,
            'user_email' => $user_email,
            'course_ids' => $course_ids
        ]);

        // Context validation
        $context = \context_system::instance();
        self::validate_context($context);

        try {
            // Начинаем транзакцию
            $transaction = $DB->start_delegated_transaction();

            // Удаляем существующие записи для этого пользователя и конфигурации
            $DB->delete_records('block_cdo_showcase_user_courses', [
                'config_id' => $params['config_id'],
                'user_email' => $params['user_email']
            ]);

            // Добавляем новые записи
            $time = time();
            $records_added = 0;
            
            foreach ($params['course_ids'] as $course_id) {
                $record = new \stdClass();
                $record->config_id = $params['config_id'];
                $record->user_email = $params['user_email'];
                $record->course_id = $course_id;
                $record->timecreated = $time;
                $record->timemodified = $time;
                
                $DB->insert_record('block_cdo_showcase_user_courses', $record);
                $records_added++;
            }

            // Подтверждаем транзакцию
            $transaction->allow_commit();

            return [
                'success' => true,
                'message' => "Успешно сохранено {$records_added} курсов для пользователя {$user_email}",
                'courses_count' => $records_added
            ];

        } catch (\Exception $e) {
            // Откатываем транзакцию в случае ошибки
            if (isset($transaction)) {
                $transaction->rollback($e);
            }
            
            throw new moodle_exception('error_saving_user_courses', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Returns description of save_user_courses() result value
     *
     * @return external_single_structure
     */
    public static function save_user_courses_returns(): external_single_structure
    {
        return new external_single_structure([
            'success' => new external_value(PARAM_BOOL, 'Operation success'),
            'message' => new external_value(PARAM_TEXT, 'Result message'),
            'courses_count' => new external_value(PARAM_INT, 'Number of courses saved')
        ]);
    }

    /**
     * Returns description of get_user_courses() parameters
     *
     * @return external_function_parameters
     */
    public static function get_user_courses_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            'config_id' => new external_value(PARAM_INT, 'Configuration ID'),
            'user_email' => new external_value(PARAM_EMAIL, 'User email')
        ]);
    }

    /**
     * Get courses for a user by email
     *
     * @param int $config_id Configuration ID
     * @param string $user_email User email
     * @return array
     */
    public static function get_user_courses(int $config_id, string $user_email): array
    {
        global $DB;

        // Parameter validation
        $params = self::validate_parameters(self::get_user_courses_parameters(), [
            'config_id' => $config_id,
            'user_email' => $user_email
        ]);

        // Context validation
        $context = \context_system::instance();
        self::validate_context($context);

        try {
            $sql = "SELECT uc.*, c.fullname, c.shortname, c.category
                    FROM {block_cdo_showcase_user_courses} uc
                    LEFT JOIN {course} c ON c.id = uc.course_id
                    WHERE uc.config_id = :config_id AND uc.user_email = :user_email
                    ORDER BY c.fullname";

            $records = $DB->get_records_sql($sql, [
                'config_id' => $params['config_id'],
                'user_email' => $params['user_email']
            ]);

            $courses = [];
            foreach ($records as $record) {
                $courses[] = [
                    'id' => (int)$record->course_id,
                    'fullname' => $record->fullname ?? 'Неизвестный курс',
                    'shortname' => $record->shortname ?? '',
                    'category' => (int)$record->category,
                    'timecreated' => (int)$record->timecreated,
                    'timemodified' => (int)$record->timemodified
                ];
            }

            return $courses;

        } catch (\Exception $e) {
            throw new moodle_exception('error_getting_user_courses', 'block_cdo_showcase', '', $e->getMessage());
        }
    }

    /**
     * Returns description of get_user_courses() result value
     *
     * @return external_multiple_structure
     */
    public static function get_user_courses_returns(): external_multiple_structure
    {
        return new external_multiple_structure(
            new external_single_structure([
                'id' => new external_value(PARAM_INT, 'Course ID'),
                'fullname' => new external_value(PARAM_TEXT, 'Course full name'),
                'shortname' => new external_value(PARAM_TEXT, 'Course short name'),
                'category' => new external_value(PARAM_INT, 'Course category'),
                'timecreated' => new external_value(PARAM_INT, 'Time created'),
                'timemodified' => new external_value(PARAM_INT, 'Time modified')
            ])
        );
    }
} 